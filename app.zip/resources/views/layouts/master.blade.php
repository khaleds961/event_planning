@include('layouts.head')

<body>
    <div>
        @yield('content')
    </div>
    @include('layouts.foot')
</body>
