<div>Dear <strong><?php echo e($player_name); ?></strong>,
    <p>
        <?php echo e($description); ?>

    </p>
    Best Regards, <br />
    <strong>The Sporciety Team.</strong><?php /**PATH C:\Xampp\htdocs\sportciety_club\resources\views/layouts/emails/email_offer.blade.php ENDPATH**/ ?>