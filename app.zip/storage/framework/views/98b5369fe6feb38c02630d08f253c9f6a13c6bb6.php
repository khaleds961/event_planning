
<?php $__env->startSection('title', 'Booking'); ?>
<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <div class="d-flex justify-content-between">
            <ol class="breadcrumb border border-warning px-3 py-2 rounded">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                            class="ti ti-home fs-4 mt-1"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('sales.index')); ?>" class="text-warning">Sales</a>
                </li>
            </ol>
        </div>
    </nav>

    <div class="row mt-4">
        <div class="col-12">
            <div class="row">
                <div class="col-md-2">
                    <div class="mb-3 has-success">
                        <label class="control-label">FROM</label>
                        <input type="text" class="form-control datepicker" id="date_from">
                        <span id="start_date_error"></span>
                    </div>
                </div>
                <!--/span-->
                <div class="col-md-2">
                    <div class="mb-3">
                        <label class="control-label">TO</label>
                        <input type="input" class="form-control datepicker" id="date_to">
                        <span id="end_date_error"></span>
                    </div>
                </div>
                <!--/span-->

                <div class="col-md-6">
                    <button class="btn btn-dark margin_top_responsive" id="search_sales_items">
                        <i class="ti ti-search"></i>
                        <span>Search</span>
                    </button>

                    <button class="btn btn-primary margin_top_responsive mx-2" id="clear_dates">
                        <i class="ti ti-brush"></i>
                        <span>Clear Dates</span>
                    </button>
                </div>
            </div>


            <!-- SALES MODAL -->
            <div class="modal fade" id="saleModal" tabindex="-1" aria-labelledby="saleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="saleModalLabel">
                                Add New Sale
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">

                            <div class="row">
                                <div class="col-12 col-md-4">
                                    <div class="user-chat-box h-100" style="border: 1px solid #DCDCDC">
                                        <div class="px-4 pt-9 pb-6 d-none d-lg-block">
                                            <form class="position-relative">
                                                <input type="text" class="form-control search-chat py-2 ps-5"
                                                    id="search_items" placeholder="Search">
                                                <i
                                                    class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                            </form>
                                        </div>
                                        <div class="app-chat">
                                            <ul class="chat-users" style="height: calc(100vh - 400px)"
                                                data-simplebar="init">
                                                <div class="simplebar-wrapper" style="margin: 0px;">
                                                    <div class="simplebar-height-auto-observer-wrapper">
                                                        <div class="simplebar-height-auto-observer"></div>
                                                    </div>
                                                    <div class="simplebar-mask">
                                                        <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                                                            <div class="simplebar-content-wrapper" tabindex="0"
                                                                role="region" aria-label="scrollable content"
                                                                style="height: 100%; overflow: hidden scroll;">
                                                                <div class="simplebar-content" style="padding: 0px;">
                                                                    <div class="items_container">
                                                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <li>
                                                                                <a href="javascript:void(0)"
                                                                                    class="px-4 py-3 bg-hover-light-black d-flex align-items-center click_item"
                                                                                    data-item-id="<?php echo e($item->id); ?>"
                                                                                    data-item-price="<?php echo e($item->price); ?>"
                                                                                    data-item-name="<?php echo e($item->name); ?>">
                                                                                    <span class="position-relative">
                                                                                        <img src="<?php echo e($item->img != null && $item->img != ''
                                                                                            ? url('') . '/' . $item->img
                                                                                            : url('') . '/public/images/courts/no-image.png'); ?>"
                                                                                            alt="user2" width="40"
                                                                                            height="40"
                                                                                            class="rounded-circle border">
                                                                                    </span>
                                                                                    <div class="ms-6 d-inline-block w-75">
                                                                                        <h6 class="mb-1 fw-semibold chat-title"
                                                                                            data-name="<?php echo e($item->name); ?>">
                                                                                            <?php echo e($item->name); ?></h6>
                                                                                    </div>
                                                                                </a>
                                                                            </li>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="simplebar-placeholder" style="width: auto; height: 720px;">
                                                    </div>
                                                </div>
                                                <div class="simplebar-track simplebar-horizontal"
                                                    style="visibility: hidden;">
                                                    <div class="simplebar-scrollbar" style="width: 0px; display: none;">
                                                    </div>
                                                </div>
                                                <div class="simplebar-track simplebar-vertical"
                                                    style="visibility: visible;">
                                                    <div class="simplebar-scrollbar"
                                                        style="height: 440px; transform: translate3d(0px, 0px, 0px); display: block;">
                                                    </div>
                                                </div>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-8">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <label for="date_" class="control-label col-form-label">Purchase
                                                    Date<b class="text-danger">*</b></label>
                                                <input type="text" class="form-control datepicker" id="date_">
                                                <span class="date_error text-uppercase text-danger b"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-12 col-md-8">
                                        <div class="col-md-4 col-xl-3">
                                            <label class="control-label col-form-label">Paid/Unpaid</label>
                                        </div>
                                        <div class="col-md-8 col-xl-9">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input success check-light-success" type="radio"
                                                    name="paid_unpaid" id="success-light-radio" value="paid">
                                                <label class="form-check-label" for="success-light-radio">Paid</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input success check-light-success" type="radio"
                                                    name="paid_unpaid" id="success2-light-radio" value="unpaid">
                                                <label class="form-check-label" for="success2-light-radio">Unpaid</label>
                                            </div>
                                        </div>
                                    </div>


                                    <label for="date_" class="control-label col-form-label">Choose/Add A Member</label>
                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="d-flex"
                                                style="border: 2px solid orange; border-radius: 5px; padding: 3px;">
                                                <input type="text" id="search-input" placeholder="Search player"
                                                    class="form-control" style="border: none; flex: 1;">
                                                <select id="user-select" class="form-control"
                                                    style="border: none; flex: 1;"></select>
                                            </div>
                                            <span id="player_error"></span>
                                        </div>

                                        <div class="col-md-5 py-2 py-md-0">
                                            <button type="btn" class="btn btn-primary" id="new_member_button">
                                                <span>Add New Member</span>
                                                <i class="ti ti-circle-plus"></i>
                                            </button>
                                        </div>

                                        <div id="new_member">
                                            <div class="p-4 border rounded mt-4" id="new_member_content"
                                                style="display: none">
                                                <div class="row">
                                                    <div class="col-12 mt-3">
                                                        <label for="full_name">Full Name
                                                            <b class="text-danger">*</b>
                                                        </label>
                                                        <input type="text" class="form-control" id="full_name"
                                                            name="full_name">
                                                        <span class="text-danger text-uppercase"
                                                            id="full_name_error"></span>
                                                    </div>

                                                    <div class="col-12 mt-3">
                                                        <label for="birth_date">Birth Date
                                                            <b class="text-danger">*</b>
                                                        </label>
                                                        <input type="date" class="form-control" id="birth_date"
                                                            name="birth_date">
                                                        <span class="text-danger text-uppercase"
                                                            id="birth_date_error"></span>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-12 mt-3">
                                                        <label for="email">Email
                                                            <b class="text-danger">*</b>
                                                        </label>
                                                        <input type="text" class="form-control" id="email"
                                                            name="email">
                                                        <span class="text-danger text-uppercase" id="email_error"></span>
                                                    </div>

                                                    <div class="col-12 mt-3">
                                                        <label for="phone_number">Phone Number
                                                            <b class="text-danger">*</b>
                                                        </label>
                                                        <div>
                                                            <input type="tel" class="form-control"
                                                                name="phone_number" id="phone_number"
                                                                placeholder="Phone Number" required>
                                                        </div>
                                                        <span id="phone_number_error"
                                                            class="text-uppercase text-danger h6"></span>
                                                        <span id="phone_number_valid"
                                                            class="text-uppercase text-success h6"></span>
                                                        <span id="phone_err"
                                                            class="text-uppercase text-success h6"></span>
                                                    </div>
                                                </div>
                                                <div>
                                                    <button type="btn" class="btn btn-success mt-3" id="save_member">
                                                        <span>Save</span>
                                                        <i class="ti ti-device-floppy"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div id="items_labels" class="row mt-4 mb-2">
                                            <div class='col-4 text-primary text-uppercase'>name</div>
                                            <div class='col-4 text-primary text-uppercase'>price</div>
                                            <div class='col-4 text-primary text-uppercase'>quantity</div>
                                        </div>
                                        
                                        <div class="row d-flex">
                                            <div class="text-center loading">Loading...</div>
                                        </div>
                                        <div class="mt-3" id="plus_court_items">
                                        </div>
                                        <span class="items_error text-uppercase text-danger">
                                        </span>
                                    </div>

                                    <div class="row" style="border-top: 1px solid #dcdcdc">
                                        <div class="col-12 col-md-6 d-flex mt-2">
                                            <h4 class="mt-2 fw-bold">TOTAL:</h4>
                                            <h4 class="mt-2"><span class="mx-1 total_amount">0</span>$</h4>
                                        </div>
                                        <div class="col-12 col-md-6 d-flex justify-content-end mt-2">
                                            <button class="btn btn-success" id="update_purchase">
                                                Update
                                                <i class="ti ti-device-floppy"></i>
                                            </button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- SALES MODAL -->

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive rounded-2">
                        <div class="mx-4">
                            <table id="sales_items-list"
                                class="table border table-striped table-bordered display text-nowrap">
                                <thead>
                                    <!-- start row -->
                                    <tr>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">player</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">date</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">total</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">purchase</h6>
                                        </th>
                                        <th></th>
                                    </tr>
                                    <!-- end row -->
                                </thead>
                                <tbody>
                                    <!-- start row -->
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                            </table>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {

            var player_id = <?php echo e(request()->id ?? 'null'); ?>;
            var sale_id;
            var country_code;
            var valid_number;
            var total_amount = 0;

            // Get the current year
            const currentYear = new Date().getFullYear();

            // Set the max and min years
            const max = currentYear - 6;
            const minYear = currentYear - 80;

            const date_min = moment().set({
                year: minYear,
                month: 11, // Note that month values are zero-based
                date: 31,
            });

            const date_max = moment().set({
                year: max,
                month: 11, // Note that month values are zero-based
                date: 31,
            });

            $('#birth_date').attr('min', date_min.format('YYYY-MM-DD'));
            $('#birth_date').attr('max', date_max.format('YYYY-MM-DD'));

            // Initialize the intlTelInput plugin on the phone number input field
            var input = $("#phone_number");
            var phone_error = $('#phone_number_error');
            var phone_valid = $('#phone_number_valid');

            input.intlTelInput({
                preferredCountries: ["lb"],
                separateDialCode: true,
                utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.1.7/js/utils.js"
            });

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#sales_items-list').DataTable({
                processing: true,
                serverSide: true,
                // scrollY: '100%',
                // scrollX: $(window).width() <= 1740,
                // scrollCollapse: true,
                // paging: true,
                responsive: true,
                "ajax": {
                    "url": "<?php echo e(route('sales_items.index')); ?>?id=" + player_id,
                    "type": "get",
                },
                columns: [{
                        data: 'player',
                        name: 'player'
                    },
                    {
                        data: 'date',
                        name: 'date',
                        order: [
                            [0, 'desc']
                        ]
                    },
                    {
                        data: 'total',
                        name: 'total'
                    },
                    {
                        data: 'is_paid',
                        name: 'is_paid',
                        className: 'text-danger'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    },
                ],
                // order: [0, 'desc'],
            });

            input.on("keyup change", function() {
                $('#phone_err').empty();
                var hasNonDigits = /[^\d]/.test(input.val());
                if (!hasNonDigits) {
                    // the phone number is valid
                    phone_error.html('').removeClass('err');
                    valid_number = input.intlTelInput("getNumber");
                    country_code = input.intlTelInput("getSelectedCountryData").dialCode;
                } else {
                    phone_error.html('Not Valid X').addClass('err');
                    phone_valid.html('')
                }
            });

            var selectedItems = [];
            $(document).on('keyup', '#search_items', function(e) {
                var search_input = $('#search_items').val();
                if (search_input.length >= 0) {
                    $.ajax({
                        url: "<?php echo e(route('courtitems.search_by_court')); ?>",
                        data: {
                            name: search_input
                        },
                        type: 'POST',
                        success: function(response) {
                            if (response.success) {
                                $('.items_container').empty();
                                for (let index = 0; index < response.data.length; index++) {

                                    const element = response.data[index];
                                    var phpurl = "<?php echo e(url('')); ?>";

                                    if (element.img != null && element.img != '') {
                                        var img = phpurl + '/' + element.img;
                                    } else {
                                        var img = phpurl + '/public/images/courts/no-image.png';
                                    }
                                    $('.items_container').append(
                                        `<li>
                                    <a href="javascript:void(0)"
                                    class="px-4 py-3 bg-hover-light-black d-flex align-items-center click_item"
                                    data-item-price="${element.price}"
                                    data-item-id="${element.item_id}" 
                                    data-item-name="${element.name}">
                                    <span class="position-relative">
                                    <img src="${img}"
                                    alt="user2" width="40" height="40"
                                    class="rounded-circle border">
                                   </span>
                                    <div class="ms-6 d-inline-block w-75">
                                    <h6 class="mb-1 fw-semibold chat-title"
                                    data-item-name="${element.name}">
                                    ${element.name}</h6>
                                    </div>
                                    </a>
                                    </li>`);
                                }
                            }
                        }
                    })
                }
            });

            $(document).on('click', '.click_item', function(e) {
                var item_id = $(this).data('item-id');
                var price = $(this).data('item-price');
                var name = $(this).data('item-name');
                if (selectedItems.includes(item_id)) {
                    console.log('no');
                } else {
                    $('#plus_court_items').append(`
                            <div class="row mb-2 item d-flex align-items-center">
                                <div class="col-3">
                                    ${name}
                                    </div>
                                <div class="col-4">
                                    <input class="price_item form-control" value="${price}" type="number">
                                    <input class="item_id" type="hidden" value="${item_id}"/>
                                    <input class="id" type="hidden" value="0"/>
                                </div>
                                <div class="col-4">
                                    <input value="1" type="number" class="qty_hour form-control"/>
                                </div>
                                <div class="col-1">
                                    <i class="ti ti-trash fs-3 text-danger cursor-pointer"></i>
                                </div>
                            </div>
                        `);
                    // Add the item to the selectedItems array and disable the li element
                    selectedItems.push(item_id);

                    //calculate the total amount
                    total_amount += price;
                    $('.total_amount').text(total_amount.toFixed(2));
                }
            });

            $('#search-input').on('input', function() {
                var query = $(this).val();
                if (query.length >= 2) {
                    $.ajax({
                        url: "<?php echo e(route('players.search')); ?>",
                        data: {
                            query: query
                        },
                        success: function(data) {
                            if (data.success) {
                                // $('#new_member_button').css('display', 'none');
                                $('#new_member_content').css('display', 'none');
                                $('#user-select').empty();
                                $.each(data.data, function(key, user) {
                                    $('#user-select').append($('<option>', {
                                        value: user.id,
                                        text: user.full_name
                                    }));
                                });
                            } else {
                                $('#user-select').empty();
                                $('#user-select').append($('<option>', {
                                    value: 0,
                                    text: 'no member match'
                                }));
                                $('#new_member_button').css('display', 'block');
                            }
                        }
                    });
                }
            });

            $(document).on('click', '#new_member_button', function(e) {
                $('#new_member_content').css('display', 'block');
                $('#phone_number_valid').empty()
                $('#full_name').val('')
                $('#birth_date').val('')
                $('#email').val('')
                $('#phone_number').val('')
            });

            const full_name = document.querySelector('#full_name');
            const full_nameValidation = document.querySelector('#full_name_error');

            full_name.addEventListener('keyup', function() {
                fullnamecheck()
            });

            //add new member
            var save_member = document.querySelector('#save_member');
            $(document).on('click', '#save_member', function(e) {

                $('#birth_date_error').empty();
                $('#email_error').empty();
                $('#phone_err').empty();

                var dateInput = $('#birth_date').val();
                var full_name = $('#full_name').val();
                var birth_date = $('#birth_date').val();
                var email = $('#email').val();
                var country_c = country_code
                var phone_number = $('#phone_number').val().replace(/\s/g, "");
                const isValid = validateDateInput(dateInput);
                const isEmailValid = isValidEmail(email);

                if (phone_number == '' || phone_number == 0 || phone_number == null) {
                    $('#phone_err').append(
                        '<span class="err text-danger text-uppercase">required !!</span>');
                } else {
                    $('#phone_err').empty();
                }
                fullnamecheck()

                if (isEmailValid) {
                    $('#email_error').empty();
                } else {
                    $('#email_error').append(
                        `<span class="err">email is invalid</span>`
                    );
                }

                if (isValid) {
                    $('#birth_date_error').empty();
                } else {
                    $('#birth_date_error').append(
                        `<span class="err">date should not be less than ${minYear} and not more than ${max}</span>`
                    );
                }

                if ($('.err').length == 0) {
                    saveButton.disabled = true;
                    $.ajax({
                        url: "<?php echo e(route('players.check_email')); ?>",
                        data: {
                            email: email,
                            phone: phone_number
                        },
                        type: 'POST',
                        success: function(data) {
                            if (data.success) {
                                storeplayer(full_name, email, phone_number, country_c,
                                    birth_date, from_sales_page = true)
                            } else {
                                swal({
                                    title: 'EMAIL OR PHONE NUMBER IS REPEATED !',
                                    icon: 'warning'
                                })
                                saveButton.disabled = false;
                            }
                        }

                    })
                }
            });

            function fullnamecheck() {
                const full_nameValue = full_name.value.trim();
                if (full_nameValue.length > 30) {
                    full_nameValidation.textContent = 'full name must not be longer than 30 characters';
                    full_nameValidation.classList.add('err');
                } else if (full_nameValue.length < 3) {
                    full_nameValidation.textContent = 'full name must be 3 characters or more';
                    full_nameValidation.classList.add('err');
                } else {
                    full_nameValidation.textContent = '';
                    full_nameValidation.classList.remove('err');
                }
            }

            function isValidEmail(email) {
                // Regular expression pattern for matching email addresses
                const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

                // Use the test() method of the pattern to check if the email address matches
                return pattern.test(email);
            }

            // Create a function to validate the date input
            function validateDateInput(dateInput) {
                // Convert the date input to a Date object
                const date = new Date(dateInput);

                // Check if the year is within the allowed range
                const year = date.getFullYear();
                if (year > max || year < minYear) {
                    return false;
                }

                // Check if the date is valid
                if (isNaN(date.getTime())) {
                    return false;
                }

                // If all checks pass, return true
                return true;
            }

            // Add a click event listener to the trash icon
            $('#plus_court_items').on('click', '.ti-trash', function() {
                // Get the parent element of the trash icon
                var item = $(this).closest('.item');
                // Get the ID of the item from the hidden input field
                var id = item.find('.id').val();
                var item_id = item.find('.item_id').val();
                var item_price = item.find('.price_item').val()
                var item_qty = item.find('.qty_hour').val()
                var each_item_total = item_price * item_qty;

                // Remove the item from the selectedItems array
                var index = selectedItems.indexOf(parseInt(item_id));
                if (index > -1) {
                    selectedItems.splice(index, 1);
                    // Remove the item from the DOM
                    item.remove();
                    total_amount -= parseFloat(each_item_total);
                    $('.total_amount').text(total_amount.toFixed(2));
                }
            });

            $(document).on('input', '.qty_hour', function(e) {
                total_amount = 0;
                console.log('kdkdk');
                var value = $(this).val();
                if (value < 1 || isNaN(value) || !value) {
                    $(this).val(1);
                    return;
                }
                $('.item').each(function() {
                    var price = parseFloat($(this).find('.price_item').val());
                    var quantity = parseInt($(this).find('.qty_hour').val());
                    var item_price = parseFloat(price) * parseInt(quantity);
                    total_amount += parseFloat(item_price);
                });
                $('.total_amount').text(total_amount.toFixed(2))
            });

            $(document).on('input change', '.price_item', function(e) {
                total_amount = 0;
                var value = parseInt($(this).val());
                if (value < 0 || isNaN(value)) {
                    $(this).val(0);
                    return;
                }
                $('.item').each(function() {
                    var price = parseFloat($(this).find('.price_item').val());
                    var quantity = parseInt($(this).find('.qty_hour').val());
                    var item_price = parseFloat(price) * parseInt(quantity);
                    total_amount += parseFloat(item_price);
                });
                $('.total_amount').text(total_amount.toFixed(2))
            });

            //save new purchase
            $(document).on('click', '#update_purchase', function(e) {

                //reset errors 
                $('.items_error').empty();
                $('.date_error').empty();

                var player_id = $('#user-select').val();
                var date = $('#date_').val();
                var formatted_date = moment($('#date_').val(), 'MM/DD/YYYY').format('YYYY-MM-DD');
                var today = moment(); // Current date
                var selectedDate = moment(formatted_date);
                var is_paid = $('input[name="paid_unpaid"]:checked').val();

                // create an empty array to hold the items
                var items = [];
                // loop through each div element with the "item" class
                if ($('.item').length > 0) {

                    $(".item").each(function() {
                        // get the name and price from the span elements in the div element
                        var id = $(this).find(".id").val();
                        var item_id = $(this).find(".item_id").val();
                        var price = $(this).find(".price_item").val();
                        var qty_hour = $(this).find('.qty_hour').val();

                        // create an object with the name and price properties
                        var item = {
                            id: id,
                            sale_id: sale_id,
                            item_id: item_id,
                            price: price,
                            qty_hour: qty_hour,
                        };
                        // add the object to the items array
                        items.push(item);
                    });
                }
                

                if (formatted_date == 'Invalid date' || selectedDate.isAfter(today)) {
                    $('.date_error').append(
                        '<span class="err">Date is required and should be today or less</span>');
                } else {
                    $('.date_error').empty();
                }

                if (items.length == 0) {
                    $('.items_error').append(
                        '<span class="err">you should choose at least one item!!</span>');
                } else {
                    $('.items_error').empty();
                }

                if ($('.err').length == 0) {
                    $.ajax({
                        url: "<?php echo e(route('sales_items.update')); ?>",
                        data: {
                            sale_id: sale_id,
                            player_id: player_id ? player_id : null,
                            date: formatted_date,
                            items: items,
                            is_paid: is_paid == 'paid' ? 1 : 0
                        },
                        type: 'POST',
                        success: function(response) {
                            if (response.success) {
                                swal({
                                    title: 'Success',
                                    text: response.msg,
                                    icon: 'success'
                                }).then(() => {
                                    location.reload()
                                })
                            }
                        }
                    })
                } else {
                    console.log('Missing Fields');
                }

            });

            $(document).on('click', '#search_sales_items', function(e) {
                console.log('djdjjdjd');
                var date_from = $('#date_from').val();
                var formatted_from = moment(date_from, 'MM/DD/YYYY').format('YYYY-MM-DD');
                var date_to = $('#date_to').val();
                var formatted_to = moment(date_to, 'MM/DD/YYYY').format('YYYY-MM-DD');
                if (date_from && date_to && date_from != '' && date_to != '') {
                    console.log('kdkdkkdk');
                    table.ajax.url("<?php echo e(route('sales_items.index')); ?>?id="+player_id+"&date_from="+formatted_from+
                        "&date_to=" + formatted_to).load();
                } else {
                    table.ajax.url("<?php echo e(route('sales_items.index')); ?>?id="+player_id).load();
                }
            })

            $(document).on('click', '#clear_dates', function(e) {
                $('#date_from').val('')
                $('#date_to').val('')
            })

            $(document).on('click', '.edit_sale', function(e) {

                $('#user-select').empty();
                $('#plus_court_items').empty()
                $('#plus_court_items').css('display', 'none')

                var date = $(this).data('date');
                var formatted_date = moment(date, 'YYYY-MM-DD').format('MM/DD/YYYY');
                var is_paid = $(this).data('is-paid');
                var check_paid = is_paid == 1 ? 'paid' : 'unpaid';
                var player_id = $(this).data('player-id');
                var player_name = $(this).data('player-name');
                total_amount = $(this).data('total');
                sale_id = $(this).data('sale-id');

                $('#date_').val(formatted_date)
                $('input[name="paid_unpaid"]').filter(`[value=${check_paid}]`).prop('checked', true)
                $('#user-select').append($('<option>', {
                    value: player_id,
                    text: player_name
                }).prop('selected', true))
                $('.total_amount').text(total_amount.toFixed(2))
                getitems(sale_id);

            });

            function getitems(sale_id) {
                if (sale_id) {
                    $.ajax({
                        url: "<?php echo e(route('sales_items.get_sales_items')); ?>",
                        data: {
                            sale_id: sale_id
                        },
                        success: function(response) {
                            if (response.success) {
                                var items = response.data;
                                items.forEach(element => {
                                    selectedItems.push(element.item_id);
                                    $('#plus_court_items').append(`
                                    <div class="row mb-2 item d-flex align-items-center">
                                    <div class="col-3">
                                    ${element.name}
                                    </div>
                                    <div class="col-4">
                                        <input class="price_item form-control" value="${element.unit_price}" type="number">
                                        <input class="id" type="hidden" value="${element.id}"/>
                                        <input class="item_id" type="hidden" value="${element.item_id}"/>
                                        <input class="sale_id" type="hidden" value="${sale_id}"/>
                                    </div>
                                    <div class="col-4">
                                        <input value="${element.qty}" type="number" class="qty_hour form-control"/>
                                    </div>
                                    <div class="col-1">
                                        <i class="ti ti-trash fs-3 text-danger cursor-pointer"></i>
                                    </div>
                                    </div>
                                    `);
                                    $('.loading').css('display', 'none')
                                    $('#plus_court_items').css('display', 'block')
                                });
                            }
                        }
                    })
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/sales_items/index.blade.php ENDPATH**/ ?>