
<?php $__env->startSection('title', 'Courts'); ?>

<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <div class="d-flex justify-content-between">
            <ol class="breadcrumb border border-warning px-3 py-2 rounded">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                            class="ti ti-home fs-4 mt-1"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="#" class="text-warning">Courts</a>
                </li>
            </ol>

            <div>
                <a type="button" class="btn mb-1 waves-effect waves-light btn-light text-dark fs-4" href="<?php echo e(route('courts.addcourtpage')); ?>">
                    <i class="ti ti-circle-plus"></i>
                    <span>Add New Court</span>
                </a>
            </div>
        </div>
    </nav>

    
    <div id="add_new_sport" class="modal fade" tabindex="-1" aria-labelledby="add_new_sport" aria-hidden="true">
        <div class="modal-dialog">
            <form action="<?php echo e(route('courts.sportstore')); ?>" method="POST" id="add_court_form">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header d-flex align-items-center">
                        <h4 class="modal-title" id="myModalLabel">
                            Add New Sport
                        </h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <h5 id="court_title" class="text-warning"></h5>
                        <input type="hidden" name="court_id" id="court_id">

                        <div class="my-2">
                            <label class="block">
                                <span>Sport Type<b style="color: #e86945">*</b></span>
                                <select class="form-control my-1" name="sport_id" id="sport_type">
                                    <option disabled value="0" selected>--Select Sport--</option>
                                    <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($sport->id); ?>"><?php echo e($sport->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span id="sport_error"></span>
                            </label>
                        </div>

                        <div class="my-2">
                            <label for="capacity" class="block my-1">Capacity</label>
                            <b style="color: #e86945">*</b>
                            <input type="number" class="form-control" name="capacity" id="capacity">
                            <span id="capacity_error"></span>
                            <span id="capacity_error_number"></span>
                        </div>

                        <div class="my-2">
                            <label for="session_price" class="block my-1">
                                <span>Session Price</span>
                                <i class=" ti ti-currency-dollar"></i>
                            </label>
                            <b style="color: #e86945">*</b>
                            <input type="number" class="form-control" name="session_price" id="session_price">
                            <span id="session_price_error"></span>
                            <span id="session_price_number"></span>
                        </div>

                        <div class="my-2">
                            <label for="session_minutes" class="block my-1">Duration</label>
                            <b style="color: #e86945">*</b>
                            <input id="demo6" type="text" value="30" name="demo6" />
                            <span id="session_minutes_error"></span>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light-danger text-danger font-medium waves-effect"
                            data-bs-dismiss="modal">
                            Close
                        </button>

                        <button class="btn btn-success px-4" id="save">
                            <div class="d-flex align-items-center">
                                <i class="ti ti-device-floppy me-1 fs-4"></i>
                                Save
                            </div>
                        </button>
                    </div>
                </div>
            </form>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="my-2">

                        <div class="table-responsive">
                            <table id="courts-list" class="table border table-striped table-bordered display text-nowrap">
                                <thead>
                                    <!-- start row -->
                                    <tr>
                                        <th>#</th>
                                        <th>Image</th>
                                        <th>Title</th>
                                        <th>Sport(s)</th>
                                        <th>Is Active</th>
                                        <th>Action</th>
                                    </tr>
                                    <!-- end row -->
                                </thead>
                                <tbody>
                                    <!-- start row -->
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                            </table>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>


    <?php $__env->stopSection(); ?>

    <?php $__env->startPush('after-scripts'); ?>
        <script>
            $(document).ready(function() {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                var table = $('#courts-list').DataTable({
                    processing: true,
                    serverSide: true,
                    // scrollY: '100%',
                    // scrollX: $(window).width() <= 831,
                    // scrollCollapse: true,
                    // paging: true,
                    responsive: true,
                    ajax: "<?php echo e(route('courts.index')); ?>",
                    columns: [{
                            data: 'id',
                            id: 'id'
                        },
                        {
                            data: "image",
                            name: 'image',
                            searchable:false,
                            orderable:false
                        },
                        {
                            data: 'title_en',
                            name: 'title_en'
                        },
                        {
                            data: 'addsport',
                            name: 'addsport',
                            searchable:false,
                            orderable:false
                        },
                        {
                            data: 'is_active',
                            name: 'is_active'
                        },
                        {
                            data: 'actions',
                            name: 'actions',
                            orderable: false,
                            searchable: false,
                            className: "text-center"
                        },
                    ],
                    order: [0, 'desc'],
                });

                //click button 
                $(document).on('click', '.add_sport_click', function(e) {
                    $('#session_minutes_error').empty();
                    $('#session_price_error').empty();
                    $('#capacity_error').empty();
                    $('#sport_error').empty();
                    $('#session_minutes').val('');
                    $('#session_price').val('');
                    $('#title').val('');
                    $('#capacity').val('');
                    $('#sport_type').val(0);
                    $('#court_id').val($(this).data('id'))
                    $('#court_title').text($(this).data('title'))
                    // $('#').val(30)
                })


                //onsubmit button 
                $('#save').on('click', function(e) {
                    e.preventDefault();
                    // $(this).prop('disabled', true);
                    $('#session_minutes_error').empty();
                    $('#session_price_error').empty();
                    $('#capacity_error').empty();
                    $('#sport_error').empty();
                    $('#capacity_error_number').empty()
                    $('#session_price_number').empty()

                    var session_minutes = $('#demo6').val();
                    var session_price = $('#session_price').val()
                    var title = $('#title').val();
                    var capacity = $('#capacity').val();
                    var sport_id = $('#sport_type').val()

                    if (!capacity) {
                        $('#capacity_error').append(
                            '<span style="color:#e86945" class="err"><b>CAPACITY IS REQUIRED!</b></span>')
                    }else{
                        $('#capacity_error').empty();
                    }

                    if (capacity < 1) {
                        $('#capacity_error_number').append(
                            '<span style="color:#e86945" class="err"><b>NUMBER SHOULD BE BIGGER THAN 0!</b></span>')
                    }else{
                        $('#capacity_error_number').empty()
                    }

                    if (!session_minutes || parseFloat(session_minutes) < 30) {
                        $('#session_minutes_error').append(
                            '<span style="color:#e86945" class="err"><b>SESSION TIME IS REQUIRED AND NOT LESS THAN 30 MIN</b></span>'
                        )
                    }else{
                        $('#session_minutes_error').empty();
                    }

                    if (!session_price) {
                        $('#session_price_error').append(
                            '<span style="color:#e86945" class="err"><b>SESSION PRICE IS REQUIRED!</b></span>'
                        )
                    }else{
                        $('#session_price_error').empty()
                    }

                    if (session_price <= 0) {
                        $('#session_price_number').append(
                            '<span style="color:#e86945" class="err"><b>NUMBER SHOULD BE BIGGER THAN 0 !</b></span>'
                        )
                    }else{
                        $('#session_price_number').empty()
                    }

                    if (sport_id == 0 || sport_id == null) {
                        $('#sport_error').append(
                            '<span style="color:#e86945" class="err"><b>SPORT TYPE IS REQUIRED!</b></span>'
                        )
                    }else{
                        $('#sport_error').empty()
                    }

                    if ($('.err').length == 0) {
                        $('#add_court_form').submit()
                        $(this).prop('disabled', true);
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sportcietyapp/public_html/platform.sportcietyapp.com/resources/views/courts/index.blade.php ENDPATH**/ ?>