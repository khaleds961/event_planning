<div class="dropdown">
    <a href="javascript:void(0)" id="nft3" data-bs-toggle="dropdown" aria-expanded="false">
        <i class="ti ti-dots fs-4"></i>
    </a>

    <ul class="dropdown-menu" aria-labelledby="nft3">

        

        <?php if(Helper::check_permission($function_id, 'is_update')): ?>
            <li>
                <a href="<?php echo e(route('courts.show', ['id' => $row->id])); ?>"
                    class="dropdown-item d-flex align-items-center">
                    <i class="ti ti-pencil me-1 fs-6"></i>
                    <span class="mx-3">Edit Court</span>
                </a>
            </li>
        <?php endif; ?>

        <?php if(Helper::check_permission($function_id, 'is_update')): ?>
            <li>
                <a href="<?php echo e(route('calendar.index', ['id' => $row->id])); ?>"
                    class="dropdown-item d-flex align-items-center">
                    <i class="ti ti-calendar me-1 fs-6"></i>
                    <span class="mx-3">Schedule</span>
                </a>
            </li>
        <?php endif; ?>

        

        <?php if(Helper::check_permission($function_id, 'is_delete')): ?>
            <ul>
                <li>
                    <a class="dropdown-item d-flex align-items-center show_confirm_court text-warning delete_icon"
                        data-id="<?php echo e($row->id); ?>" data-table_name="<?php echo e($table_name); ?>" style="cursor: pointer">
                        <i class="ti ti-trash me-1 fs-6"></i>
                        <span class="mx-3">Delete Court</span>
                    </a>
                </li>
            </ul>
        <?php endif; ?>
    </ul>
</div>
</ul>

<script>
    $(document).ready(function() {
        $('.dropify').dropify();
    });
</script>
<?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/courts/courts_actions.blade.php ENDPATH**/ ?>