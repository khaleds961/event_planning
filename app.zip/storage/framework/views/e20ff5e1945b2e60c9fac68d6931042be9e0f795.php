
<?php $__env->startSection('title', 'Clients'); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
      <h4 class="card-title mb-0">Basic Example</h4>
      <h6 class="card-subtitle mb-3"></h6>
      <div id="example-basic" class="mt-5">
        <h3>Keyboard</h3>
        <section>
          <p> Try the keyboard navigation by clicking arrow left or right! </p>
        </section>
        <h3>Effects</h3>
        <section>
          <p>Wonderful transition effects.</p>
        </section>
        <h3>Pager</h3>
        <section>
          <p> The next and previous buttons help you to navigate through your content. </p>
        </section>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script src="<?php echo e(asset('dist/libs/jquery-steps/build/jquery.steps.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dist/libs/jquery-validation/dist/jquery.validate.min.js')); ?>"></script> 
    <script src="<?php echo e(asset('dist/js/forms/form-wizard.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\sportciety_club\resources\views/clients/testhere.blade.php ENDPATH**/ ?>