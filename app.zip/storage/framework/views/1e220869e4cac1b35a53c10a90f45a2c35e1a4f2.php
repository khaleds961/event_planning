
<?php $__env->startSection('title', 'Booking'); ?>
<?php $__env->startSection('content'); ?>

    

    <div class="row">
        <div class="col-12 col-md-4">
            <div class="user-chat-box h-100" style="border: 1px solid #DCDCDC">
                <div class="px-4 pt-9 pb-6 d-none d-lg-block">
                    <form class="position-relative">
                        <input type="text" class="form-control search-chat py-2 ps-5" id="search_items" placeholder="Search">
                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                    </form>
                </div>
                <div class="app-chat">
                    <ul class="chat-users" style="height: calc(100vh - 400px)" data-simplebar="init">
                        <div class="simplebar-wrapper" style="margin: 0px;">
                            <div class="simplebar-height-auto-observer-wrapper">
                                <div class="simplebar-height-auto-observer"></div>
                            </div>
                            <div class="simplebar-mask">
                                <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                                    <div class="simplebar-content-wrapper" tabindex="0" role="region"
                                        aria-label="scrollable content" style="height: 100%; overflow: hidden scroll;">
                                        <div class="simplebar-content" style="padding: 0px;">
                                            <div class="items_container">
                                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="javascript:void(0)"
                                                            class="px-4 py-3 bg-hover-light-black d-flex align-items-center chat-user"
                                                            id="chat_user_5" data-user-id="5">
                                                            <span class="position-relative">
                                                                <img src="<?php echo e($item->img != null && $item->img != ''
                                                                    ? url('') . '/' . $item->img
                                                                    : url('') . '/public/images/courts/no-image.png'); ?>"
                                                                    alt="user2" width="40" height="40"
                                                                    class="rounded-circle">
                                                            </span>
                                                            <div class="ms-6 d-inline-block w-75">
                                                                <h6 class="mb-1 fw-semibold chat-title"
                                                                    data-name="<?php echo e($item->name); ?>">
                                                                    <?php echo e($item->name); ?></h6>
                                                            </div>
                                                        </a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="simplebar-placeholder" style="width: auto; height: 720px;"></div>
                        </div>
                        <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                            <div class="simplebar-scrollbar" style="width: 0px; display: none;"></div>
                        </div>
                        <div class="simplebar-track simplebar-vertical" style="visibility: visible;">
                            <div class="simplebar-scrollbar"
                                style="height: 440px; transform: translate3d(0px, 0px, 0px); display: block;">
                            </div>
                        </div>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-8">

            <div class="row">
                <div class="col-md-12">
                    <div class="d-flex" style="border: 2px solid orange; border-radius: 5px; padding: 5px;">
                        <input type="text" id="search-input" placeholder="Search player by name" class="form-control"
                            style="border: none; flex: 1;">
                        <select id="user-select" class="form-control" style="border: none; flex: 1;"></select>
                    </div>
                    <span id="player_error"></span>
                </div>

                <div id="new_member">

                    <button type="btn" class="btn btn-primary mt-3" style="display: none" id="new_member_button">
                        <span>Add New Member</span>
                        <i class="ti ti-circle-plus"></i>
                    </button>

                    <div class="p-4 border rounded mt-4" id="new_member_content" style="display: none">
                        <div class="row">
                            <div class="col-md-6 mt-3">
                                <label for="full_name">Full Name
                                    <b class="text-danger">*</b>
                                </label>
                                <input type="text" class="form-control" id="full_name" name="full_name">
                                <span class="text-danger text-uppercase" id="full_name_error"></span>
                            </div>

                            <div class="col-md-6 mt-3">
                                <label for="birth_date">Birth Date
                                    <b class="text-danger">*</b>
                                </label>
                                <input type="date" class="form-control" id="birth_date" name="birth_date">
                                <span class="text-danger text-uppercase" id="birth_date_error"></span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mt-3">
                                <label for="email">Email
                                    <b class="text-danger">*</b>
                                </label>
                                <input type="text" class="form-control" id="email" name="email">
                                <span class="text-danger text-uppercase" id="email_error"></span>
                            </div>

                            <div class="col-md-6 mt-3">
                                <label for="phone_number">Phone Number
                                    <b class="text-danger">*</b>
                                </label>
                                <div>
                                    <input type="tel" class="form-control" name="phone_number" id="phone_number"
                                        placeholder="Phone Number" required>
                                </div>
                                <span id="phone_number_error" class="text-uppercase text-danger h6"></span>
                                <span id="phone_number_valid" class="text-uppercase text-success h6"></span>
                                <span id="phone_err" class="text-uppercase text-success h6"></span>
                            </div>


                        </div>


                        <div>
                            <button type="btn" class="btn btn-success mt-3" id="save_member">
                                <span>Save</span>
                                <i class="ti ti-device-floppy"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#bookings-list').DataTable({
                processing: true,
                serverSide: true,
                scrollY: '100%',
                scrollCollapse: true,
                paging: true,
                responsive: true,
                ajax: "<?php echo e(route('sales.index')); ?>",
                columns: [{
                        data: 'player',
                        name: 'player'
                    },
                    {
                        data: 'paid',
                        name: 'paid',
                        className: 'text-success'
                    },
                    {
                        data: 'unpaid',
                        name: 'unpaid',
                        className: 'text-danger'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    },
                ],
                order: [0, 'desc'],
            });

            var selectedItems = [];
            $(document).on('keyup', '#search_items', function(e) {
                var search_input = $('#search_items').val();
                if (search_input.length >= 0) {
                    $.ajax({
                        url: "<?php echo e(route('courtitems.search_by_court')); ?>",
                        data: {
                            name: search_input
                        },
                        type: 'POST',
                        success: function(response) {
                            if (response.success) {
                                $('.items_container').empty();
                                for (let index = 0; index < response.data.length; index++) {
                                    const element = response.data[index];
                                    var phpurl = "<?php echo e(url('')); ?>";
                                    if (element.img != null && element.img != '') {
                                        var img = phpurl + '/' + element.img;
                                    } else {
                                        var img = phpurl + '/public/images/courts/no-image.png';
                                    }
                                    selectedItems.push(element.id);
                                    $('.items_container').append(
                                        `<li>
                                    <a href="javascript:void(0)"
                                    class="px-4 py-3 bg-hover-light-black d-flex align-items-center chat-user"
                                    id="chat_user_5" data-user-id="5">
                                    <span class="position-relative">
                                    <img src="${img}"
                                    alt="user2" width="40" height="40"
                                    class="rounded-circle">
                                   </span>
                                    <div class="ms-6 d-inline-block w-75">
                                    <h6 class="mb-1 fw-semibold chat-title"
                                    data-name="${element.name}">
                                    ${element.name}</h6>
                                    </div>
                                    </a>
                                    </li>`);
                                }
                            }
                        }
                    })
                }
            });

            $('#search-input').on('input', function() {
                var query = $(this).val();
                if (query.length >= 2) {
                    $.ajax({
                        url: "<?php echo e(route('players.search')); ?>",
                        data: {
                            query: query
                        },
                        success: function(data) {
                            if (data.success) {
                                $('#new_member_button').css('display', 'none');
                                $('#new_member_content').css('display', 'none');
                                $('#user-select').empty();
                                $.each(data.data, function(key, user) {
                                    $('#user-select').append($('<option>', {
                                        value: user.id,
                                        text: user.full_name
                                    }));
                                });
                            } else {
                                $('#user-select').empty();
                                $('#user-select').append($('<option>', {
                                    value: 0,
                                    text: 'no member match'
                                }));
                                $('#new_member_button').css('display', 'block');
                            }
                        }
                    });
                }
            });

            $(document).on('click', '#new_member_button', function(e) {
                $('#new_member_content').css('display', 'block');
                $('#phone_number_valid').empty()
                $('#full_name').val('')
                $('#birth_date').val('')
                $('#email').val('')
                $('#phone_number').val('')
            });

            //add new member
            var save_member = document.querySelector('#save_member');
            $(document).on('click', '#save_member', function(e) {

                $('#birth_date_error').empty();
                $('#email_error').empty();
                $('#phone_err').empty();

                var dateInput = $('#birth_date').val();
                var full_name = $('#full_name').val();
                var birth_date = $('#birth_date').val();
                var email = $('#email').val();
                var country_c = country_code
                var phone_number = $('#phone_number').val().replace(/\s/g, "");
                const isValid = validateDateInput(dateInput);
                const isEmailValid = isValidEmail(email);

                if (phone_number == '' || phone_number == 0 || phone_number == null) {
                    $('#phone_err').append(
                        '<span class="err text-danger text-uppercase">required !!</span>');
                } else {
                    $('#phone_err').empty();
                }
                fullnamecheck()

                if (isEmailValid) {
                    $('#email_error').empty();
                } else {
                    $('#email_error').append(
                        `<span class="err">email is invalid</span>`
                    );
                }

                if (isValid) {
                    $('#birth_date_error').empty();
                } else {
                    $('#birth_date_error').append(
                        `<span class="err">date should not be less than ${minYear} and not more than ${maxYear}</span>`
                    );
                }

                if ($('.err').length == 0) {
                    saveButton.disabled = true;
                    $.ajax({
                        url: "<?php echo e(route('players.check_email')); ?>",
                        data: {
                            email: email,
                            phone: phone_number
                        },
                        type: 'POST',
                        success: function(data) {
                            if (data.success) {
                                storeplayer(full_name, email, phone_number, country_c,
                                    birth_date)
                            } else {
                                swal({
                                    title: 'EMAIL OR PHONE NUMBER IS REPEATED !',
                                    icon: 'warning'
                                })
                                saveButton.disabled = false;
                            }
                        }

                    })
                }
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/sales/index_.blade.php ENDPATH**/ ?>