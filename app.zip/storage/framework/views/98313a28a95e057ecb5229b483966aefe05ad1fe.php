
<?php $__env->startSection('title', 'Staff'); ?>
<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <ol class="breadcrumb border border-warning px-3 py-2 rounded">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                        class="ti ti-home fs-4 mt-1"></i></a>
            </li>
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('staff.index')); ?>" class="text-warning">Staff</a>
            </li>
            <li class="breadcrumb-item">
                <a href="#" class="text-warning">Add New Member</a>
            </li>
        </ol>
    </nav>


    <div class="row">
        <div class="col-12 mt-4">
            <form action="<?php echo e(route('staff.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-body p-4 border-bottom">
                        <h5 class="fs-4 fw-semibold mb-4">Account Details</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-1">
                                    <label for="exampleInputPassword1" class="form-label fw-semibold">Username<span
                                            class="text-danger fs-4"><b>*</b></span></label>
                                    <input type="text" class="form-control" id="username" required>
                                    <span id="username-validation" class="text-danger h6 text-uppercase"></span>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-1">
                                    <label for="exampleInputPassword1" class="form-label fw-semibold">Sex<span
                                            class="text-danger fs-4"><b>*</b></span></label>
                                    <select class="form-control" name="sex" id="sex">
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                    </select>
                                </div>
                            </div>

                        </div>
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <label for="password" class="form-label fw-semibold">Password<span
                                        class="text-danger fs-4"><b>*</b></span></label>
                                <div class="input-group border rounded-1 mb-1">
                                    <input type="password" class="form-control border-0" id="password" minlength="9"
                                        pattern="^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]+$" required>
                                    <span class="bg-transparent px-6 border-0" id="basic-addon1">
                                        <button class="btn" type="button" id="togglePassword">
                                            <i class="ti ti-eye fs-5 text-warning"></i>
                                        </button></span>
                                </div>
                                <span id="password-validation" class="text-danger h6 text-uppercase"></span>
                            </div>
                            <div class="col-md-6 mt-3 m-md-0">
                                <label for="confirm_password" class="form-label fw-semibold">Confirm Password<span
                                        class="text-danger fs-4"><b>*</b></span></label>
                                <div class="input-group border rounded-1 mb-1">
                                    <input type="password" class="form-control border-0" id="confirm_password"
                                        minlength="9" required>
                                    <span class="bg-transparent px-6 border-0" id="basic-addon1">
                                        <button class="btn" type="button" id="toggleConfirmPassword">
                                            <i class="ti ti-eye fs-5 text-warning"></i>
                                        </button>
                                    </span>
                                </div>
                                <span id="confirm-password-validation" class="text-danger h6 text-uppercase"></span>
                            </div>
                        </div>
                    </div>

                    <div class="card-body p-4">
                        <h5 class="fs-4 fw-semibold mb-4">Personal Info</h5>
                        <div class="row">
                            

                            <div class="col-md-6 mt-3 m-md-0">
                                <div class="mb-1">
                                    <label for="exampleInputPassword1" class="form-label fw-semibold">Full Name<span
                                            class="text-danger fs-4"><b>*</b></span></label>
                                    <input type="text" class="form-control" id="lastname" required>
                                </div>
                                <span id="lastname-validation" class="text-danger h6 text-uppercase"></span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mt-3">
                                <div class="mb-1">
                                    <label for="user_type" class="form-label fw-semibold">User Type<span
                                            class="text-danger fs-4"><b>*</b></span></label>
                                    <div>
                                        <select name="user_type" id="user_type" class="form-control" required>
                                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <span id="user_type_error" class="text-uppercase text-danger h6"></span>
                            </div>

                            <div class="col-md-6 mt-3">
                                <div class="mb-1">
                                    <label for="user_salary" class="form-label fw-semibold">Salary<span
                                            class="text-danger fs-4"><b>*</b></span></label>
                                    <div>
                                        <input type="number" class="form-control" id="user_salary" required>
                                    </div>
                                </div>
                                <span id="salary_error" class="text-uppercase text-danger h6"></span>
                                <span id="salary_error_empty" class="text-uppercase text-danger h6"></span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mt-3">
                                <div class="mb-1">
                                    <label for="exampleInputPassword1" class="form-label fw-semibold">Birth Date<span
                                            class="text-danger fs-4"><b>*</b></span></label>
                                    <input id="startDate" class="form-control" type="date" required>
                                    <span id="startDate-validation" class="text-uppercase text-danger h6" type="date"
                                        required> </span>
                                </div>
                            </div>

                            <div class="col-md-6 mt-3">
                                <div class="mb-1">
                                    <label for="phone_number" class="form-label fw-semibold">Phone Number <span
                                            class="text-danger fs-4"><b>*</b></span></label>
                                    <div>
                                        <input type="tel" class="form-control" name="phone_number" id="phone_number"
                                            placeholder="Phone Number" required>
                                    </div>
                                </div>
                                <span id="phone_number_error" class="text-uppercase text-danger h6"></span>
                                <span id="phone_number_valid" class="text-uppercase text-success h6"></span>
                            </div>
                        </div>

                        <div class="col-12 mt-3">
                            <div class="d-flex align-items-center justify-content-end gap-3 mb-1">
                                <button class="btn btn-success" id="submit">Save</button>
                                <a class="btn btn-light-danger text-danger" href="<?php echo e(route('staff.index')); ?>">Cancel</a>
                            </div>
                            <span id="submit_error"></span>
                        </div>
                    </div>
                </div>
            </form>

        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        ///Date
        const start_date = document.querySelector('#startDate');
        const start_date_validation = document.querySelector('#startDate-validation');
        var currentYear = new Date().getFullYear();
        var tenYearsAgoYear = currentYear - 10;
        var date = moment(tenYearsAgoYear, "YYYY").endOf("year");
        var formattedDate = date.format("YYYY-MM-DD");
        document.getElementById('startDate').setAttribute('max', formattedDate);

        var eightyYearsAgoYear = currentYear - 80;
        var date_eighty = moment(eightyYearsAgoYear, "YYYY").startOf("year");
        var formattedDate_eighty = date_eighty.format("YYYY-MM-DD");
        document.getElementById('startDate').setAttribute('min', formattedDate_eighty);

        const password = document.querySelector('#password');
        const confirmPassword = document.querySelector('#confirm_password');
        const passwordValidation = document.querySelector('#password-validation');
        const confirmPasswordValue = confirmPassword.value;
        const confirmPasswordValidation = document.querySelector('#confirm-password-validation');

        password.addEventListener('keyup', function() {
            const passwordValue = password.value;
            if (passwordValue.length < 9) {
                passwordValidation.textContent = 'Password must be at least 9 characters';
                passwordValidation.classList.add('err');
            } else if (!passwordValue.match(/[A-Z]/)) {
                passwordValidation.textContent = 'Password must contain at least one uppercase letter';
                passwordValidation.classList.add('err');
            } else if (!passwordValue.match(/[0-9]/)) {
                passwordValidation.textContent = 'Password must contain at least one number';
                passwordValidation.classList.add('err');
            } else if (!passwordValue.match(/[!@#$%^&*]/)) {
                passwordValidation.textContent = 'Password must contain at least one special character';
                passwordValidation.classList.add('err');
            } else {
                passwordValidation.textContent = '';
                passwordValidation.classList.remove('err');
            }
        });

        confirmPassword.addEventListener('keyup', function() {
            const confirmPasswordValue = confirmPassword.value;

            if (confirmPasswordValue !== password.value) {
                confirmPasswordValidation.textContent = 'Passwords do not match';
                confirmPasswordValidation.classList.add('err');
            } else {
                confirmPasswordValidation.textContent = '';
                confirmPasswordValidation.classList.remove('err');
            }
        });

        const username = document.querySelector('#username');
        const usernameValidation = document.querySelector('#username-validation');

        username.addEventListener('keyup', function() {
            const usernameValue = username.value.trim();

            if (usernameValue.length > 20) {
                usernameValidation.textContent = 'Username must not be longer than 20 characters';
                usernameValidation.classList.add('err');
            } else if (usernameValue.length < 3) {
                usernameValidation.textContent = 'Username must be 3 characters or more';
                usernameValidation.classList.add('err');
            } else if (/\s/.test(usernameValue)) {
                usernameValidation.textContent = 'Username must not contain spaces';
                usernameValidation.classList.add('err');
            } else {
                usernameValidation.textContent = '';
                usernameValidation.classList.remove('err');
            }
        });

        // const firstname = document.querySelector('#firstname');
        // const firstnameValidation = document.querySelector('#firstname-validation');

        // firstname.addEventListener('keyup', function() {
        //     const firstnameValue = firstname.value.trim();

        //     if (firstnameValue.length > 15) {
        //         firstnameValidation.textContent = 'firstname must not be longer than 15 characters';
        //         firstnameValidation.classList.add('err');
        //     } else if (firstnameValue.length < 3) {
        //         firstnameValidation.textContent = 'firstname must be 3 characters or more';
        //         firstnameValidation.classList.add('err');
        //     } else if (/\s/.test(firstnameValue)) {
        //         firstnameValidation.textContent = 'firstname must not contain spaces';
        //         firstnameValidation.classList.add('err');
        //     } else {
        //         firstnameValidation.textContent = '';
        //         firstnameValidation.classList.remove('err');
        //     }
        // });



        const lastname = document.querySelector('#lastname');
        const lastnameValidation = document.querySelector('#lastname-validation');

        lastname.addEventListener('keyup', function() {
            const lastnameValue = lastname.value.trim();

            if (lastnameValue.length > 40) {
                lastnameValidation.textContent = 'fullname not be longer than 40 characters';
                lastnameValidation.classList.add('err');
            } else if (lastnameValue.length < 3) {
                lastnameValidation.textContent = 'fullname be 3 characters or more';
                lastnameValidation.classList.add('err');
            } else {
                lastnameValidation.textContent = '';
                lastnameValidation.classList.remove('err');
            }
        });

        var valid_number;
        var country_code;
        $(document).ready(function() {
            // Initialize the intlTelInput plugin on the phone number input field
            var input = $("#phone_number");
            var phone_error = $('#phone_number_error');
            var phone_valid = $('#phone_number_valid');

            input.intlTelInput({
                preferredCountries: ["lb"],
                separateDialCode: true,
                utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.1.7/js/utils.js"
            });

            // Add a keyup event listener to validate the phone number
            input.on("keyup change", function() {
                // var isValid = input.intlTelInput("isValidNumber");
                var hasNonDigits = /[^\d]/.test(input.val());
                // if (isValid && !hasNonDigits) {
                    if (!hasNonDigits) {
                    // phone_valid.html('Valid <i class="ti ti-check"></i>'); 
                    // the phone number is valid
                    phone_error.html('').removeClass('err');
                    valid_number = input.intlTelInput("getNumber");
                    country_code = input.intlTelInput("getSelectedCountryData").dialCode;
                } else {
                    phone_error.html('Not Valid X').addClass('err');
                    phone_valid.html('')
                }
            });
        });

        function onSubmit() {
            const passwordValue = password.value;
            const confirmPasswordValue = confirmPassword.value;
            const usernameValue = username.value.trim();
            // const firstnameValue = firstname.value.trim();
            const lastnameValue = lastname.value.trim();
            // const isValid = $("#phone_number").intlTelInput("isValidNumber");
            const hasNonDigits = /[^\d]/.test($("#phone_number").val());
            const startDateValue = $('#startDate').val()
            const phone_number = $('#phone_number').val()
            const phone_error = document.querySelector('#phone_number_error');
            const salary = document.querySelector('#user_salary');
            const salaryValue = salary.value.trim();
            const salary_validation = document.querySelector('#salary_error');
            const salary_empty = document.querySelector('#salary_error_empty');

            if (salaryValue == '' || salaryValue == 0 || salaryValue == null) {
                salary_empty.textContent = 'salary is required !';
                salary_empty.classList.add('err');
            } else {
                salary_empty.textContent = '';
                salary_empty.classList.remove('err');
            }

            if (salaryValue < 0) {
                salary_validation.textContent = 'wrong format!';
                salary_validation.classList.add('err');
            } else {
                salary_validation.textContent = '';
                salary_validation.classList.remove('err');
            }

            if (phone_number == '' || phone_number == 0 || phone_number == null) {
                phone_error.textContent = 'required';
                phone_error.classList.add('err');
            } else {
                phone_error.textContent = '';
                phone_error.classList.remove('err');
            }

            if (startDateValue > formattedDate) {
                start_date_validation.textContent = `date should not be greater than ${formattedDate}`;
                start_date_validation.classList.add('err');
            } else {
                start_date_validation.textContent = '';
                start_date_validation.classList.remove('err');
            }

            if (startDateValue < formattedDate_eighty) {
                start_date_validation.textContent = `date should not be less than ${formattedDate_eighty}`;
                start_date_validation.classList.add('err');
            } else {
                start_date_validation.textContent = '';
                start_date_validation.classList.remove('err');
            }

            if (passwordValue.length < 9) {
                passwordValidation.textContent = 'Password must be at least 9 characters';
                passwordValidation.classList.add('err');
            } else if (!passwordValue.match(/[A-Z]/)) {
                passwordValidation.textContent = 'Password must contain at least one uppercase letter';
                passwordValidation.classList.add('err');
            } else if (!passwordValue.match(/[0-9]/)) {
                passwordValidation.textContent = 'Password must contain at least one number';
                passwordValidation.classList.add('err');
            } else if (!passwordValue.match(/[!@#$%^&*]/)) {
                passwordValidation.textContent = 'Password must contain at least one special character';
                passwordValidation.classList.add('err');
            } else {
                passwordValidation.textContent = '';
                confirmPasswordValidation.classList.remove('err');
            }

            if (confirmPasswordValue !== password.value) {
                confirmPasswordValidation.textContent = 'Passwords do not match';
                confirmPasswordValidation.classList.add('err');
            } else {
                confirmPasswordValidation.textContent = '';
                confirmPasswordValidation.classList.remove('err');
            }

            if (usernameValue.length > 20) {
                usernameValidation.textContent = 'Username must not be longer than 20 characters';
                usernameValidation.classList.add('err');
            } else if (usernameValue.length < 3) {
                usernameValidation.textContent = 'Username must be 3 characters or more';
                usernameValidation.classList.add('err');
            } else if (/\s/.test(usernameValue)) {
                usernameValidation.textContent = 'Username must not contain spaces';
                usernameValidation.classList.add('err');
            } else {
                usernameValidation.textContent = '';
                usernameValidation.classList.remove('err');
            }

            // if (firstnameValue.length > 15) {
            //     firstnameValidation.textContent = 'firstname must not be longer than 15 characters';
            //     firstnameValidation.classList.add('err');
            // } else if (firstnameValue.length < 3) {
            //     firstnameValidation.textContent = 'firstname must be 3 characters or more';
            //     firstnameValidation.classList.add('err');
            // } else if (/\s/.test(firstnameValue)) {
            //     firstnameValidation.textContent = 'firstname must not contain spaces';
            //     firstnameValidation.classList.add('err');
            // } else {
            //     firstnameValidation.textContent = '';
            //     firstnameValidation.classList.remove('err');
            // }

            if (lastnameValue.length > 40) {
                lastnameValidation.textContent = 'fullname not be longer than 40 characters';
                lastnameValidation.classList.add('err');
            } else if (lastnameValue.length < 3) {
                lastnameValidation.textContent = 'fullname be 3 characters or more';
                lastnameValidation.classList.add('err');
            } else {
                lastnameValidation.textContent = '';
                lastnameValidation.classList.remove('err');
            }

            if (!hasNonDigits) {
                $('#phone_number_valid').html('Valid <i class="ti ti-check"></i>'); // the phone number is valid
                $('#phone_number_error').html('').removeClass('err');
                valid_number = $("#phone_number").intlTelInput("getNumber");
            } else {
                $('#phone_number_error').html('Not Valid X').addClass('err');
                $('#phone_number_valid').html('')
            }

            if ($('#user_type').val() != 0 || $('#user_type').val() != null) {
                $('#user_type_error').html('')
            } else {
                $('#user_type_error').html('required').addClass('err');
            }
        }

        $('#submit').on('click', function(e) {
            onSubmit();
            e.preventDefault();

            if ($('.err').length == 0) {

                var username = $('#username').val();
                var phone_number = $('#phone_number').val().replace(/\s/g, "");
                var password = $('#password').val();
                var full_name = $('#lastname').val()
                var birth_date = $('#startDate').val();
                var gender = $('#sex').val()
                var type_id = $('#user_type').val();
                var country_c = country_code.replace(/\s/g, "");
                var salary = $('#user_salary').val()

                $('#submit_error').html('');
                $.ajax({
                    url: "<?php echo e(route('staff.check_username')); ?>",
                    data: {
                        username: username,
                        phone_number: phone_number
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            $.ajax({
                                url: "<?php echo e(route('staff.store')); ?>",
                                data: {
                                    username: username,
                                    phone_number: phone_number,
                                    country_code: country_c,
                                    password: password,
                                    full_name: full_name,
                                    birth_date: birth_date,
                                    gender: gender,
                                    type_id: type_id,
                                    salary: salary
                                },
                                type: 'POST',
                                success: function(e) {
                                    if (data.success) {
                                        window.location.href = "<?php echo e(route('staff.index')); ?>";
                                    }
                                }
                            })
                        } else {
                            swal({
                                title: "PHONE OR USERNAME IS USED BEFORE",
                                icon: "warning",
                            });
                            return
                        }
                    }
                })
            } else {
                $('#submit_error').html('correct the errors first').addClass('text-danger text-uppercase h6');
            }
        });

        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sportcietyapp/public_html/platform.sportcietyapp.com/resources/views/staff/storepage.blade.php ENDPATH**/ ?>