
<?php $__env->startSection('title', 'Expenses History'); ?>
<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <div class="d-md-flex justify-content-between">
            <ol class="breadcrumb border border-warning px-3 py-2 rounded">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                            class="ti ti-home fs-4 mt-1"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="#" class="text-warning">Expenses History</a>
                </li>
            </ol>

            <div>
                <a type="button" class="btn waves-effect waves-light btn-light text-dark fs-4 mx-md-2 full_width" data-bs-toggle="modal"
                    data-bs-target="#eventModal" id="modal_button">
                    <i class="ti ti-circle-plus"></i>
                    <span>Generate New Amount</span>
                </a>

                <button class="btn btn-primary p-2 payment_button full_width" data-bs-toggle="modal" data-bs-target="#paymentModal">
                    <i class="ti ti-circle-plus"></i>
                    Add New Payment
                </button>
            </div>
        </div>
    </nav>

    <div class="mt-4"></div>
    <div class="accordion accordion-flush" id="accordionFlushExample">
        <div class="accordion-item">
            <h2 class="accordion-header" id="flush-headingThree">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                    data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                    <span class="fs-6">FILTERS</span>
                    <i class="ti ti-adjustments fs-7 mx-2"></i>
                </button>
            </h2>
            <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree"
                data-bs-parent="#accordionFlushExample" style="">
                <div class="accordion-body">
                    <div class="row">
                        <div class="col-md-3">
                            <label for="label-form">Date From</label>
                            <input type="date" class="form-control" id="search_from"
                                value="<?php echo e(request()->get('date_from')); ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="label-form">Date To</label>
                            <input type="date" class="form-control" id="search_to"
                                value="<?php echo e(request()->get('date_to')); ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="label-form">Expense Type</label>
                            <select name="expenses_types_search" id="expenses_types_search" class="form-control"
                                onchange="searchExpenses(false)">
                                <option selected value="none">--NONE--</option>
                                <?php $__currentLoopData = $expenses_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($expense_type['id']); ?>"
                                        <?php echo e(request()->get('type') == $expense_type['id'] ? 'selected' : ''); ?>>
                                        <?php echo e($expense_type['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="label-form">Expense</label>
                            <select name="expenses_search" id="expenses_search" class="form-control">
                            </select>
                        </div>
                    </div>

                    <div class="row mt-2">

                        <div class="col-md-3">
                            <label for="label-form">Staff</label>
                            <select name="staff_id" id="staff_id" class="form-control">
                                <option selected value="none">--NONE--</option>
                                <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($staff['id']); ?>"
                                        <?php echo e(request()->get('staff_id') == $staff['id'] ? 'selected' : ''); ?>>
                                        <?php echo e($staff['full_name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label for="label-form">Search Results</label>
                            <button class="btn btn-success w-100" id="search_button" onclick="search_button()">
                                <i class="ti ti-search"></i>
                                Search
                            </button>
                        </div>

                        <div class="col-md-3">
                            <label for="label-form">Clear Inputs</label>
                            <button class="btn btn-primary w-100" id="clear_button">
                                <i class="ti ti-eraser"></i>
                                Clear
                            </button>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body p-2 d-flex align-items-center gap-3">
                    <div class="d-flex align-items-center gap-3">
                        <h5 class="fw-semibold mb-0">Total Amount:</h5>
                        <span class="fs-6 d-flex align-items-center">
                            <i class="ti ti-currency-dollar"></i>
                            <?php echo e(number_format($total_amount, 2)); ?>

                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body p-2 d-flex align-items-center gap-3">
                    <div class="d-flex align-items-center gap-3">
                        <h5 class="fw-semibold mb-0">Total Payment:</h5>
                        <span class="fs-6 d-flex align-items-center">
                            <i class="ti ti-currency-dollar"></i>
                            <?php echo e(number_format($total_payment, 2)); ?>

                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body p-2 d-flex align-items-center gap-3">
                    <div class="d-flex align-items-center gap-3">
                        <h5 class="fw-semibold mb-0">Balance:</h5>
                        <span class="fs-6 d-flex align-items-center">
                            <i class="ti ti-currency-dollar"></i>
                            <?php echo e($balance); ?>

                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="d-md-flex justify-content-end">
        <!-- BEGIN MODAL -->
        <div class="modal fade" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="eventModalLabel">
                            Generate New Amount
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="label-form">Date<b class="text-danger">*</b></label>
                                <input type="date" class="form-control" id="expense_date">
                                <span class="container_error text-uppercase text-danger" id="expense_date_error"></span>
                            </div>

                            <div class="col-md-6 mt-3 mt-md-0">
                                <label for="label-form">Expense Type<b class="text-danger">*</b></label>
                                <select name="expenses_types" id="expenses_types" class="form-control"
                                    onchange="getExpenses(payment=false)">
                                    <option disabled selected value="0">--SELECT AN OPTION--</option>
                                    <?php $__currentLoopData = $expenses_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($expense_type['id']); ?>"><?php echo e($expense_type['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="container_error text-uppercase text-danger" id="type_error"></span>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-6">
                                <label for="label-form">Expense</label>
                                <select name="expenses" id="expenses" class="form-control">
                                </select>
                                <span class="container_error text-uppercase text-danger" id="expense_error"></span>
                            </div>

                            <div class="col-md-6 mt-3 mt-md-0">
                                <label for="label-form">Staff</label>
                                <select name="staff_id" id="staff_id_generate" class="form-control">
                                    <option selected value="none">--NONE--</option>
                                    <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($staff['id']); ?>"><?php echo e($staff['full_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                </select>
                                <span class="container_error text-uppercase text-danger" id="staff_error"></span>
                            </div>
                        </div>

                        <div class="row mt-3">

                            <div class="col-md-6">
                                <label for="label-form">Amount<b class="text-danger">*</b></label>
                                <input type="number" class="form-control" id="amount" name="amount">
                                <span class="container_error text-uppercase text-danger" id="amount_error"></span>
                            </div>

                            <div class="col-md-6">
                                <label for="label-form">Invoice ID#</label>
                                <input type="text" class="form-control" id="invoice_id" name="invoice_id">
                                <span class="container_error text-uppercase text-danger" id="invoice_error"></span>
                            </div>
                        </div>

                    </div>

                    <div class="d-flex justify-content-end my-2">
                        <button type="submit" class="btn btn-success btn-add-event mx-2" id="save_item">
                            <i class="ti ti-device-floppy fs-3"></i>
                            Generate New Amount
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="d-md-flex justify-content-end">
        <!-- BEGIN MODAL -->
        <div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="paymentModalLabel">
                            Add Payment
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="label-form">Date<b class="text-danger">*</b></label>
                                <input type="date" class="form-control" id="payment_date">
                                <span class="payment_container text-uppercase text-danger" id="payment_date_error"></span>
                            </div>

                            <div class="col-md-6 mt-3 mt-md-0">
                                <label for="label-form">Expense Type<b class="text-danger">*</b></label>
                                <select name="expenses_types_payment" id="expenses_types_payment" class="form-control"
                                    onchange="getExpenses(payment=true)">
                                    <option disabled selected value="0">--SELECT AN OPTION--</option>
                                    <?php $__currentLoopData = $expenses_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($expense_type['id']); ?>"><?php echo e($expense_type['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="container_error text-uppercase text-danger" id="expense_type_error"></span>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-6">
                                <label for="label-form">Expense</label>
                                <select name="expenses_payment" id="expenses_payment" class="form-control">
                                    <option value="none">--NONE--</option>
                                </select>
                                <span class="container_error text-uppercase text-danger" id="expense_error"></span>
                            </div>

                            <div class="col-md-6 mt-3 mt-md-0">
                                <label for="label-form">Staff</label>
                                <select name="staff_id_payment" id="staff_id_payment" class="form-control">
                                    <option value="none">--NONE--</option>
                                    <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($staff['id']); ?>"><?php echo e($staff['full_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                </select>
                                <span class="container_error text-uppercase text-danger" id="staff_error_payment"></span>
                            </div>
                        </div>

                        <div class="row mt-3 d-flex align-items-center">

                            <div class="col-md-6">
                                <label for="label-form">Amount<b class="text-danger">*</b></label>
                                <input type="number" class="form-control" id="amount_payment" name="amount_payment">
                                <span class="container_error text-uppercase text-danger" id="amount_payment_error"></span>
                            </div>

                            <div class="col-md-6 mt-3 mt-md-0">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input success check-outline outline-success" type="radio"
                                        id="success-outline-radio" name="payment_type" value="cash">
                                    <label class="form-check-label" for="success-outline-radio">Cash</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input success check-outline outline-success" type="radio"
                                        id="success2-outline-radio" name="payment_type" value="check" checked="">
                                    <label class="form-check-label" for="success2-outline-radio">Check Bancair</label>
                                </div>
                            </div>
                            <span class="container_error text-uppercase text-danger" id="payment_type_error"></span>
                        </div>

                    </div>

                    <div class="d-flex justify-content-end my-2">
                        <button type="submit" class="btn btn-success btn-add-event mx-2" id="generate_payment">
                            <i class="ti ti-device-floppy fs-3"></i>
                            Generate Payment
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>


    
    <div class="d-md-flex justify-content-end">
        <!-- BEGIN MODAL -->
        <div class="modal fade" id="editEventModal" tabindex="-1" aria-labelledby="editEventModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editEventModalLabel">
                            Edit Amount/Payment
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="label-form">Date<b class="text-danger">*</b></label>
                                <input type="date" class="form-control" id="edit_expense_date">
                                <span class="edit_container_error text-uppercase text-danger"
                                    id="edit_expense_date_error"></span>
                            </div>

                            <div class="col-md-6 mt-3 mt-md-0">
                                <label for="label-form">Expense Type<b class="text-danger">*</b></label>
                                <select name="expenses_types" id="edit_expenses_types" class="form-control"
                                    onchange="getExpensesEdit()">
                                    <option disabled selected value="0">--SELECT AN OPTION--</option>
                                    <?php $__currentLoopData = $expenses_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($expense_type['id']); ?>"><?php echo e($expense_type['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="edit_container_error text-uppercase text-danger" id="edit_type_error"></span>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-6">
                                <label for="label-form">Expense</label>
                                <select name="edit_expenses" id="edit_expenses" class="form-control">
                                </select>
                                <span class="edit_container_error text-uppercase text-danger"
                                    id="edit_expense_error"></span>
                            </div>

                            <div class="col-md-6 mt-3 mt-md-0">
                                <label for="label-form">Staff</label>
                                <select name="edit_staff_id" id="edit_staff_id_generate" class="form-control">
                                    <option selected value="none">--NONE--</option>
                                    <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($staff['id']); ?>"><?php echo e($staff['full_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                </select>
                                <span class="edit_container_error text-uppercase text-danger"
                                    id="edit_staff_error"></span>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-6">
                                <label for="label-form">Amount<b class="text-danger">*</b></label>
                                <input type="number" class="form-control" id="edit_amount" name="edit_amount">
                                <span class="container_error text-uppercase text-danger" id="edit_amount_error"></span>
                            </div>

                            <div id="cashorcheck" class="col-md-6">
                            </div>
                        </div>

                    </div>

                    <div class="d-flex justify-content-end my-2">
                        <button type="submit" class="btn btn-success btn-add-event mx-2" id="edit_amount_payment">
                            <i class="ti ti-device-floppy fs-3"></i>
                            Update Amount/Payment
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="my-2">

                        <div class="table-responsive">
                            <table id="expenses_types_table"
                                class="table border table-striped table-bordered display text-nowrap">
                                <thead>
                                    <!-- start row -->
                                    <tr>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">date</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">Expense Type</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">Expense</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">Staff</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">invoice</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">Amount</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">payment</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">payment type</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">action</h6>
                                        </th>

                                    </tr>
                                    <!-- end row -->
                                </thead>
                                <tbody>
                                    <!-- start row -->
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                            </table>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            //default date
            $('#expense_date').val(moment().format('YYYY-MM-DD'))
            $('#expense_date').attr('max', moment().format('YYYY-MM-DD')); // Set maximum date as today's date

            $('#payment_date').val(moment().format('YYYY-MM-DD'))
            $('#payment_date').attr('max', moment().format('YYYY-MM-DD')); // Set maximum date as today's date


            var table = $('#expenses_types_table').DataTable({
                processing: true,
                serverSide: true,
                scrollY: '100%',
                scrollCollapse: true,
                paging: true,
                responsive: true,
                ajax: getURL(),
                columns: [{
                        data: 'date',
                        name: 'date',
                        id: 'id'
                    },
                    {
                        data: 'type_name',
                        name: 'type_name',
                    },
                    {
                        data: 'expense_name',
                        name: 'expense_name',
                    },
                    {
                        data: 'staff_name',
                        name: 'staff_name',
                    },
                    {
                        data: 'invoice',
                        name: 'invoice',
                    },
                    {
                        data: 'expense_in',
                        name: 'expense_in',
                        className: "text-success"
                    },
                    {
                        data: 'expense_out',
                        name: 'expense_out',
                        className: "text-danger"
                    },
                    {
                        data: 'payment_type',
                        name: 'payment_type',
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    }
                ],
                order: [0, 'desc'],
            });

            var expense_type_search = $('#expenses_types_search').val()
            if (expense_type_search) {
                searchExpenses(true)
            }

            $('#eventModal').on('hidden.bs.modal', function(e) {
                $('.container_error').text('')
            });

            //add type input
            $(document).on('click', '.add_type', function(e) {
                $('#type-container').append(`
                <div class="d-flex my-3 mx-2 type_append">
                <input type="text" class="form-control" name="type_name[]">
                <div class="mx-2 invalid-feedback"></div>
                <button class="btn p-2 text-danger delete_type">
                    <i class="ti ti-trash"></i>
                </button>
                </div>
                `);
            })

            //delete appended type input
            $(document).on('click', '.delete_type', function(e) {
                $(this).closest('.type_append').remove();
            });


            $(document).on('click', '#save_item', function(e) {

                var valid = true;
                var date = $('#expense_date').val();
                var type = $('#expenses_types').val();
                var expense = $('#expenses').val();
                var staff_id = $('#staff_id_generate').val();
                var invoice_id = $('#invoice_id').val();
                var amount = $('#amount').val();

                if (!isValidDateFormat(date)) {
                    $('#expense_date_error').text('DATE REQUIRED AND MAX IS TODAY')
                    valid = false;
                    return;
                } else {
                    $('#expense_date_error').text('')
                    valid = true
                }

                if (!amount || isNaN(amount) || amount < 0) {
                    $('#amount').val(1)
                    $('#amount_error').text('amount is required')
                    valid = false;
                    return;
                } else {
                    $('#amount_error').text('')
                    valid = true;
                }

                if (!type || type == 0 || isNaN(type)) {
                    $('#type_error').text('Type is required')
                    valid = false;
                    return;
                } else {
                    $('#type_error').text('')
                    valid = true;
                }

                if (expense == 'none' && staff_id == 'none') {
                    $('#staff_error').text('you should choose expense or staff first !!');
                    valid = false;
                    return;
                } else {
                    $('#staff_error').text('');
                    valid = true;
                }

                if (valid) {
                    $.ajax({
                        url: "<?php echo e(route('expensehistory.store')); ?>",
                        method: 'POST',
                        data: {
                            date: date,
                            type: type,
                            expense_id: expense,
                            staff_id: staff_id,
                            invoice_id: invoice_id,
                            amount: amount
                        },
                        type: 'POST',
                        success: function(response) {
                            if (response.success) {
                                swal({
                                    title: 'EXPENSE ADDED SUCCESSFULLY',
                                    icon: 'success'
                                }).then(() => {
                                    location.href =
                                        "<?php echo e(route('expensehistory.index')); ?>";
                                })
                            }
                        },
                        error: function(xhr, status, error) {
                            // Handle the error
                            console.log(error);
                        }
                    });
                }
            });

            const modal = document.querySelector('#eventModal');
            modal.addEventListener('hidden.bs.modal', function(event) {
                const elementsToRemove = document.querySelectorAll('div.type_append');
                elementsToRemove.forEach(function(element) {
                    element.remove();
                });
                const in_err = document.querySelector('input.is-invalid');
                in_err.classList.remove('is-invalid');
                in_err.textContent = '';
            });

            $(document).on('click', '.payment_button', function(e) {
                $('.container_error').text('')
            });

            $(document).on('click', '#generate_payment', function(e) {

                var date = $('#payment_date').val();
                var amount = $('#amount_payment').val();
                const checkedPaymentType = document.querySelector('input[name="payment_type"]:checked');
                const checkedValue = checkedPaymentType.value;
                var check = true;
                var expense_type = $('#expenses_types_payment').val();
                var expense = $('#expenses_payment').val();
                var staff_id = $('#staff_id_payment').val();

                if (!expense_type || expense_type == 0 || expense_type < 0 || isNaN(expense_type)) {
                    $('#expense_type_error').text('expense type is required');
                    check = false
                    return;
                } else {
                    $('#expense_type_error').text('')
                    check = true;
                }

                if (!expense || !staff_id) {
                    $('#staff_error_payment').text('you should choose expense or staff first !!');
                    check = false;
                    return;
                } else {
                    $('#staff_error_payment').text('');
                    check = true;
                }

                if (expense == 'none' && staff_id == 'none') {
                    $('#staff_error_payment').text('you should choose expense or staff first !!');
                    check = false;
                    return;
                } else {
                    $('#staff_error_payment').text('');
                    check = true;
                }

                if (!isValidDateFormat(date)) {
                    $('#payment_date_error').text('DATE REQUIRED AND MAX IS TODAY')
                    check = false;
                    return;
                } else {
                    $('#payment_date_error').text('')
                    check = true
                }

                if (!amount || isNaN(amount) || amount < 0) {
                    $('#amount_payment').val(1);
                    $('#payment_type_error').text('Amount is required')
                    check = false;
                    return;
                } else {
                    $('#payment_type_error').text('')
                    check = true;
                }

                if (!checkedValue) {
                    $('#amount_payment_error').text('payment type is required')
                    check = false;
                    return;
                } else {
                    $('#amount_payment_error').text('')
                    check = true;
                }

                if (check) {
                    $.ajax({
                        url: "<?php echo e(route('expensehistory.store_payment')); ?>",
                        data: {
                            expense_id: expense,
                            type_id: expense_type,
                            staff_id: staff_id,
                            date: date,
                            out_expense: amount,
                            payment_type: checkedValue,
                        },
                        type: 'POST',
                        success: function(response) {
                            if (response.success) {
                                swal({
                                    title: 'PAYMENT ADDED SUCCESSFULLY',
                                    icon: 'success'
                                }).then(() => {
                                    location.href =
                                        "<?php echo e(route('expensehistory.index')); ?>";
                                })
                            }
                        }
                    })
                }
            })

        });

        function isValidDateFormat(date) {
            var today = moment().format('YYYY-MM-DD');
            // Check if the date string is valid and less than or equal to today's date
            return moment(date, 'YYYY-MM-DD', true).isValid() && moment(date).isSameOrBefore(today);
        }

        //onchange expenses_types
        function getExpenses(payment) {

            $('#expenses').empty();
            $('#expenses_payment').empty()

            if (payment) {
                var type_id = $('#expenses_types_payment').val();
                if (type_id != 0) {
                    $('#expenses_payment').append($('<option>', {
                        value: 'none',
                        text: '--NONE--'
                    }));
                }
            } else {
                var type_id = $('#expenses_types').val()
                if (type_id != 0) {
                    $('#expenses').append($('<option>', {
                        value: 'none',
                        text: '--NONE--'
                    }));
                }
            }
            $.ajax({
                url: "<?php echo e(route('expensehistory.getExpenses')); ?>",
                data: {
                    type_id: type_id
                },
                success: function(response) {
                    if (response.success) {
                        var data = response.data;
                        // Appending new values using a for loop
                        if (payment) {
                            for (var i = 0; i < data.length; i++) {
                                $('#expenses_payment').append($('<option>', {
                                    value: data[i].id,
                                    text: data[i].name
                                }));
                            }
                        } else {
                            for (var i = 0; i < data.length; i++) {
                                $('#expenses').append($('<option>', {
                                    value: data[i].id,
                                    text: data[i].name
                                }));
                            }
                        }
                    }

                }
            })
        }

        //onchange expenses_types
        function searchExpenses(onready = false) {
            $('#expenses_search').empty();
            var type_id = $('#expenses_types_search').val()
            if (type_id != 0) {
                $('#expenses_search').append($('<option>', {
                    value: 'none',
                    text: '--NONE--'
                }));
            }
            $.ajax({
                url: "<?php echo e(route('expensehistory.getExpenses')); ?>",
                data: {
                    type_id: type_id
                },
                success: function(response) {
                    if (response.success) {
                        var data = response.data;
                        for (var i = 0; i < data.length; i++) {
                            $('#expenses_search').append($('<option>', {
                                value: data[i].id,
                                text: data[i].name
                            }));
                        }
                        if (onready) {
                            const currentUrl = window.location.href;
                            // Create a new URL object based on the current URL
                            const url = new URL(currentUrl);
                            // Create a new URLSearchParams object based on the query parameters
                            const searchParams = new URLSearchParams(url.search);
                            // Get the value of the 'type' parameter
                            const expense_id = searchParams.get('expense_id');
                            if (expense_id) {
                                $('#expenses_search').val(expense_id)
                            }
                        }
                    }

                }
            })
        }

        $(document).on('click', '#clear_button', function(e) {
            $('#search_from').val('')
            $('#search_to').val('')
            $('#expenses_types_search').val('none')
            $('#expenses_search').val('none')
            $('#staff_id').val('none')
        });

        function search_button() {
            var URL = "<?php echo e(route('expensehistory.index')); ?>";
            var date_from = $('#search_from').val().trim();
            var date_to = $('#search_to').val().trim();
            var expense_type = $('#expenses_types_search').val().trim();
            var expense = $('#expenses_search').val();
            var staff_id = $('#staff_id').val()
            var params = [];

            if (date_from && date_to) {
                params.push('date_from=' + date_from);
                params.push('date_to=' + date_to);
            }

            if (expense_type != 'none') {
                params.push('type=' + expense_type);
            }

            if (expense != 'none' && expense && expense != null) {
                params.push('expense_id=' + expense);
            }

            if (staff_id != 'none') {
                params.push('staff_id=' + staff_id);
            }

            if (params.length > 0) {
                URL += '?' + params.join('&');
            } else {
                location.href = "<?php echo e(route('expensehistory.index')); ?>";
            }

            location.href = URL;
        }

        function getURL() {
            var URL = "<?php echo e(route('expensehistory.index')); ?>";
            var date_from = $('#search_from').val().trim();
            var date_to = $('#search_to').val().trim();
            var expense_type = $('#expenses_types_search').val().trim();
            var expense = <?php echo json_encode($expense_id); ?>;
            var staff_id = $('#staff_id').val()
            var params = [];

            if (date_from && date_to) {
                params.push('date_from=' + date_from);
                params.push('date_to=' + date_to);
            }

            if (expense_type != 'none') {
                params.push('type=' + expense_type);
            }

            if (expense) {
                params.push('expense_id=' + expense);
            }

            if (staff_id != 'none') {
                params.push('staff_id=' + staff_id);
            }

            if (params.length > 0) {
                URL += '?' + params.join('&');
                return URL;
            } else {
                return "<?php echo e(route('expensehistory.index')); ?>";
            }
        }

        //EDIT MODAL
        var edit_id;
        var checkinout;
        //edit expense
        function getExpensesEdit(expense_id = 0, type_id = 0) {
            $('#edit_expenses').empty();
            if (type_id != 0) {
                id = type_id;
                $('#edit_expenses').append($('<option>', {
                    value: 'none',
                    text: '--NONE--'
                }));
            } else {
                var id = $('#edit_expenses_types').val()
                if (id != 0) {
                    $('#edit_expenses').append($('<option>', {
                        value: 'none',
                        text: '--NONE--'
                    }));
                }
            }
            $.ajax({
                url: "<?php echo e(route('expensehistory.getExpenses')); ?>",
                data: {
                    type_id: id
                },
                success: function(response) {
                    if (response.success) {
                        var data = response.data;
                        // Appending new values using a for loop
                        for (var i = 0; i < data.length; i++) {
                            $('#edit_expenses').append($('<option>', {
                                value: data[i].id,
                                text: data[i].name
                            }));
                        }
                        if (expense_id != 0) {
                            $('#edit_expenses').val(expense_id)
                        }
                    }
                }
            })
        }


        $(document).on('click', '.edit_button', function(e) {

            edit_id = $(this).data('id');
            var date = $(this).data('date');
            var type = $(this).data('type');
            var expense = $(this).data('expense');
            var staff = $(this).data('staff');
            var invoice = $(this).data('invoice');
            var amount = $(this).data('amount');
            var payment = $(this).data('payment');
            var payment_type = $(this).data('payment-type');
            checkinout = $(this).data('check');
            var expense_id = expense == 0 ? 'none' : expense;
            getExpensesEdit(expense_id, type)

            if (checkinout == 'in') {
                $('#edit_amount').val(amount)
                $('#cashorcheck').html(`
            <label for="label-form">Invoice ID#</label>
            <input type="text" class="form-control" id="edit_invoice_id" name="edit_invoice_id" value=${invoice}>
            <span class="edit_container_error text-uppercase text-danger"
            id="edit_invoice_error"></span>
            `);
            } else {
                $('#edit_amount').val(payment)
                $('#cashorcheck').html(`
                <div class="mt-3">
                <div class="form-check form-check-inline">
                <input class="form-check-input success check-outline outline-success" type="radio"
                id="success-outline-radio" name="payment_type_edit" value="cash">
                <label class="form-check-label" for="success-outline-radio">Cash</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input success check-outline outline-success" type="radio"
                id="success2-outline-radio" name="payment_type_edit" value="check">
                <label class="form-check-label" for="success2-outline-radio">Check Bancair</label>
                </div>
                </div>`);
            }

            $('input[name="payment_type_edit"]').filter(`[value="${payment_type}"]`).prop('checked', true);
            $('#edit_expense_date').val(date);
            $('#edit_expenses_types').val(type);
            $('#edit_expenses').val(expense == 0 ? 'none' : expense);
            $('#edit_staff_id_generate').val(staff == 0 ? 'none' : staff);
            $('#edit_invoice_id').val(invoice);
        });

        $(document).on('click', '#edit_amount_payment', function(e) {

            var expense_type = $('#edit_expenses_types').val();
            var expense = $('#edit_expenses').val();
            var staff_id = $('#edit_staff_id_generate').val();
            var date = $('#edit_expense_date').val();
            var amount = $('#edit_amount').val();
            var check = false;


            if (checkinout == 'in') {
                var checkedValue = null;
                var edit_invoice_id = $('#edit_invoice_id').val()
            } else {
                var edit_invoice_id = null;
                var checkedPaymentType = document.querySelector('input[name="payment_type_edit"]:checked');
                var checkedValue = checkedPaymentType.value;
                if (!checkedValue) {
                    $('#edit_amount_error').text('payment type is required')
                    check = false;
                    return;
                } else {
                    $('#edit_amount_error').text('')
                    check = true;
                }
            }

            if (!expense_type || expense_type == 0 || expense_type < 0 || isNaN(expense_type)) {
                $('#edit_type_error').text('expense type is required');
                check = false;
                return;
            } else {
                $('#edit_type_error').text('')
                check = true;
            }

            if (expense == 'none' && staff_id == 'none') {
                $('#edit_staff_error').text('you should choose expense or staff first !!');
                check = false;
                return;
            } else {
                $('#edit_staff_error').text('');
                check = true;
            }

            if (!isValidDateFormat(date)) {
                $('#edit_expense_date_error').text('DATE REQUIRED AND MAX IS TODAY')
                check = false;
                return;
            } else {
                $('#edit_expense_date_error').text('')
                check = true
            }

            if (!amount || isNaN(amount) || amount < 0) {
                $('#edit_amount').val(1);
                $('#edit_amount_error').text('Amount is required')
                check = false;
                return;
            } else {
                $('#edit_amount_error').text('')
                check = true;
            }

            if (check) {
                $.ajax({
                    url: "<?php echo e(route('expensehistory.update')); ?>",
                    data: {
                        id: edit_id,
                        expense_id: expense,
                        type_id: expense_type,
                        staff_id: staff_id,
                        date: date,
                        expense: amount,
                        payment_type: checkedValue,
                        invoice_id: edit_invoice_id
                    },
                    type: 'POST',
                    success: function(response) {
                        if (response.success) {
                            swal({
                                title: 'ROW UPDATED SUCCESSFULLY',
                                icon: 'success'
                            }).then(() => {
                                location.href =
                                    "<?php echo e(route('expensehistory.index')); ?>";
                            })
                        }
                    }
                })
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\sportciety_club\resources\views/expense_history/index.blade.php ENDPATH**/ ?>