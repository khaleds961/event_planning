<?php if(Helper::check_permission($function_id, 'is_delete')): ?>
    <a class="show_confirmed text-warning delete_icon" data-id="<?php echo e($id); ?>" data-table_name="<?php echo e($table_name); ?>"
        style="cursor: pointer">
        <i class="ti ti-trash me-1 fs-6"></i>
    </a>
<?php endif; ?>

<?php if(Helper::check_permission($function_id, 'is_read')): ?>
    <a class="text-dark edit_button" style="cursor: pointer" data-bs-toggle="modal"
        data-id="<?php echo e($id); ?>" data-date="<?php echo e($row->date); ?>" data-type="<?php echo e($row->type_id); ?>" 
        data-expense="<?php echo e($row->expense_id); ?>"
        data-staff="<?php echo e($row->staff_id); ?>"
        data-invoice="<?php echo e($row->invoice_id); ?>"
        data-payment-type="<?php echo e($row->payment_type); ?>"
        data-amount="<?php echo e($row->in_expense); ?>"
        data-payment="<?php echo e($row->out_expense); ?>"
        data-check="<?php echo e($in_or_out); ?>"
        data-bs-target="#editEventModal">
        <i class="ti ti-pencil fs-6"></i>
    </a>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/expense_history/action.blade.php ENDPATH**/ ?>