<?php

if ($checked_flag == 1) {
    $checked = 'checked';
} else {
    $checked = '';
}
?>

        <?php if($action == 'is_active'): ?>
            <div class="form-group">
            <div class="custom-control custom-switch">
                <input type="checkbox" class="custom-control-input change_status" data-id="<?php echo e($id); ?>" data-action="<?php echo e($action); ?>" data-table_name="<?php echo e($table_name); ?>" id="customSwitch_<?php echo e($id); ?>" <?php echo e($checked); ?>>
                <label class="custom-control-label" for="customSwitch_<?php echo e($id); ?>">Active</label>
            </div>
        </div>
        
        <?php endif; ?>

<?php if($action == 'is_featured'): ?>
    <div class="form-group">
        <div class="custom-control custom-switch custom-checkbox-secondary">
            <input type="checkbox" class="custom-control-input change_status" data-id="<?php echo e($id); ?>"
                data-action="<?php echo e($action); ?>" data-table_name="<?php echo e($table_name); ?>"
                id="customSwitch1_<?php echo e($id); ?>" <?php echo e($checked); ?>>
            <label class="custom-control-label" for="customSwitch1_<?php echo e($id); ?>">Featured</label>
        </div>
    </div>
<?php endif; ?>

<?php if($action == 'is_approved'): ?>
    <div class="form-group">
        <div class="custom-control custom-switch custom-checkbox-success">
            <input type="checkbox" class="custom-control-input change_status_approval_active"
                data-id="<?php echo e($id); ?>" data-action="<?php echo e($action); ?>" data-table_name="<?php echo e($table_name); ?>"
                id="customSwitch2_<?php echo e($id); ?>" <?php echo e($checked); ?>>
            <label class="custom-control-label" for="customSwitch2_<?php echo e($id); ?>">Approved</label>
        </div>
    </div>
<?php endif; ?>

<?php if($action == 'is_refundable'): ?>
    <div class="form-group">
        <div class="custom-control custom-switch custom-checkbox-success">
            <input type="checkbox" class="custom-control-input change_status" data-id="<?php echo e($id); ?>"
                data-action="<?php echo e($action); ?>" data-table_name="<?php echo e($table_name); ?>"
                id="customSwitch2_<?php echo e($id); ?>" <?php echo e($checked); ?>>
            <label class="custom-control-label" for="customSwitch2_<?php echo e($id); ?>">Refundable</label>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/actions/other_action.blade.php ENDPATH**/ ?>