

<?php if(Helper::check_permission($function_id, 'is_read')): ?>
    <div>
        <?php if(count($sports) > 0): ?>
            <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span>
                    <a href="courts/editsport/<?php echo e($id); ?>/<?php echo e($sport->id); ?>" class="text-warning">
                        [<?php echo e($sport->title); ?>]
                    </a>
                </span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <span>No Sport Yet</span>
        <?php endif; ?>

        <?php if(Helper::check_permission($function_id, 'is_write')): ?>
            <button class="btn me-1 mb-1 text-error font-medium add_sport_click" data-id="<?php echo e($id); ?>"
                data-title="<?php echo e($title); ?>" data-bs-toggle="modal" data-bs-target="#add_new_sport"
                data-bs-toggle="tooltip" data-bs-placement="right" title="Add New Sport">
                <i class="ti ti-circle-plus text-danger" style="font-size: 20px"></i>
            </button>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH C:\Xampp\htdocs\sportciety_club\resources\views/courts/addsport_action.blade.php ENDPATH**/ ?>