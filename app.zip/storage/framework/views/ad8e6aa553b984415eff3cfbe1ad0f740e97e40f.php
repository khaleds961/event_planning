
<?php $__env->startSection('title', 'Clients'); ?>
<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <div class="d-md-flex justify-content-between">
            <ol class="breadcrumb border border-warning px-3 py-2 rounded mb-sm-2 mb-0">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                            class="ti ti-home fs-4 mt-1"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="#" class="text-warning">Clients</a>
                </li>
            </ol>

            <div>
                <a type="button" class="btn mb-1 waves-effect waves-light btn-light text-dark fs-4 full_width"
                    data-bs-toggle="modal" data-bs-target="#eventModal" id="modal_button">
                    <i class="ti ti-circle-plus"></i>
                    <span>Add New Client</span>
                </a>

                <span class="mx-2"></span>

                <button type="button"
                    class="btn mb-1 waves-effect waves-success bg-light-success text-success fs-4 full_width"
                    data-bs-toggle="modal" data-bs-target="#broadcastModal" id="broadcast_button" disabled>
                    <i class="ti ti-broadcast"></i>
                    <span>Clients BroadCasting</span>
                </button>
            </div>
        </div>
    </nav>

    <div class="d-md-flex justify-content-end">
        <!-- BEGIN MODAL -->
        <div class="modal fade" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
            <div class="modal-dialog ">
                <div class="modal-content p-3">
                    <div class="modal-header">
                        <h5 class="modal-title" id="eventModalLabel">
                            Add New Client
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="mt-3">
                        <label for="full_name">Full Name
                            <b class="text-danger">*</b>
                        </label>
                        <input type="text" class="form-control" id="full_name" name="full_name">
                        <span class="text-danger text-uppercase" id="full_name_error"></span>
                    </div>

                    <div class="mt-3">
                        <label for="birth_date">Birth Date
                            <b class="text-danger">*</b>
                        </label>
                        <input type="date" class="form-control" id="birth_date" name="birth_date">
                        <span class="text-danger text-uppercase" id="birth_date_error"></span>
                    </div>

                    <div class="mt-3">
                        <label for="email">Email
                            <b class="text-danger">*</b>
                        </label>
                        <input type="text" class="form-control" id="email" name="email">
                        <span class="text-danger text-uppercase" id="email_error"></span>
                    </div>

                    <div class="mt-3">
                        <div>
                            <label for="phone_number">Phone Number
                                <b class="text-danger">*</b>
                            </label>
                        </div>
                        <input type="number" class="form-control" id="phone_number" name="phone_number">
                        <span id="phone_number_error" class="text-uppercase text-danger h6"></span>
                        <span id="phone_number_valid" class="text-uppercase text-success h6"></span>
                        <span id="phone_err" class="text-uppercase text-success h6"></span>
                    </div>

                    <div class="d-flex justify-content-end mt-3">
                        <button class="btn btn-success btn-add-event" id="save_member">
                            <i class="ti ti-device-floppy fs-3"></i>
                            Save New Client
                        </button>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- BEGIN MODAL BROADCAST -->
    <div class="d-md-flex justify-content-end">
        <!-- BEGIN MODAL BROADCAST -->
        <div class="modal fade" id="broadcastModal" tabindex="-1" aria-labelledby="broadcastModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="card-title mb-0">Clients BroadCast</h4>
                    </div>
                    <div class="modal-body">

                        <div id="step2" class="step">
                            <!-- Step 2 content goes here -->
                            <div class="d-flex align-items-center">
                                
                                <span class="fs-6 mx-2 ">
                                    Send BroadCast To
                                </span>
                            </div>
                            <section class="mt-3">
                                <div class="row py-2">
                                    <div class="col-md-8 col-xl-9">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input success" type="checkbox" id="success-check"
                                                name="broadcast_type" value="email" checked>
                                            <label class="form-check-label" for="success-check">Email</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input success" type="checkbox" id="success2-check"
                                                name="broadcast_type" value="notification">
                                            <label class="form-check-label" for="success2-check">Mobile
                                                Notification</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label for="shortDescription1">Description :</label>
                                            <textarea name="shortDescription" id="shortDescription1" rows="6" class="form-control"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>

                        <div class="d-flex justify-content-end">
                            <button class="btn btn-primary" id="nextButton">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <div class="my-2">
                        <label for="">
                            <input type="checkbox" id="select_all_btn" style="width: 15px;height:15px">
                            <span class="h5 mx-2 mb-2">Select All</span>
                        </label>

                        <label class="block">
                            <select class="form-control my-1" name="sport_id" id="sport_type" onchange="search()">
                                <option disabled value="0" selected>--Select Sport--</option>
                                <option value="none" selected>--None--</option>
                                <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sport->id); ?>"
                                        <?php echo e($sport->id == request()->sport_id ? 'selected' : ''); ?>><?php echo e($sport->title); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span id="sport_error"></span>
                        </label>
                    </div>

                    <div class="table-responsive mt-2">
                        <table id="expenses_table" class="table border table-striped table-bordered display text-nowrap">
                            <thead>
                                <!-- start row -->
                                <tr>
                                    <th></th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">fullname</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">phone</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">email</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">total reservations</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">total spent</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">last reservation</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">history</h6>
                                    </th>
                                </tr>
                                <!-- end row -->
                            </thead>
                            <tbody>
                                <!-- start row -->
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-scripts'); ?>
    <script>
        const full_name = document.querySelector('#full_name');
        const full_nameValidation = document.querySelector('#full_name_error');

        const currentYear = new Date().getFullYear();

        // Set the max and min years
        const maxYear = currentYear - 6;
        const minYear = currentYear - 80;

        const date_min = moment().set({
            year: minYear,
            month: 11, // Note that month values are zero-based
            date: 31,
        });

        var checkedValues = [];

        $(document).ready(function() {
            var sport_id = 0;
            var phone = $('#phone_number');
            var phone_error = $('#phone_number_error');
            var phone_valid = $('#phone_number_valid');
            var valid_number;
            var country_code;

            phone.intlTelInput({
                preferredCountries: ["lb"],
                separateDialCode: true,
                utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.1.7/js/utils.js"
            });

            // Add a keyup event listener to validate the phone number
            phone.on("keyup change", function() {
                var hasNonDigits = /[^\d]/.test(phone.val());
                if (!hasNonDigits) {
                    phone_error.html('').removeClass('err');
                    valid_number = phone.intlTelInput("getNumber");
                    country_code = phone.intlTelInput("getSelectedCountryData").dialCode;
                } else {
                    phone_error.html('Not Valid X').addClass('err');
                    phone_valid.html('')
                }
            });

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#expenses_table').DataTable({
                processing: true,
                serverSide: true,
                // scrollY: '100%',
                // scrollX: $(window).width() <= 1740, // Set scrollX to false when screen width is greater than 1740px
                // scrollCollapse: true,
                // paging: true,
                responsive: true,
                "ajax": {
                    "url": "<?php echo e(route('clients.index')); ?>?sport_id=" + sport_id != 0 ? sport_id : sport_id,
                    "type": "get",
                },
                columns: [{
                        data: null,
                        render: function(data, type, row) {
                            return `<input type="checkbox" class="row-select" value="${row.id}">`;
                        },
                        orderable: false,
                        searchable: false,
                        className: 'select-checkbox',
                    },
                    {
                        data: 'full_name',
                        name: 'full_name',
                    },
                    {
                        data: 'phone',
                        name: 'phone'
                    },
                    {
                        data: 'email',
                        name: 'email',
                    },
                    {
                        data: 'total_reservations',
                        name: 'total_reservations',
                        searchable:false
                    },
                    {
                        data: 'total_spent',
                        name: 'total_spent',
                        searchable:false
                    },
                    {
                        data: 'last_reservation',
                        name: 'last_reservation',
                        orderable: false,
                        searchable: false,
                    },
                    {
                        data: 'history',
                        name: 'history',
                        className: 'text-center',
                        orderable: false,
                        searchable: false,
                    },
                ],
                order: [0, 'desc'],
                select: {
                    style: 'multi',
                    selector: 'td.select-checkbox',
                }

            });

            $('#select_all_btn').on('click', function() {
                if ($(this).is(':checked')) {
                    $('#broadcast_button').prop('disabled', false);
                    $('input[class="row-select"]').prop('checked', true);
                } else {
                    $('#broadcast_button').prop('disabled', true);
                    $('input[class="row-select"]').prop('checked', false);
                }
            });

            $(document).on('click', '#save_member', function(e) {
                $('#birth_date_error').empty();
                $('#email_error').empty();
                $('#phone_err').empty();
                var phone_number = $('#phone_number').val().replace(/\s/g, "");
                var dateInput = $('#birth_date').val();
                var full_name = $('#full_name').val();
                var birth_date = $('#birth_date').val();
                var email = $('#email').val();
                var country_c = country_code.replace(/\s/g, "");
                const isValid = validateDateInput(dateInput);
                const isEmailValid = isValidEmail(email);

                if (phone_number == '' || phone_number == 0 || phone_number == null) {
                    $('#phone_err').append(
                        '<span class="err text-danger text-uppercase">required !!</span>');
                } else {
                    $('#phone_err').empty();
                }
                fullnamecheck()

                if (isEmailValid) {
                    $('#email_error').empty();
                } else {
                    $('#email_error').append(
                        `<span class="err">email is invalid</span>`
                    );
                }

                if (isValid) {
                    $('#birth_date_error').empty();
                } else {
                    $('#birth_date_error').append(
                        `<span class="err">date should not be less than ${minYear} and not more than ${maxYear}</span>`
                    );
                }

                if ($('.err').length == 0) {
                    $('#save_member').attr('disabled', true)
                    $.ajax({
                        url: "<?php echo e(route('players.check_email')); ?>",
                        data: {
                            email: email,
                            phone: phone_number
                        },
                        type: 'POST',
                        success: function(data) {
                            if (data.success) {
                                storeplayer(full_name, email, phone_number, country_c,
                                    birth_date)
                            } else {
                                swal({
                                    title: 'EMAIL OR PHONE NUMBER IS REPEATED !',
                                    icon: 'warning'
                                })
                                $('#save_member').attr('disabled', false)
                            }
                        }

                    })
                }
            });

            full_name.addEventListener('keyup', function() {
                fullnamecheck()
            });

            // Get references to the steps
            const step1 = document.getElementById('step1');
            const step2 = document.getElementById('step2');

            // Get references to the navigation buttons
            const nextButton = document.getElementById('nextButton');
            const previousButton = document.getElementById('previousButton');

            $('#expenses_table').on('change', 'input.row-select', function() {
                showNextStep()
            });

            // Function to show the next step
            function showNextStep() {
                checkedValues = []
                $('input[class="row-select"]:checked').each(function() {
                    checkedValues.push($(this).val());
                });
                console.log({
                    checkedValues
                });

                if (checkedValues.length > 0) {
                    $('#broadcast_button').prop('disabled', false);
                    step2.style.display = 'block';
                } else {
                    $('#broadcast_button').prop('disabled', true);
                }
            }

            // Function to show the previous step
            // function showPreviousStep() {
            //     nextButton.textContent = 'Next';
            //     step2.style.display = 'none';
            //     step1.style.display = 'block';
            // }

            // Event listener for the previous button
            // previousButton.addEventListener('click', showPreviousStep);

            nextButton.addEventListener('click', function() {
                if (nextButton.textContent === 'Submit') {
                    var description = $('#shortDescription1').val();
                    var broadcastTypes = [];

                    $('input[name="broadcast_type"]:checked').each(function() {
                        broadcastTypes.push($(this).val());
                    });

                    if (description == '' || !description) {
                        swal({
                            title: "Warning!",
                            text: "Please make your desicription at least characters.",
                            icon: 'warning'
                        });
                        return;
                    }
                    //first check again if checkedValues has more than one value
                    //check also broadcast
                    if (checkedValues.length > 0 && broadcastTypes.length > 0) {
                        $('#nextButton').prop('disabled', true)
                        $('#previousButton').prop('disabled', true)
                        $.ajax({
                            url: "<?php echo e(route('clients.broadcast')); ?>",
                            data: {
                                clients: checkedValues,
                                broadcast: broadcastTypes,
                                description: description
                            },
                            type: 'POST',
                            success: function(response) {
                                if (response.status_email && response.status_notification) {
                                    swal({
                                        title: 'Success',
                                        text: 'Email and Notifications are sent successfully',
                                        icon: 'success'
                                    }).then(() => {
                                        location.reload();
                                    });
                                } else if (response.status_email) {
                                    swal({
                                        title: 'Success',
                                        text: 'Email is sent successfully',
                                        icon: 'success'
                                    }).then(() => {
                                        location.reload();
                                    });
                                } else if (response.status_notification) {
                                    swal({
                                        title: 'Success',
                                        text: 'Notification is sent successfully',
                                        icon: 'success'
                                    }).then(() => {
                                        location.reload();
                                    });
                                } else {
                                    console.log('error');
                                    $('#nextButton').prop('disabled', false)
                                    $('#previousButton').prop('disabled', false)
                                }
                            }
                        })
                    } else {
                        swal({
                            title: "Warning!",
                            text: "You must choose a broadcast type first!.",
                            icon: 'warning'
                        });
                        return;
                    }
                } else {
                    // Proceed to the next step
                    showNextStep();
                }
            });

            $('#broadcastModal').on('hidden.bs.modal', function() {
                $('input[type="checkbox"][name="client_id"]').prop('checked', false);
                $('#shortDescription1').val('')
                $('input[type="checkbox"][name="broadcast_type"]').prop('checked', false)
                checkedValues = [];
                // showPreviousStep()
            });

            $('#eventModal').on('hidden.bs.modal', function() {
                $('#full_name_error').empty();
                $('#birth_date_error').empty();
                $('#email_error').empty();
                $('#phone_err').empty()
                $('#phone_number_error').empty();
                $('#phone_number_valid').empty();
            });

        });

        function search() {

            var URL = "<?php echo e(route('clients.index')); ?>";
            sport_id = $('#sport_type').val().trim();
            var element = [];

            if (sport_id == 'none') {
                location.href = URL;
            } else {

                if (sport_id && sport_id != null && sport_id != 'none') {
                    element.push('sport_id=' + sport_id);
                }

                if (element.length > 0) {
                    URL += '?' + element.join('&');
                } else {
                    location.href = "<?php echo e(route('clients.index')); ?>";
                }

                location.href = URL;
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/clients/index.blade.php ENDPATH**/ ?>