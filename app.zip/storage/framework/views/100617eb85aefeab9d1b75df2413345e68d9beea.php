
<?php $__env->startSection('title', 'Admins'); ?>
<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <ol class="breadcrumb border border-warning px-3 py-2 rounded">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                        class="ti ti-home fs-4 mt-1"></i></a>
            </li>
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('permission.index')); ?>" class="text-warning d-flex align-items-center">
                    Admins
                </a>
            </li>
            <li class="breadcrumb-item">
                <a href="#" class="text-warning"><?php echo e($type_name); ?></a>
            </li>
        </ol>
    </nav>

    <table class="table mt-4">
        <thead>
            <tr>
                <th>
                    <h6 class="fs-4 fw-semibold mb-0 text-uppercase">function</h6>
                </th>
                <th>
                    <h6 class="fs-4 fw-semibold mb-0 text-uppercase">all permissions</h6>
                </th>
                <th>
                    <h6 class="fs-4 fw-semibold mb-0 text-uppercase">read</h6>
                </th>
                <th>
                    <h6 class="fs-4 fw-semibold mb-0 text-uppercase">write</h6>
                </th>
                <th>
                    <h6 class="fs-4 fw-semibold mb-0 text-uppercase">update</h6>
                </th>
                <th>
                    <h6 class="fs-4 fw-semibold mb-0 text-uppercase">delete</h6>
                </th>
            </tr>
        </thead>
        <form action="<?php echo e(route('permission.update_store')); ?>" method="post" id="permission_form">
            <?php echo csrf_field(); ?>
            <tbody>
                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($permission->fct_name); ?></td>
                        <td>
                            <span class="d-flex">
                                <span class="mx-2">All</span>
                                <input type="checkbox" class="form-check-input all_checkbox" data-id="<?php echo e($index); ?>"
                                    id="all<?php echo e($index); ?>" 
                                    <?php echo e($permission->is_read && $permission->is_write && $permission->is_update && $permission->is_delete ? 'checked' : ''); ?>/>
                            </span>
                        </td>
                        <td>
                            <span class="d-flex">
                                <span class="mx-2">Read</span>
                                <input type="hidden" name="type_id" value="<?php echo e($id); ?>">
                                <input type="hidden" name="id[<?php echo e($index); ?>]" value="<?php echo e($permission->function_id); ?>">
                                <input type="checkbox" name="is_read[<?php echo e($index); ?>]" class="form-check-input"
                                    id="read<?php echo e($index); ?>" <?php echo e($permission->is_read ? 'checked' : ''); ?> />
                            </span>
                        </td>
                        <td>
                            <span class="d-flex">
                                <span class="mx-2">Write</span>
                                <input type="checkbox" name="is_write[<?php echo e($index); ?>]" class="form-check-input"
                                    id="write<?php echo e($index); ?>" <?php echo e($permission->is_write ? 'checked' : ''); ?> />
                            </span>
                        </td>
                        <td>
                            <span class="d-flex">
                                <span class="mx-2">Update</span>
                                <input type="checkbox" name="is_update[<?php echo e($index); ?>]" class="form-check-input"
                                    id="update<?php echo e($index); ?>" <?php echo e($permission->is_update ? 'checked' : ''); ?> />
                            </span>
                        </td>
                        <td>
                            <span class="d-flex">
                                <span class="mx-2">Delete</span>
                                <input type="checkbox" name="is_delete[<?php echo e($index); ?>]" class="form-check-input"
                                    id="delete<?php echo e($index); ?>" <?php echo e($permission->is_delete ? 'checked' : ''); ?> />
                            </span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
    </table>

    <div class="my-3 d-md-flex justify-content-end">
        <button class="btn btn-success" type="submit" id="save">Update</button>
    </div>
    </form>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $(document).on('click', '.all_checkbox', function(e) {
                var index = $(this).data('id');
                if ($(this).is(':checked')) {
                    $(`#read${index}, #write${index}, #update${index},#delete${index}`).prop('checked',
                        true);
                } else {
                    $(`#read${index}, #write${index}, #update${index},#delete${index}`).prop('checked',
                        false);
                }
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/permissions/permission_control.blade.php ENDPATH**/ ?>