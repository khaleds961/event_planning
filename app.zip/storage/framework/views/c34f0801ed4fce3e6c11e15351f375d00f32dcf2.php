
<?php $__env->startSection('title', 'Admins'); ?>
<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <div class="d-flex justify-content-between">
            <ol class="breadcrumb border border-warning px-3 py-2 rounded">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                            class="ti ti-home fs-4 mt-1"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="#" class="text-warning">Permissions</a>
                </li>
            </ol>

            <div>
                <a type="button" class="btn mb-1 waves-effect waves-light btn-light text-dark fs-4" data-bs-toggle="modal"
                    data-bs-target="#usertypeModal" id="modal_button">
                    <i class="ti ti-circle-plus"></i>
                    <span>Add New Type</span>
                </a>
            </div>
        </div>
    </nav>

    <div class="card my-2">
        <div class="card-body">
            <div class="my-2">
                <div class="table-responsive rounded-2 my-4">
                    <div class="table-responsive mx-3">
                        <table id="permissions-list" class="table border table-striped table-bordered display text-nowrap">
                            <thead>
                                <!-- start row -->
                                <tr>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">id</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">type</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">is active</h6>
                                    </th>
                                    <th></th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">action</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">staff</h6>
                                    </th>
                                </tr>
                                <!-- end row -->
                            </thead>
                            <tbody>
                                <!-- start row -->
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- BEGIN Staff MODAL -->
    <div class="modal fade" id="staffModal" tabindex="-1" aria-labelledby="staffModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staffModalLabel">
                        <span id="type_title">Show Staff</span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive rounded-2 my-4">
                        <div class="table-responsive mx-3">
                            <table id="staff_by_type" class="table border table-striped table-bordered display text-nowrap">
                                <thead>
                                    <tr>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">id</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">full name</h6>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                    </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- BEGIN MODAL -->
    <div class="modal fade" id="usertypeModal" tabindex="-1" aria-labelledby="usertypeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="usertypeModalLabel">
                        <span id="type_title">Add New User Type</span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('permission.store')); ?>" method='POST' id="submit_store">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="mt-2">
                                <label class="form-label">Type<b class="text-danger">*</b></label>
                                <input id="user_type" type="text" class="form-control" name="name" />
                                <span id="type_error"></span>
                            </div>
                            <div class="d-flex justify-content-end mt-3">
                                <button type="button" class="btn" data-bs-dismiss="modal">
                                    Close
                                </button>
                                <button type="submit" class="btn btn-success btn-add-event" id="save_type">
                                    <i class="ti ti-device-floppy"></i>
                                    Save
                                </button>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {
            // var bookedDates = new bootstrap.Modal(document.getElementById("booked_days"));

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#permissions-list').DataTable({
                processing: true,
                serverSide: true,
                scrollY: '100%',
                scrollCollapse: true,
                paging: true,
                responsive: true,
                ajax: "<?php echo e(route('permission.index')); ?>",
                columns: [{
                        data: 'id',
                        name: 'id',
                    },
                    {
                        data: 'type',
                        name: 'type',
                    },
                    {
                        data: 'active',
                        name: 'active',
                    },

                    {
                        data: 'permission',
                        name: 'permission',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    },
                    {
                        data: 'staff',
                        name: 'staff',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    }

                ],
                order: [0, 'desc'],
            });

            $(document).on('click', '#modal_button', function(e) {
                $('#type_title').text('Add New User Type')
                $('#user_type').val('');
                $('#type_error').empty();
                $('.btn-add-event').attr('id', 'save_type');
                $('#save_type').removeAttr('data-id');
            });

            var edit_id;
            $(document).on('click', '.modal_button_edit', function(e) {
                e.preventDefault();
                $('#type_error').empty();
                $('#type_title').text('Edit User Type');
                $('#user_type').val($(this).data('type_name'));
                $('.btn-add-event').attr('id', 'update_type').attr('data-id', $(this).data('id'));
                edit_id = $(this).data('id');
            });

            $(document).on('click', '#update_type', function(e) {
                e.preventDefault()
                $('#type_error').empty();
                var type_name = $('#user_type').val();
                if (type_name < 1) {
                    $('#type_error').append(
                        '<span class="err text-upercase text-danger">Required !!</span>')
                } else {
                    $('#type_error').empty();
                }
                if ($('.err').length == 0) {
                    $.ajax({
                        url: "<?php echo e(route('permission.update')); ?>",
                        data: {
                            id: edit_id,
                            name: type_name
                        },
                        type: 'POST',
                        success: function(data) {
                            console.log(data);
                            if (data.success) {
                                swal({
                                    title: "Success",
                                    text: 'Record Updated Successfully',
                                    icon: "success",
                                }).then(function() {
                                    location.reload();
                                });
                            }
                        },
                        error: function(xhr, status, error) {
                            // Handle the error response here
                            var response = xhr.responseJSON;
                            if (response && response.errors) {
                                // Handle the validation errors here
                                var errors = response.errors;
                                swal({
                                    title: "error",
                                    text: 'Type is Required',
                                    icon: "warning",
                                });
                            }
                        }
                    })
                }
            });

            $(document).on('click', '#save_type', function(e) {
                e.preventDefault();
                $('#type_error').empty();

                var type = $('#user_type').val()
                // console.log(type);return
                if (type < 1) {
                    $('#type_error').append(
                        '<span class="err text-upercase text-danger">Required !!</span>')
                } else {
                    $('#type_error').empty();
                }

                if ($('.err').length == 0) {
                    $('#submit_store').submit()
                }
            });

            $(document).on('click', '.show_staff_button', function(e) {
                var type_id = $(this).data('id');
                var url = "<?php echo e(url('')); ?>";

                if ($.fn.DataTable.isDataTable('#staff_by_type')) {
                    $('#staff_by_type').DataTable().destroy(); // Destroy the existing DataTable
                }

                var table = $('#staff_by_type').DataTable({
                    processing: true,
                    serverSide: true,
                    scrollY: '100%',
                    scrollCollapse: true,
                    paging: true,
                    responsive: true,
                    ajax: url + `/getstaffbytype/${type_id}`,
                    columns: [{
                            data: 'id',
                            name: 'id',
                        },
                        {
                            data: 'full_name',
                            name: 'full_name',
                        },
                    ],
                    order: [0, 'desc'],
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\sportciety_club\resources\views/permissions/index.blade.php ENDPATH**/ ?>