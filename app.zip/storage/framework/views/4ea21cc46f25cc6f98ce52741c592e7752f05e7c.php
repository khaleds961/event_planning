<?php if(Helper::check_permission($function_id, 'is_delete')): ?>
    <a class="show_confirmed text-warning delete_icon" data-id="<?php echo e($id); ?>"
        data-table_name="<?php echo e($table_name); ?>" style="cursor: pointer">
        <i class="ti ti-trash me-1 fs-6"></i>
    </a>
<?php endif; ?><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/court_items/action.blade.php ENDPATH**/ ?>