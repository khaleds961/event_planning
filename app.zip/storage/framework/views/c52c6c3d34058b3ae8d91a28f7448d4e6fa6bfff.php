
<?php $__env->startSection('title', 'Summary'); ?>
<?php $__env->startSection('content'); ?>


    <div class="row">

        <div class="col-sm-12 col-md-3">
            <div class="mb-3">
                <label for="datefrom" class="control-label col-form-label">FROM</label>
                <input type="text" class="form-control datepicker" id="datefrom" value="<?php echo e(request()->get('date_from')); ?>" />
            </div>
        </div>

        <div class="col-sm-12 col-md-3">
            <div>
                <label for="dateto" class="control-label col-form-label">TO</label>
                <input type="text" class="form-control datepicker" id="dateto" value="<?php echo e(request()->get('date_to')); ?>" />
            </div>
        </div>

        <div class="col-sm-12 col-md-3">
            <div>
                <label for="sports" class="control-label col-form-label">SPORTS</label>
                <select class="form-control" id="sports" onchange="getCourts()">
                    <option selected value="none">--None--</option>
                    <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sport['id']); ?>"
                            <?php echo e(request()->get('sport_id') == $sport['id'] ? 'selected' : ''); ?>><?php echo e($sport['name']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="col-sm-12 col-md-3">
            <div>
                <label for="courts" class="control-label col-form-label">COURTS</label>
                <select class="form-control" id="courts">
                    <option selected value="none">--None--</option>
                </select>
            </div>
        </div>

    </div>

    <div class="d-flex mt-3 mt-md-0">
        
        <div>
            <button class="btn btn-danger" onclick="search()">
                <i class="ti ti-search"></i>
                <span class="mx-2">Search</span>
            </button>
        </div>
        
        <div class="mx-2"></div>
        
        <div>
            <button class="btn btn-primary" onclick="clearsearch()">
                <i class="ti ti-eraser"></i>
                <span class="mx-2">Clear</span>
            </button>
        </div>
        
    </div>

    <div class="row mt-3">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body p-4">
                    <div>
                        <h5 class="d-flex justify-content-between">
                            <span style="color: #808080">Profit And Loss</span>
                            
                            <span style="color:#52b900" class="timeline fs-2"></span>
                        </h5>
                    </div>
                    <div class="container mt-4">
                        <div class="row">
                            <div class="col-md-12 d-flex align-items-center justify-content-center">
                                <!-- Content of the centered div -->
                                <h3>$ <?php echo e(number_format($net_profit, 2, '.', ',')); ?></h3>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 d-flex align-items-center justify-content-center">
                                <!-- Content of the centered div -->
                                <h5 style="color: #808080">Total Profit</h5>
                            </div>
                        </div>

                        <div class="row d-flex align-items-center mt-3">
                            <div class="col-8">
                                
                                <div class="progress" style="height: 30px">
                                    <div class="progress-bar" role="progressbar"
                                        style="width: <?php echo e($revenue_percentage); ?>%;background-color:#50b900"></div>
                                    <div class="progress-bar" role="progressbar"
                                        style="width: <?php echo e($expenses_percentage); ?>%;background-color:#dff1c9"></div>
                                </div>
                            </div>
                            <div class="col-4">
                                
                                <h6 title="Reservations Income <?php echo e(number_format($revenue,2)); ?> $/ Sales Income <?php echo e(number_format($sales,2)); ?> $" style="cursor: pointer">$ <?php echo e(number_format($revenue_sales,2)); ?> Income</h6>
                            </div>
                        </div>

                        <div class="row d-flex align-items-center mt-4">
                            <div class="col-6">
                                <div class="progress" style="height: 30px">
                                    <div class="progress-bar" role="progressbar"
                                        style="width: <?php echo e($expenses_percentage); ?>%;background-color:#00a8a3"></div>
                                    <div class="progress-bar" role="progressbar"
                                        style="width: <?php echo e($revenue_percentage); ?>%;background-color:#c8efec"></div>
                                </div>
                            </div>
                            <div class="col-6">
                                <h6>$ <?php echo e(number_format($expenses, 2, '.', ',')); ?> Expenses</h6>
                            </div>
                        </div>

                        <div class="border-bottom mt-3"></div>

                        <div class="row mt-3">
                            <div class="col-md-12 d-flex align-items-center justify-content-center">
                                <a href="<?php echo e(route('index')); ?>">
                                    <span style="color:#52b900"><strong>See More</strong></span>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card">
                <div class="card-body p-4">
                    <div>
                        <h5 class="d-flex justify-content-between card-title fw-semibold">
                            <span style="color: #808080">Invoices</span>
                        </h5>
                    </div>
                    <div class="container mt-4">
                        <div class="row">
                            <div class="col-md-12 d-flex align-items-center justify-content-center">
                                <!-- Content of the centered div -->
                                <h3>$ <?php echo e(number_format($expenses_in, 2, '.', ',')); ?> </h3>
                            </div>
                        </div>

                        <span style="color:#52b900" class="timeline fs-2"></span>
                        <div class="row">
                            <div class="col-md-12 d-flex align-items-center justify-content-center">
                                <!-- Content of the centered div -->
                                <h5 style="color: #808080">Unpaid</h5>
                            </div>
                        </div>

                        <div class="d-flex mt-3 justify-content-between">
                            <h6><span style="color:#e4946e">$ <?php echo e(number_format($expenses_out, 2, '.', ',')); ?></span></h6>
                            <h6> <span>$ <?php echo e(number_format($unpaid_expenses, 2, '.', ',')); ?></span></h6>
                        </div>
                        <div class="d-flex justify-content-between">
                            <h6>Overdue</h6>
                            <h6>Not due yet</h6>
                        </div>

                        <div class="row d-flex align-items-center mt-3">
                            <div class="col-12">
                                <div class="progress" style="height: 30px">
                                    <div class="progress-bar" role="progressbar"
                                        style="width: <?php echo e($overdue_percentage); ?>%;background-color:#f66147
                                        ">
                                    </div>
                                    <div class="progress-bar" role="progressbar"
                                        style="width: <?php echo e($not_due_percentage); ?>%;background-color:#f3f4f6
                                        ">
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        // Get the URL parameters
        const urlParams = new URLSearchParams(window.location.search);

        // var first_day_of_month = moment().startOf('month').format('YYYY-MM-DD');
        // var last_day_of_month = moment().endOf('month').format('YYYY-MM-DD');

        var date_from = urlParams.get('date_from');
        var date_to = urlParams.get('date_to');

        // if (!date_from && !date_to) {
        //     $('#datefrom').val(first_day_of_month);
        //     $('#dateto').val(last_day_of_month);
        // }

        if (!date_from && !date_to) {
            $('.timeline').text('From the beginning of the year to its end.');
        }else{
            $('.timeline').text('');
        }

        // Extract the sport_id parameter from the URL
        var courtId = urlParams.get('court_id');

        // Extract the sport_id parameter from the URL
        const sportId = urlParams.get('sport_id');
        // Check if sport_id exists and has a valid value
        if (sportId && sportId !== '') {
            // Sport ID exists and is not empty
            getCourts(sportId)
        } else {
            // Sport ID does not exist or is empty
            console.log('Sport ID does not exist or is empty');
        }

        function search() {
            var URL = "<?php echo e(route('summary.index')); ?>";
            var date_from = $('#datefrom').val().trim();
            if (date_from) {
                var parsedDate = moment(date_from, "MM/DD/YYYY", true);
                var convertedDate = parsedDate.isValid() ? parsedDate.format("YYYY-MM-DD") : date_from;
                date_from = convertedDate;
            }
            var date_to = $('#dateto').val().trim();
            if (date_to) {
                var parsedDate = moment(date_to, "MM/DD/YYYY", true);
                var convertedDate = parsedDate.isValid() ? parsedDate.format("YYYY-MM-DD") : date_to;
                date_to = convertedDate;
            }
            var sport_id = $('#sports').val().trim();
            var court_id = $('#courts').val();

            var element = [];

            if (date_from && date_to) {
                element.push('date_from=' + date_from);
                element.push('date_to=' + date_to);
            }

            if (sport_id && sport_id != null && sport_id != 'none') {
                element.push('sport_id=' + sport_id);
            }

            if (court_id && court_id != null && court_id != 'none') {
                element.push('court_id=' + court_id)
            }

            if (element.length > 0) {
                URL += '?' + element.join('&');
            } else {
                location.href = "<?php echo e(route('summary.index')); ?>";
            }

            location.href = URL;

        }

        function clearsearch() {
            var URL = "<?php echo e(route('summary.index')); ?>";
            $('#datefrom').val('');
            $('#dateto').val('');
            $('#sports').val('none');
            $('#courts').empty();
            $('#courts').append($('<option>', {
                value: 'none',
                text: 'None'
            })).val('none');
        }

        function getCourts(sport_id = 0) {
            if (!sport_id) {
                var sport_id = $('#sports').val();
            }
            $('#courts').empty();
            $('#courts').append('<option selected disabled>--None--</option>');
            if (sport_id && sport_id != 0) {
                $.ajax({
                    url: "<?php echo e(route('booking.sportsbycourt')); ?>",
                    data: {
                        sport_id: sport_id
                    },
                    type: 'POST',
                    success: function(response) {
                        console.log(response);
                        if (response.success) {
                            var data = response.data;
                            for (var i = 0; i < data.length; i++) {
                                var option = $('<option>', {
                                    value: data[i].id,
                                    text: data[i].title_en
                                });
                                $('#courts').append(option);
                                // Check if court_id exists and has a valid value
                                if (courtId && courtId !== '') {
                                    $('#courts').val(courtId);
                                }
                            }
                        }
                    }
                });
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sportcietyapp/public_html/platform.sportcietyapp.com/resources/views/summary/index.blade.php ENDPATH**/ ?>