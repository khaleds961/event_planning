
<?php $__env->startSection('title', 'Schedule'); ?>

<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <ol class="breadcrumb border border-warning px-3 py-2 rounded">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                        class="ti ti-home fs-4 mt-1"></i></a>
            </li>
            <li class="breadcrumb-item">
                <a href="#" class="text-warning">Schedule</a>
            </li>
        </ol>
    </nav>

    <div class="row">

        <div class='d-flex justify-content-between'>

            <div class="col-sm-12 col-md-2">
                <!-- ------------------------------------------ -->
                <!-- Medium -->
                <!-- ------------------------------------------ -->
                <button class="btn me-1 my-3 btn-light-warning text-warning btn-lg px-4 fs-4 font-medium"
                    data-bs-toggle="modal" data-bs-target="#bs-example-modal-md">
                    ADD BOOKING
                </button>
                <!-- sample modal content -->
                <div id="bs-example-modal-md" class="modal fade" tabindex="-1" aria-labelledby="bs-example-modal-md"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                                <h4 class="modal-title" id="myModalLabel">
                                    Medium Modal
                                </h4>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <h4>
                                    Overflowing text to show scroll behavior
                                </h4>
                                <p>
                                    Praesent commodo cursus magna, vel scelerisque
                                    nisl consectetur et. Vivamus sagittis lacus
                                    vel augue laoreet rutrum faucibus dolor
                                    auctor.
                                </p>
                                <p>
                                    Aenean lacinia bibendum nulla sed consectetur.
                                    Praesent commodo cursus magna, vel scelerisque
                                    nisl consectetur et. Donec sed odio dui. Donec
                                    ullamcorper nulla non metus auctor fringilla.
                                </p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-light-danger text-danger font-medium waves-effect"
                                    data-bs-dismiss="modal">
                                    Close
                                </button>
                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
            </div>

            <div class="col-4">

                <div class="d-flex justify-content-between align-items-center my-3">

                    <button class="btn btn-light-warning text-warning">
                        <i class="ti ti-arrow-left" style="font-size: 25px;"></i>
                    </button>

                    <div class="">
                        <input type="date" class="form-control py-2" id="dateopen" value="<?php echo date('Y-m-d'); ?>" />
                    </div>

                    <button class="btn btn-light-warning text-warning">
                        <i class="ti ti-arrow-right" style="font-size: 25px;"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="row">

        <div class="col">
            <div>
                <h4>Court 1</h4>
            </div>
            <div class="tab-content">
                <div id="note-full-container" class="note-has-grid">

                    <div class="row">
                        <div class="col-12">
                            <div class="col single-note-item all-category">
                                <div class="card card-body">
                                    <span class="side-stick"></span>
                                    <h6 class="note-title text-truncate w-75 mb-0"
                                        data-noteHeading="Book a Ticket for Movie">
                                        Book a Ticket for Movie </h6>
                                    <p class="note-date fs-2">11 March 2009</p>
                                    <div class="note-content">
                                        <p class="note-inner-content"
                                            data-noteContent="Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.">
                                            Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="col single-note-item all-category">
                                <div class="card card-body">
                                    <span class="side-stick"></span>
                                    <h6 class="note-title text-truncate w-75 mb-0"
                                        data-noteHeading="Book a Ticket for Movie">
                                        Book a Ticket for Movie </h6>
                                    <p class="note-date fs-2">11 March 2009</p>
                                    <div class="note-content">
                                        <p class="note-inner-content"
                                            data-noteContent="Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.">
                                            Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="col single-note-item all-category">
                                <div class="card card-body">
                                    <span class="side-stick"></span>
                                    <h6 class="note-title text-truncate w-75 mb-0"
                                        data-noteHeading="Book a Ticket for Movie">
                                        Book a Ticket for Movie </h6>
                                    <p class="note-date fs-2">11 March 2009</p>
                                    <div class="note-content">
                                        <p class="note-inner-content"
                                            data-noteContent="Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.">
                                            Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="col single-note-item all-category">
                                <div class="card card-body">
                                    <span class="side-stick"></span>
                                    <h6 class="note-title text-truncate w-75 mb-0"
                                        data-noteHeading="Book a Ticket for Movie">
                                        Book a Ticket for Movie </h6>
                                    <p class="note-date fs-2">11 March 2009</p>
                                    <div class="note-content">
                                        <p class="note-inner-content"
                                            data-noteContent="Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.">
                                            Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="col">
            <div>
                <h4>Court 2</h4>
            </div>
            <div class="tab-content">
                <div id="note-full-container" class="note-has-grid">

                    <div class="row">
                        <div class="col-12">
                            <div class="col single-note-item all-category">
                                <div class="card card-body">
                                    <span class="side-stick"></span>
                                    <h6 class="note-title text-truncate w-75 mb-0"
                                        data-noteHeading="Book a Ticket for Movie">
                                        Book a Ticket for Movie </h6>
                                    <p class="note-date fs-2">11 March 2009</p>
                                    <div class="note-content">
                                        <p class="note-inner-content"
                                            data-noteContent="Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.">
                                            Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="col single-note-item all-category">
                                <div class="card card-body">
                                    <span class="side-stick"></span>
                                    <h6 class="note-title text-truncate w-75 mb-0"
                                        data-noteHeading="Book a Ticket for Movie">
                                        Book a Ticket for Movie </h6>
                                    <p class="note-date fs-2">11 March 2009</p>
                                    <div class="note-content">
                                        <p class="note-inner-content"
                                            data-noteContent="Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.">
                                            Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="col single-note-item all-category">
                                <div class="card card-body">
                                    <span class="side-stick"></span>
                                    <h6 class="note-title text-truncate w-75 mb-0"
                                        data-noteHeading="Book a Ticket for Movie">
                                        Book a Ticket for Movie </h6>
                                    <p class="note-date fs-2">11 March 2009</p>
                                    <div class="note-content">
                                        <p class="note-inner-content"
                                            data-noteContent="Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.">
                                            Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="col single-note-item all-category">
                                <div class="card card-body">
                                    <span class="side-stick"></span>
                                    <h6 class="note-title text-truncate w-75 mb-0"
                                        data-noteHeading="Book a Ticket for Movie">
                                        Book a Ticket for Movie </h6>
                                    <p class="note-date fs-2">11 March 2009</p>
                                    <div class="note-content">
                                        <p class="note-inner-content"
                                            data-noteContent="Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.">
                                            Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="col">
            <div>
                <h4>Court 3</h4>
            </div>
            <div class="tab-content">
                <div id="note-full-container" class="note-has-grid">

                    <div class="row">
                        <div class="col-12">
                            <div class="col single-note-item all-category">
                                <div class="card card-body">
                                    <span class="side-stick"></span>
                                    <h6 class="note-title text-truncate w-75 mb-0"
                                        data-noteHeading="Book a Ticket for Movie">
                                        Book a Ticket for Movie </h6>
                                    <p class="note-date fs-2">11 March 2009</p>
                                    <div class="note-content">
                                        <p class="note-inner-content"
                                            data-noteContent="Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.">
                                            Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="col single-note-item all-category">
                                <div class="card card-body">
                                    <span class="side-stick"></span>
                                    <h6 class="note-title text-truncate w-75 mb-0"
                                        data-noteHeading="Book a Ticket for Movie">
                                        Book a Ticket for Movie </h6>
                                    <p class="note-date fs-2">11 March 2009</p>
                                    <div class="note-content">
                                        <p class="note-inner-content"
                                            data-noteContent="Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.">
                                            Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="col single-note-item all-category">
                                <div class="card card-body">
                                    <span class="side-stick"></span>
                                    <h6 class="note-title text-truncate w-75 mb-0"
                                        data-noteHeading="Book a Ticket for Movie">
                                        Book a Ticket for Movie </h6>
                                    <p class="note-date fs-2">11 March 2009</p>
                                    <div class="note-content">
                                        <p class="note-inner-content"
                                            data-noteContent="Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.">
                                            Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="col single-note-item all-category">
                                <div class="card card-body">
                                    <span class="side-stick"></span>
                                    <h6 class="note-title text-truncate w-75 mb-0"
                                        data-noteHeading="Book a Ticket for Movie">
                                        Book a Ticket for Movie </h6>
                                    <p class="note-date fs-2">11 March 2009</p>
                                    <div class="note-content">
                                        <p class="note-inner-content"
                                            data-noteContent="Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.">
                                            Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>





<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/schedule/_index.blade.php ENDPATH**/ ?>