
<?php $__env->startSection('title', 'Courts'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-sm-12 col-md-3">
            <div class="mb-3">
                <label for="dateopen" class="control-label col-form-label">FROM</label>
                <input type="date" class="form-control" id="dateopen" />
            </div>
        </div>

        <div class="col-sm-12 col-md-3">
            <div class="mb-3">
                <label for="datefixe" class="control-label col-form-label">TO</label>
                <input type="date" class="form-control" id="datefixe" />
            </div>
        </div>

        <div class="col-sm-12 col-md-3">
            <div class="mb-3">
                <label for="sports" class="control-label col-form-label">SPORTS</label>
                <select class="form-control select2" id="sports">
                    <option>Select</option>

                </select>
            </div>
        </div>

        <div class="col-sm-12 col-md-3">
            <div class="mb-3">
                <label for="courts" class="control-label col-form-label">COURTS</label>
                <select class="form-control select2" id="courts">
                    <option>Select</option>

                </select>
            </div>
        </div>

        <div class="col">
            <button class="btn btn-danger">
                <i class="ti ti-search"></i>
                <span class="mx-3">Search</span>
            </button>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-sm-6 col-lg-3 col-xl-3">
            <a href="page-user-profile.html" class="p-4 text-center bg-light-primary card shadow-none rounded-2">
                <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/svgs/icon-user-male.svg"
                    width="50" height="50" class="mb-6 mx-auto" alt="">
                <p class="fw-semibold text-primary mb-1">Customers</p>
                <h4 class="fw-semibold text-primary mb-0">3,685</h4>
            </a>
        </div>
        <div class="col-sm-6 col-lg-3 col-xl-3">
            <a href="javascript:void(0)" class="p-4 text-center bg-light-warning card shadow-none rounded-2">
                <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/svgs/icon-briefcase.svg"
                    width="50" height="50" class="mb-6 mx-auto" alt="">
                <p class="fw-semibold text-warning mb-1">Booking</p>
                <h4 class="fw-semibold text-warning mb-0">256</h4>
            </a>
        </div>
        <div class="col-sm-6 col-lg-3 col-xl-3">
            <a href="app-email.html" class="p-4 text-center bg-light-danger card shadow-none rounded-2">
                <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/svgs/icon-favorites.svg"
                    width="50" height="50" class="mb-6 mx-auto" alt="">
                <p class="fw-semibold text-danger mb-1">Revenue</p>
                <h4 class="fw-semibold text-danger mb-0">$348K</h4>
            </a>
        </div>
        <div class="col-sm-6 col-lg-3 col-xl-3">
            <a href="app-chat.html" class="p-4 text-center bg-light-success card shadow-none rounded-2">
                <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/svgs/icon-speech-bubble.svg"
                    width="50" height="50" class="mb-6 mx-auto" alt="">
                <p class="fw-semibold text-success mb-1">Profile Views</p>
                <h4 class="fw-semibold text-success mb-0">96</h4>
            </a>
        </div>
    </div>

    <section>
        <div class="row">
            <!-- Start Basic Bar Chart -->
            <div class="col-12 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <h4>BOOKING</h4>
                        <div id="chart-bar-basic"></div>
                    </div>
                </div>
            </div>
            <!-- End Basic Bar Chart -->

            <!-- Start top per card -->
            <div class="col-12 col-lg-4">
                <div class="card" style="height: 457px;">
                    <div class="card-body">
                        <h4>TOP PERFORMING</h4>
                        <table class="mb-3 table">
                            <thead class="bg-success text-white">
                                <tr>
                                    <th>COURT</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Nigam</td>
                                    <td>336</td>
                                </tr>
                                <tr>
                                    <td>Prohaska</td>
                                    <td>126</td>
                                </tr>
                                <tr>
                                    <td>Rogahn</td>
                                    <td>102</td>
                                </tr>
                                <tr>
                                    <td>Batroun</td>
                                    <td>90</td>
                                </tr>
                                <tr>
                                    <td>Sagesse</td>
                                    <td>85</td>
                                </tr>
                                <tr>
                                    <td>Riyadi</td>
                                    <td>19</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End top per card -->

            <!-- Start top per card -->
            <div class="col-12 col-lg-4">
                <div class="card" style="height: 457px;">
                    <div class="card-body">
                        <h4>CUSTOMERS</h4>
                        <table class="mb-3 table">
                            <thead class="bg-warning text-white">
                                <tr>
                                    <th>NAME</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Abdo</td>
                                    <td>336</td>
                                </tr>
                                <tr>
                                    <td>Marc</td>
                                    <td>126</td>
                                </tr>
                                <tr>
                                    <td>Saad</td>
                                    <td>102</td>
                                </tr>
                                <tr>
                                    <td>Mahmoud</td>
                                    <td>90</td>
                                </tr>
                                <tr>
                                    <td>Fouad</td>
                                    <td>85</td>
                                </tr>
                                <tr>
                                    <td>Assaad</td>
                                    <td>19</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End top per card -->

        </div>
        
    </section>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\khaled.alhoussein\Desktop\sporciety_new\sportciety_club\resources\views/dashboard/index.blade.php ENDPATH**/ ?>