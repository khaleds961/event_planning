<a style="cursor:pointer" href="<?php echo e(route('sales_items.index',['id' => $row->player_id])); ?>">
    <i class="ti ti-eye fs-7"></i>
</a><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/sales/actions.blade.php ENDPATH**/ ?>