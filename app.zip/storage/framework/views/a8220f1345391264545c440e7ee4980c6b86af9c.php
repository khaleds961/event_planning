
<?php $__env->startSection('title', 'Booking'); ?>
<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <div class="d-flex justify-content-between">
            <ol class="breadcrumb border border-warning px-3 py-2 rounded">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                            class="ti ti-home fs-4 mt-1"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="#" class="text-warning">Bookings</a>
                </li>
            </ol>


            <div class="mx-2">
                <a type="button" class="btn mb-1 waves-effect waves-light btn-light text-dark fs-4 mx-0 mx-md-2"
                    data-bs-toggle="modal" data-bs-target="#eventModal" id="modal_button">
                    <i class="ti ti-circle-plus"></i>
                    <span>Add New Booking</span>
                </a>

                <a type="button" class="btn mb-1 waves-effect waves-secondary btn-secondary text-light fs-4"
                    href="<?php echo e(route('calendar.index', ['id' => $firstId])); ?>">
                    <i class="ti ti-calendar-event"></i>
                    <span>Go To Schedule</span>
                </a>
            </div>
        </div>
    </nav>

    <div class="row mt-4">
        <div class="col-12">
            <div class="row">
                <div class="col-md-2">
                    <div class="mb-3 has-success">
                        <label class="control-label">FROM</label>
                        <input type="text" class="form-control datepicker" id="start_date">
                        <span id="start_date_error"></span>
                    </div>
                </div>
                <!--/span-->
                <div class="col-md-2">
                    <div class="mb-3">
                        <label class="control-label">TO</label>
                        <input type="input" class="form-control datepicker" id="end_date">
                        <span id="end_date_error"></span>
                    </div>
                </div>
                <!--/span-->

                <div class="col-md-6">
                    <button class="btn btn-dark margin_top_responsive" id="search_bookings">
                        <i class="ti ti-search"></i>
                        <span>Search</span>
                    </button>

                    <button class="btn btn-primary margin_top_responsive mx-2" id="clear_bookings">
                        <i class="ti ti-brush"></i>
                        <span>Clear Dates</span>
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <!--/span-->
                    <div>
                        <div>
                            <div class="d-flex justify-content-center justify-content-md-start">
                                <button type="button"
                                    class="btn mb-1 waves-effect waves-light btn-warning status_button pending_button"
                                    value="0">
                                    PENDING
                                </button>
                                <button type="button"
                                    class="btn mb-1 waves-effect waves-light btn-success status_button confirm_button mx-2 mx-md-3"
                                    value="1">
                                    UPCOMING
                                </button>
                                <button type="button"
                                    class="btn mb-1 waves-effect waves-light btn-danger status_button history_button"
                                    value="2">
                                    HISTORY
                                </button>
                            </div>
                            
                        </div>
                    </div>
                    <!--/span-->

                    <div class="my-2">
                        <div class="d-md-flex justify-content-end">
                            <!-- BEGIN MODAL -->
                            <div class="modal fade" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel"
                                aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="eventModalLabel">
                                                Add Booking
                                            </h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="d-flex"
                                                        style="border: 2px solid orange; border-radius: 5px; padding: 5px;">
                                                        <input type="text" id="search-input"
                                                            placeholder="Search player by name" class="form-control"
                                                            style="border: none; flex: 1;">
                                                        <select id="user-select" class="form-control"
                                                            style="border: none; flex: 1;"></select>
                                                    </div>
                                                    <span id="player_error"></span>
                                                </div>

                                                <div id="new_member">

                                                    <button type="btn" class="btn btn-primary mt-3"
                                                        style="display: none" id="new_member_button">
                                                        <span>Add New Member</span>
                                                        <i class="ti ti-circle-plus"></i>
                                                    </button>

                                                    <div class="p-4 border rounded mt-4" id="new_member_content"
                                                        style="display: none">
                                                        <div class="row">
                                                            <div class="col-md-6 mt-3">
                                                                <label for="full_name">Full Name
                                                                    <b class="text-danger">*</b>
                                                                </label>
                                                                <input type="text" class="form-control" id="full_name"
                                                                    name="full_name">
                                                                <span class="text-danger text-uppercase"
                                                                    id="full_name_error"></span>
                                                            </div>

                                                            <div class="col-md-6 mt-3">
                                                                <label for="birth_date">Birth Date
                                                                    <b class="text-danger">*</b>
                                                                </label>
                                                                <input type="date" class="form-control"
                                                                    id="birth_date" name="birth_date">
                                                                <span class="text-danger text-uppercase"
                                                                    id="birth_date_error"></span>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="col-md-6 mt-3">
                                                                <label for="email">Email
                                                                    <b class="text-danger">*</b>
                                                                </label>
                                                                <input type="text" class="form-control" id="email"
                                                                    name="email">
                                                                <span class="text-danger text-uppercase"
                                                                    id="email_error"></span>
                                                            </div>

                                                            <div class="col-md-6 mt-3">
                                                                <label for="phone_number">Phone Number
                                                                    <b class="text-danger">*</b>
                                                                </label>
                                                                <div>
                                                                    <input type="tel" class="form-control"
                                                                        name="phone_number" id="phone_number"
                                                                        placeholder="Phone Number" required>
                                                                </div>
                                                                <span id="phone_number_error"
                                                                    class="text-uppercase text-danger h6"></span>
                                                                <span id="phone_number_valid"
                                                                    class="text-uppercase text-success h6"></span>
                                                                <span id="phone_err"
                                                                    class="text-uppercase text-success h6"></span>
                                                            </div>


                                                        </div>


                                                        <div>
                                                            <button type="btn" class="btn btn-success mt-3"
                                                                id="save_member">
                                                                <span>Save</span>
                                                                <i class="ti ti-device-floppy"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row mt-4">

                                                <div class="col-md-6">
                                                    <label for="sport_type" class="form-label">Sport<b
                                                            class="text-danger">*</b></label>
                                                    <select class="form-control my-1" name="sport_id" id="sport_id">
                                                        <option disabled value="0" selected>--Select Sport--</option>
                                                        <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($sport->id); ?>"><?php echo e($sport->title); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <span id="sport_error"></span>
                                                </div>

                                                <div class="col-md-6">
                                                    <label for="court_id" class="form-label">Court<b
                                                            class="text-danger">*</b></label>
                                                    <select class="form-control my-1" name="court_id" id="court_id">
                                                        <option disabled value="0" selected>
                                                            --Select Court--
                                                        </option>
                                                        <?php $__currentLoopData = $courts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $court): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($court->id); ?>"><?php echo e($court->title_en); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <span id="court_error"></span>
                                                    <span id="court_wrong_error"></span>
                                                </div>

                                            </div>

                                            <div class="row">

                                                <div class="col-md-6 mt-2">
                                                    <div class="">
                                                        <label class="form-label">Date<b class="text-danger">*</b></label>
                                                        <input id="event-date" type="date" class="form-control" />
                                                        <span id="date_error"></span>
                                                        <span id="date_error_"></span>
                                                    </div>
                                                </div>


                                                <div class="col-md-6 mt-2">
                                                    <label class="form-label">From<b class="text-danger">*</b></label>
                                                    <select class="form-control" id="event_start" name="event_start">
                                                        <?php
                                                        $start_time = strtotime('00:00');
                                                        $end_time = strtotime('23:30');
                                                        $interval = 30 * 60; // 30 minutes
                                                        
                                                        for ($i = $start_time; $i <= $end_time; $i += $interval) {
                                                            $value = date('g:i A', $i);
                                                            echo "<option value='$value'>$value</option>";
                                                        }
                                                        ?>
                                                    </select>
                                                    <span id="event_start_error"></span>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 mt-2" id="price_input">
                                                    <label
                                                        class="form-label d-flex justify-content-between align-items-center">
                                                        <span>Price
                                                            <i class="ti ti-currency-dollar"></i>
                                                        </span>
                                                        <span id="editable_price">
                                                            <i class="ti ti-pencil" style="cursor: pointer"
                                                                data-bs-toggle="tooltip" title="Make Price Editable"></i>
                                                        </span>
                                                    </label>
                                                    <input id="court-price" type="number" class="form-control"
                                                        readonly />
                                                    <span id="price_error"></span>
                                                </div>

                                                <div class="col-md-6 mt-2">
                                                    <label for="book_session_duration" class="form-label">Duration<b
                                                            class="text-danger">*</b></label>
                                                    <input id="book_session_duration" type="text"
                                                        name="book_session_duration" class="session_minutes" />
                                                    <span id="session_minutes_error"></span>
                                                    <span id="session_minutes_empty"></span>
                                                </div>
                                            </div>


                                            <div class="col-md-12 mt-2">
                                                <label class="form-label">Notes</label>
                                                <textarea placeholder="Enter Text" class="form-control rounded h-70" name="description"></textarea>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 mt-2">
                                                    <div class="d-flex align-items-center my-7">
                                                        <span
                                                            class="text-dark fw-bolder text-capitalize me-3">Public</span>
                                                        <div class="form-check form-switch mb-0">
                                                            <input class="form-check-input" type="checkbox"
                                                                role="switch" id="private" checked="">
                                                        </div>
                                                        <span
                                                            class="text-dark fw-bolder text-capitalize ms-2">Private</span>
                                                    </div>
                                                </div>

                                                
                                            </div>

                                            <div class="row">
                                                <div class="col mt-4">
                                                    <span>Add Item(s)
                                                        <i class="ti ti-shopping-cart mx-2"></i>
                                                    </span>
                                                    <div class="search-container">
                                                        <input type="text" placeholder="Search..."
                                                            class="form-control" id="search_input">
                                                        <div class="search-results" id="search-results"></div>
                                                    </div>
                                                    <div id="items_labels" class="row my-2">
                                                        <div class='col-3 text-primary text-uppercase'>name</div>
                                                        <div class='col-3 text-primary text-uppercase'>price</div>
                                                        <div class='col-3 text-primary text-uppercase'>quantity</div>
                                                    </div>
                                                    <div class="mt-3 d-none" id="plus_court_items">
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="order-summary border rounded my-4 mx-2">
                                                        <div class="p-3">
                                                            <h5 class="fs-5 fw-semibold mb-4">Reservation Summary</h5>
                                                            <div class="d-flex justify-content-between mb-4">
                                                                <p class="mb-0 fs-4">Court</p>
                                                                <h6 class="mb-0 fs-4 fw-semibold">
                                                                    <span id="court_reservation_price"></span>
                                                                </h6>
                                                            </div>
                                                            <div class="d-flex justify-content-between mb-4">
                                                                <p class="mb-0 fs-4">Items</p>
                                                                <h6 class="mb-0 fs-4 fw-semibold text-danger">
                                                                    <span id="items_total_price"></span>
                                                                </h6>
                                                            </div>
                                                            <div class="d-flex justify-content-between">
                                                                <h6 class="mb-0 fs-4 fw-semibold">Total</h6>
                                                                <h6 class="mb-0 fs-5 fw-semibold">
                                                                    <span id="grand_total" class="text-success"></span>
                                                                </h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-end">
                                                <button type="submit" class="btn btn-success btn-add-event"
                                                    id="book_event">
                                                    Add Booking
                                                </button>
                                                <button type="submit" class="btn btn-success btn-add-event mx-2"
                                                    id="update_booking">
                                                    Update Booking
                                                </button>
                                                <span class="recurring_space"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- END MODAL -->

                    </div>

                    
                    
                    <div class="modal fade" id="recurringModal" tabindex="-1" aria-labelledby="recurringModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="recurringModalLabel">
                                        <span>Recurring</span>
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">

                                    <div id="recurring_content">

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label for="recurring_day" class="form-label">Every<b
                                                        class="text-danger">*</b></label>
                                                <select class="form-control" name="recurring_day" id="recurring_day">
                                                    <option disabled value="0" selected>--Select Day--</option>
                                                    <option value="1">Monday</option>
                                                    <option value="2">Tuesday</option>
                                                    <option value="3">Wednesday</option>
                                                    <option value="4">Thursday</option>
                                                    <option value="5">Friday</option>
                                                    <option value="6">Saturday</option>
                                                    <option value="7">Sunday</option>
                                                </select>
                                                <span id="recurring_day_error"></span>

                                            </div>

                                            <div class="col-md-6">
                                                <div>
                                                    <label class="form-label">From<b class="text-danger">*</b></label>
                                                    <select class="form-control" id="recurring_start_time">
                                                        <option value="0">--Select An Option--</option>
                                                        <?php
                                                        $start_time = strtotime('00:00');
                                                        $end_time = strtotime('23:30');
                                                        $interval = 30 * 60; // 30 minutes
                                                        
                                                        for ($i = $start_time; $i <= $end_time; $i += $interval) {
                                                            $value = date('g:i A', $i);
                                                            echo "<option value='$value'>$value</option>";
                                                        }
                                                        ?>
                                                    </select>
                                                    <span id="recurring_start_error"></span>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="col-md-12 mt-2">
                                            <label for="recurring_duration" class="form-label">Duration<b
                                                    class="text-danger">*</b></label>
                                            <input id="recurring_duration" type="text" name="recurring_duration"
                                                class="session_minutes" />
                                            <span id="recurring_duration_error"></span>
                                            <span id="recurring_duration_empty"></span>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="control-label col-form-label">Start Date<b
                                                        class="text-danger">*</b></label>
                                                <input type="date" class="form-control" id="recurring_start_date">
                                                <span id="recurring_start_date_error"></span>
                                            </div>

                                            <div class="col-md-6">
                                                <label class="control-label col-form-label">End Date<b
                                                        class="text-danger">*</b></label>
                                                <input type="date" class="form-control" id="recurring_end_date">
                                                <span id="recurring_end_date_error"></span>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn" data-bs-dismiss="modal">
                                        Close
                                    </button>
                                    <button type="button" class="btn btn-success btn-add-event"
                                        data-url="<?php echo e(route('calendar.storerecurring')); ?>" id="storerecurring">
                                        Save
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    

                    
                    <div class="modal fade" id="booked_days" tabindex="-1" aria-labelledby="booked_daysLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="booked_daysLabel">
                                        Booked/Unbooked Dates: <span id="day_name" class="text-danger fs-5 mx-2"></span>
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div id="available_days"></div>
                                        <div id="not_booked_days"></div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn" data-bs-dismiss="modal">
                                        Close
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    

                    <!-- Stop Recurring MODAL -->
                    <div class="modal fade" id="stopRecurringModal" tabindex="-1"
                        aria-labelledby="stopRecurringModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="stopRecurringModalLabel">
                                        Stop Recurring
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input danger check-outline outline-danger"
                                                    type="radio" id="danger2-outline-radio" name="recurring_interval"
                                                    value="all" checked="">
                                                <label class="form-check-label" for="danger2-outline-radio">
                                                    <h6>
                                                        Stop All Dates
                                                    </h6>
                                                </label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input danger check-outline outline-danger"
                                                    type="radio" id="danger3-outline-radio" name="recurring_interval"
                                                    value="specify">
                                                <label class="form-check-label" for="danger3-outline-radio">
                                                    <h6>
                                                        Specify Start/End Recurring Dates
                                                    </h6>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row specify_times" style="display: none">
                                        <div class="col-12">
                                            <div class="mb-1">
                                                <label for="datefrom" class="control-label col-form-label">FROM</label>
                                                <input type="text" class="form-control datepicker" id="datefrom" />
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div>
                                                <label for="dateto" class="control-label col-form-label">TO</label>
                                                <input type="text" class="form-control datepicker" id="dateto" />
                                            </div>
                                        </div>
                                    </div>

                                    <div class="d-flex justify-content-end mt-4">
                                        <button class="btn btn-success stop_reccuring">Stop Recurring</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Stop Recurring MODAL -->

                </div>



                <div class="rounded-2 table-responsive">
                    <div class="mx-4">
                        <table id="bookings-list" class="table border table-striped table-bordered display ">
                            <thead>
                                <!-- start row -->
                                <tr>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">Date</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">Time</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">sport</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">court</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">duration</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">player</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">type</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">status</h6>
                                    </th>
                                    <th>
                                        <h6 class="fs-4 fw-semibold mb-0 text-uppercase">confirm/cancel</h6>
                                    </th>
                                    <th></th>
                                </tr>
                                <!-- end row -->
                            </thead>
                            <tbody>
                                <!-- start row -->
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                        </table>
                    </div>

                </div>
            </div>
        </div>

    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        $('#session_min').attr('disabled', true);
        // var each_session_min = $('#session_min').val();
        var each_session_min = 0;
        var price_initial = 0;
        var total_items_price = 0;
        var valid_number;
        var country_code;
        var court_id;
        var saveButton = document.getElementById("save_member");
        var selectedItems = [];
        var range_start = '';
        var range_end = '';
        var player_id;
        var player_name;
        var sport_id = $('#select_sport').val();
        var recurring_duration;
        var booking_id;
        var status_id;

        // Initialize the intlTelInput plugin on the phone number input field
        var input = $("#phone_number");
        var phone_error = $('#phone_number_error');
        var phone_valid = $('#phone_number_valid');

        // Get the current year
        const currentYear = new Date().getFullYear();

        // Set the max and min years
        const maxYear = currentYear - 6;
        const minYear = currentYear - 80;

        const full_name = document.querySelector('#full_name');
        const full_nameValidation = document.querySelector('#full_name_error');

        const date_min = moment().set({
            year: minYear,
            month: 11, // Note that month values are zero-based
            date: 31,
        });

        const date_max = moment().set({
            year: maxYear,
            month: 11, // Note that month values are zero-based
            date: 31,
        });

        $('#birth_date').attr('min', date_min.format('YYYY-MM-DD'));
        $('#birth_date').attr('max', date_max.format('YYYY-MM-DD'));


        input.intlTelInput({
            preferredCountries: ["lb"],
            separateDialCode: true,
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.1.7/js/utils.js"
        });

        $(document).ready(function() {
            var bookedDates = new bootstrap.Modal(document.getElementById("booked_days"));
            var stopRecurringModal = new bootstrap.Modal(document.getElementById("stopRecurringModal"));
            var myModal = new bootstrap.Modal(document.getElementById("eventModal"));

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            //give start and end a values
            $('#event-date').attr('min', moment().format('YYYY-MM-DD'))

            var table = $('#bookings-list').DataTable({
                processing: true,
                serverSide: true,
                responsive: true,
                pagging:true,
                ajax: "<?php echo e(route('booking.index')); ?>",

                columns: [{
                        data: 'date',
                        name: 'date',
                    },
                    {
                        data: 'time_from',
                        name: 'time_from',
                        // order: [0, 'desc']
                    },
                    {
                        data: "sport",
                        name: 'sport',
                        searchable:false
                    },
                    {
                        data: 'court_name',
                        name: 'court_name',
                        searchable:false
                    },
                    {
                        data: 'duration',
                        name: 'duration'
                    },
                    {
                        data: 'full_name',
                        name: 'users_players.full_name',
                        searchable:true
                    },
                    {
                        data: 'is_private',
                        name: 'is_private'
                    },
                    {
                        data: 'status',
                        className: "text-center"
                    },
                    {
                        data: 'change_status',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    },
                ],
                order: [0, 'desc'],
            });

            function updateBooking(action, bookingId) {

                $.ajax({
                    url: "<?php echo e(route('booking.update')); ?>",
                    data: {
                        booking_id: bookingId,
                        update: action
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            swal("Booking Updated!", {
                                icon: "success",
                            }).then(() => {
                                location.reload();
                            });
                        }
                    }
                });
            }

            $(document).on('click', '.confirm_booking', function(e) {
                var booking_id = $(this).data('id');
                if (!isNaN(booking_id)) {
                    event.preventDefault();
                    swal({
                            title: `Are you sure you want to confirm this booking?`,
                            // text: "If you delete this, it will be gone forever.",
                            icon: "success",
                            buttons: true,
                            dangerMode: true,
                        })
                        .then((willDelete) => {
                            if (willDelete) {
                                updateBooking('confirm', booking_id);
                            }
                        });
                }
            });

            $(document).on('click', '.reject_booking', function(e) {
                var booking_id = $(this).data('id');
                if (!isNaN(booking_id)) {
                    event.preventDefault();
                    swal({
                            title: `Are you sure you want to reject this booking?`,
                            text: "If you delete this, it will be gone forever.",
                            icon: "warning",
                            buttons: true,
                            dangerMode: true,
                        })
                        .then((willDelete) => {
                            if (willDelete) {
                                updateBooking('reject', booking_id);
                            }
                        });
                }
            });

            //check start date < end date
            $(document).on('change', '#start_date', function(e) {
                $('#end_date').val('')
                $('#end_date').attr('min', $('#start_date').val())
            });

            $(document).on('change', '#end_date', function(e) {
                if ($('#end_date').val() < $('#start_date').val()) {
                    $('#start_date').val('')
                }
            });

            function populateSportSelect(courts, court_id = 0) {
                var select = $('#court_id');
                select.empty(); // Remove any existing options from the select element
                select.append($('<option>').text('--Select Court--').attr('value', '0').prop('disabled', true).prop(
                    'selected', true)); // Add a default option to the select element
                $.each(courts, function(index, court) {
                    select.append($('<option>').text(court.title_en).attr('value', court
                        .id)); // Add an option for each court in the response
                });
                if (court_id != 0) {
                    $('#court_id').val(court_id)
                }
            }

            //get sports by court 
            $(document).on('change', '#sport_id', function(e) {
                //reset min minutes 
                $('#book_session_duration').val('')

                var sport_id = $('#sport_id').val();
                if (isNaN(sport_id)) {
                    $('#sport_error').append(
                        '<span class="text-uppercase text-danger err">wrong id !!</span>');
                } else {
                    $('#sport_error').empty()
                }
                if ($('#err').length == 0) {
                    $.ajax({
                        url: "<?php echo e(route('booking.sportsbycourt')); ?>",
                        type: 'POST',
                        data: {
                            sport_id: sport_id
                        },
                        success: function(data) {
                            if (data.success) {
                                populateSportSelect(data.data);
                            }
                        }
                    })
                }
            })

            function sportbycourt(sport_id, court_id) {
                //reset min minutes 
                $('#book_session_duration').val('')
                // var sport_id = $('#sport_id').val();
                if (isNaN(sport_id)) {
                    $('#sport_error').append(
                        '<span class="text-uppercase text-danger err">wrong id !!</span>');
                } else {
                    $('#sport_error').empty()
                }
                if ($('#err').length == 0) {
                    $.ajax({
                        url: "<?php echo e(route('booking.sportsbycourt')); ?>",
                        type: 'POST',
                        data: {
                            sport_id: sport_id
                        },
                        success: function(data) {
                            if (data.success) {
                                populateSportSelect(data.data, court_id);
                            }
                        }
                    })
                }
            }
            //get booking row by booking id
            var recurring_min_duration;
            var id_sport;
            var booking_id_rec;
            var court_id_rec;

            ////////////////START EDIT BOOKING

            $("input[name='edit_duration']").TouchSpin({
                buttondown_class: "btn btn-light-danger text-danger font-medium",
                buttonup_class: "btn btn-light-success text-success font-medium",
                min: 30,
                max: 300,
                step: 30
            });

            var booking_id_edit;
            var court_id_edit;
            //click edit booking
            $(document).on('click', '#edit_button', function(e) {

                $('#book_event').css('display', 'none');
                $('#update_booking').css('display', 'block');
                booking_id_edit = $(this).data('id');

                //reset errors
                // $('#price_error').empty()
                // $("#court_price").prop("readonly", true);
                // $('#duration_minutes_error').empty();
                // $('#duration_minutes_empty').empty();
                // $('#user-select').empty();
                $("#session_minutes_error").empty();
                $('#session_minutes_empty').empty();
                $('#court_error').empty()
                $('#sport_error').empty()
                $('#date_error').empty()
                $('#date_error_').empty()
                $('#event_start_error').empty();
                $("#court_price").prop("readonly", true);
                //reset items
                $('#plus_court_items').empty()
                $('.recurring_space').empty()

                $.ajax({
                    url: "<?php echo e(route('booking.show')); ?>",
                    type: 'POST',
                    data: {
                        booking_id: booking_id_edit
                    },
                    success: function(data) {
                        if (data.success) {
                            console.log({
                                data
                            });
                            var player_id = data.data.player_id;
                            var player_name = data.data.player_name;
                            console.log(player_id, player_name);
                            const newOption = $('<option>', {
                                value: player_id,
                                text: player_name
                            });

                            var sport_id = data.data.sport_id;
                            var court_id = data.data.court_id;
                            var is_recurring = data.data.is_recurring;

                            // Append the new option to the select element
                            $('#user-select').append(newOption);
                            // Select the new option in the dropdown list
                            newOption.prop('selected', true);
                            $('#sport_id').val(sport_id)
                            console.log({
                                court_id
                            });
                            sportbycourt(sport_id, court_id)
                            $('#court_id').val(court_id)
                            court_id_edit = court_id;

                            if (is_recurring) {
                                $('.recurring_space').append(`<button type="button" class="btn btn-warning" id="stop_recurring" data-stop-recurring="${data.data.reference_id}">
                                    Stop Recurring
                                </button>`);
                            } else {
                                $('.recurring_space').empty()
                            }

                            //disable unchange fields
                            $('#event-date').prop('disabled', true);
                            $('#sport_id').prop('disabled', true);
                            $('#court_id').prop('disabled', true);

                            $('#event-date').val(data.data.date)
                            var time_from = moment(data.data.time_from, 'h:mm A').format(
                                'h:mm A');
                            $('#event_start option[value="' + time_from + '"]').prop(
                                'selected', true);
                            $('#court-price').val(data.data.total_price)
                            $('#book_session_duration').val(data.data.duration)
                            $('textarea[name="description"]').val(data.data.notes);
                            if (data.data.is_private == 1) {
                                $('#private').prop('checked', true)
                            } else {
                                $('#private').prop('checked', false)
                            }
                            if (data.data.is_paid == 1) {
                                $('#ispaid_reservation').prop('checked', true)
                            } else {
                                $('#ispaid_reservation').prop('checked', false)
                            }
                            status_id = data.data.status;
                            get_booking_items(booking_id_edit)
                            $('#court_reservation_price').text((data.data.total_price).toFixed(
                                2) + '$')
                            $('#items_total_price').text((data.data.add_on_price).toFixed(2) +
                                '$');
                            $('#grand_total').text((data.data.grand_total).toFixed(2) + '$');

                            total_items_price = data.data.add_on_price;
                            check_sess_up(true, court_id, sport_id)
                        }
                    }
                })
            })


            //update booking
            $(document).on("click", '#update_booking', function(e) {

                id = booking_id_edit;
                var starttime = $('#event_start').val();
                var minutes = parseInt($('#book_session_duration').val(), 10);
                var time_from = moment(starttime, 'h:mm A').format(
                    'HH:mm:ss'); // Convert the timestamp to 24-hour format
                var time_to = moment(starttime, 'h:mm A').add(minutes, 'minutes').format('HH:mm:ss');
                var notes = $('textarea[name="description"]').val();
                var is_private = $('#private').is(':checked') ? 1 : 0;
                var is_paid = $('#ispaid_reservation').is(':checked') ? 1 : 0;
                var price = $('#court-price').val();
                var date = $('#event-date').val();
                var weekday = moment(date, 'YYYY-MM-DD').day();
                var player_id = $('#user-select').val()
                var total_price = $('#court-price').val()

                var dateTime_from = moment(date + ' ' + time_from).format('YYYY-MM-DD HH:mm:ss');
                var dateTime_to = moment(dateTime_from).add(minutes, 'minutes').format(
                    'YYYY-MM-DD HH:mm:ss');

                if (isNaN(minutes)) {
                    $('#duration_minutes_empty').append(
                        `<span class="text-danger text-uppercase err">fill the session duration !!</span>`
                    )
                } else {
                    $('#duration_minutes_empty').empty();
                }

                if (minutes < each_session_min) {
                    $('#duration_minutes_error').append(
                        `<span class="text-danger text-uppercase err">The Session Duration should not be less than <b>${each_session_min}</b></span>`
                    )
                } else {
                    $('#duration_minutes_error').empty()
                }

                if (price > 0) {
                    $('#price_error').empty()
                } else {
                    $('#price_error').append(
                        `<span class="text-danger text-uppercase err">Price is required !!</span>`)
                }

                // console.log({price});return
                if ($('.err').length == 0) {
                    $.ajax({
                        url: "<?php echo e(route('calendar.updatebooking')); ?>",
                        data: {
                            date: date,
                            id: id,
                            court_id: court_id_edit,
                            time_from: dateTime_from,
                            time_to: dateTime_to,
                            is_private: is_private ? 1 : 0,
                            is_paid: is_paid ? 1 : 0,
                            notes: notes,
                            duration: minutes,
                            price: price,
                            weekday: weekday == 0 ? 7 : weekday,
                            status: status_id,
                            player_id: player_id,
                            total_price: total_price,
                            add_on: total_items_price,
                        },
                        type: "POST",
                        success: function(data) {
                            if (data.available_time) {
                                adds_on(id, true)
                            } else {
                                swal({
                                    title: "Error",
                                    text: 'THIS TIME IS ALREADY TAKEN BY ANOTHER RESERVATION, OR NOT INCLUDED IN COURT OPENING HOURS !!',
                                    icon: "error",
                                });
                                return
                            }
                        },
                        error: function(err) {
                            console.log(err);
                        }
                    });
                }
            });

            function get_booking_items(booking_id) {
                $.ajax({
                    url: "<?php echo e(route('reservation_items.get_booking_items')); ?>",
                    data: {
                        booking_id: booking_id
                    },
                    success: function(data) {
                        if (data.length > 0) {
                            $('#plus_court_items').removeClass(
                                'd-none')
                            for (let index = 0; index < data.length; index++) {
                                const element = data[index];
                                selectedItems.push(element.item_id);
                                $('#plus_court_items').append(`
              <div class="row mb-2 px-1 item d-flex align-items-center">
                  <div class="col-3">
                      ${element.name}
                      </div>
                  <div class="col-3">
                      <input class="price_item form-control" value="${element.price}" type="number"/>
                      <input class="id" type="hidden" value="${element.item_id}"/>
                  </div>
                  <div class="col-3">
                      <input value="${element.qty_hour}" type="number" class="qty_hour form-control"/>
                  </div>
                  <div class="col-3">
                      <i class="ti ti-trash fs-3 text-danger cursor-pointer"></i>
                  </div>
              </div>
              `)
                            }
                        }
                    }
                })
            }

            ////////////////END EDIT BOOKING

            /////////RECURRING


            //booking duration
            $("input[name='recurring_duration']").TouchSpin({
                buttondown_class: "btn btn-light-danger text-danger font-medium",
                buttonup_class: "btn btn-light-success text-success font-medium",
                min: 30,
                max: 300,
                step: 30
            });


            $(document).on('click', '#recurring_button', function(e) {
                $('#recurring_start_date').attr('min', moment().format('YYYY-MM-DD'));

                $('#recurring_day').val(0);
                $('#recurring_start_time').val(0);
                $('#recurring_duration').val('');
                $('#recurring_start_date').val('');
                $('#recurring_end_date').val('');
                $('#recurring_start_error').empty()
                $('#recurring_start_date_error').empty()
                $('#recurring_end_date_error').empty()
                $('#recurring_day_error').empty()
                $('#recurring_duration_empty').empty()
                $('#recurring_duration_error').empty()

                var booking_id = $(this).data('id');

                $.ajax({
                    url: "<?php echo e(route('booking.show')); ?>",
                    type: 'POST',
                    data: {
                        booking_id: booking_id
                    },
                    success: function(data) {
                        if (data.success) {
                            $('#recurring_duration').val(data.data.duration)
                            recurring_min_duration = data.data.duration;
                            id_sport = data.data.sport_id;
                            booking_id_rec = data.data.id;
                            court_id_rec = data.data.court_id;
                        }
                    }
                })
            });

            //check start date < end date
            $(document).on('change', '#recurring_start_date', function(e) {
                $('#recurring_end_date').val('')
                $('#recurring_end_date').attr('min', $('#recurring_start_date').val())
            });

            $(document).on('change', '#recurring_end_date', function(e) {
                if ($('#recurring_end_date').val() < $('#recurring_start_date').val()) {
                    $('#recurring_start_date').val('')
                }
            });

            //add recurring 
            $(document).on('click', '#storerecurring', function() {
                //empty errors
                $('#recurring_start_error').empty()
                $('#recurring_start_date_error').empty()
                $('#recurring_end_date_error').empty()
                $('#recurring_day_error').empty()
                $('#recurring_duration_empty').empty()
                $('#recurring_duration_error').empty()

                // Your code to handle the click event goes here
                var weekday = $('#recurring_day').val()
                var starttime = $('#recurring_start_time').val();
                var minutes = parseInt($('#recurring_duration').val(), 10);
                var time_from = moment(starttime, 'h:mm A').format(
                    'HH:mm:ss'); // Convert the timestamp to 24-hour format
                var time_to = moment(starttime, 'h:mm A').add(minutes, 'minutes').format('HH:mm:ss');
                var start_date = $('#recurring_start_date').val();
                var end_date = $('#recurring_end_date').val();
                var player_id = $('#user-select').val()


                if (!starttime || starttime == 0 || starttime == null) {
                    $('#recurring_start_error').append(
                        `<span class="text-danger text-uppercase err">time from is required !!</span>`)
                } else {
                    $('#recurring_start_error').empty()
                }
                if (!start_date) {
                    $('#recurring_start_date_error').append(
                        `<span class="text-danger text-uppercase err">start date is required !!</span>`)
                } else {
                    $('#recurring_start_date_error').empty()
                }
                if (!end_date) {
                    $('#recurring_end_date_error').append(
                        `<span class="text-danger text-uppercase err">end date is required !!</span>`)
                } else {
                    $('#recurring_end_date_error').empty()
                }
                if (isNaN(weekday) || weekday == 0 || weekday == null) {
                    $('#recurring_day_error').append(
                        `<span class="text-danger text-uppercase err">seleting a day is required !!</span>`
                    )
                } else {
                    $('#recurring_day_error').empty()
                }
                if (isNaN(minutes)) {
                    $('#recurring_duration_empty').append(
                        `<span class="text-danger text-uppercase err">fill the session duration !!</span>`
                    )
                } else {
                    $('#recurring_duration_empty').empty();
                }
                if (minutes < recurring_min_duration) {
                    $('#recurring_duration_error').append(
                        `<span class="text-danger text-uppercase err">The Session Duration should not be less than <b>${recurring_min_duration}</b></span>`
                    )
                } else {
                    $('#recurring_duration_error').empty()
                }
                if (!id_sport || id_sport == 0 || id_sport == null) {
                    console.log('sport id is missing');
                    return;
                }

                if ($('.err').length == 0) {
                    $.ajax({
                        url: "<?php echo e(route('calendar.storerecurring')); ?>",
                        data: {
                            booking_id: booking_id_rec,
                            court_id: court_id_rec,
                            time_from: time_from,
                            time_to: time_to,
                            start_date: start_date,
                            end_date: end_date,
                            duration: minutes,
                            weekday: weekday == 7 ? 0 : weekday,
                            sport_id: id_sport,
                            player_id: player_id
                        },
                        type: "POST",
                        success: function(data) {

                            if (data.success) {

                                $('#recurringModal').hide()
                                bookedDates.show()

                                if (data.booked_dates.length > 0) {
                                    var booked_days = data.booked_dates;
                                    var html =
                                        '<div> <span class="fs-6 mb-2 text-info text-uppercase">successfully booked sessions in: </span>'
                                    for (let i = 0; i < booked_days.length; i++) {
                                        html += '<div class="text-success my-1 h5">' +
                                            booked_days[i] + '</div>';
                                    }
                                    html += '</div>';
                                    $('#available_days').append(html)
                                } else {
                                    $('#available_days').append(
                                        `<div class="text-warning text-uppercase h4">unfortunately there is no available reservation !! </b></div>`
                                    )
                                }

                                if (data.not_available_dates.length > 0) {
                                    var not_booked_days = data.not_available_dates;
                                    var html =
                                        '<div> <span class="fs-6 mb-2 text-info text-uppercase">Not Available Dates: </span>'
                                    for (let i = 0; i < not_booked_days.length; i++) {
                                        html += '<div class="text-danger my-1 h5">' +
                                            not_booked_days[i] + '</div>';
                                    }
                                    html += '</div>';
                                    $('#not_booked_days').append(html)
                                } else {
                                    $('#not_booked_days').append(``)
                                }
                            }
                        },
                        error: function(err) {
                            console.log(err);
                        }
                    });
                }

            })

            // Relaod page when modal reccuring close
            document.getElementById('booked_days').addEventListener('hidden.bs.modal', function(event) {
                console.log('Modal closed');
                location.reload()
            });

            //////////RECURRING

            //booking duration
            $("input[name='book_session_duration']").TouchSpin({
                buttondown_class: "btn btn-light-danger text-danger font-medium",
                buttonup_class: "btn btn-light-success text-success font-medium",
                min: 30,
                max: 300,
                step: 30
            });

            //price up
            $('.bootstrap-touchspin-up').on('click', function(e) {
                var sport_court_price = parseFloat($('#court-price').val())
                var duration = parseInt($('#book_session_duration').val());
                console.log(sport_court_price);
                console.log({
                    each_session_min
                });
                if (each_session_min < duration) {
                    if (duration < 300) {
                        sport_court_price += (price_initial * 30) / each_session_min;
                    } else if (duration == 300) {
                        sport_court_price = (price_initial * 300) / each_session_min;
                    }
                }
                $('#court-price').val(sport_court_price.toFixed(2))
                $('#court_reservation_price').text(sport_court_price.toFixed(2) + "$")
                if (parseFloat($('#items_total_price').text())) {
                    total_items_price = parseFloat(($('#items_total_price').text()));
                }
                var gd_t = parseFloat(sport_court_price) + total_items_price;
                $('#grand_total').text(gd_t.toFixed(2) + '$')
                court_price = sport_court_price;
            })

            //price down
            $('.bootstrap-touchspin-down').on('click', function(e) {
                var sport_court_price = parseFloat($('#court-price').val());
                if (price_initial < sport_court_price) {
                    sport_court_price -= (price_initial * 30) / each_session_min;
                    $('#court-price').val(sport_court_price.toFixed(2))
                    $('#court_reservation_price').text(sport_court_price.toFixed(2) + "$")
                    if (parseFloat($('#items_total_price').text())) {
                        total_items_price = parseFloat(($('#items_total_price').text()).toFixed(2) + "$");
                    }
                    var gd_t = parseFloat(sport_court_price) + total_items_price;
                    $('#grand_total').text(gd_t.toFixed(2) + '$')
                    court_price = sport_court_price;
                }
            })

            //editable price
            $('#editable_price').on('click', function(e) {
                $("#court-price").prop("readonly", false);
            });

            $(document).on('change', '#court_id', function(e) {
                check_sess()
                $('#plus_court_items').empty()
                $('#search_input').val('')
                total_items_price = 0
                $('#items_total_price').text(0)
                $('#grand_total').text($('#court-price').val())
            });

            function check_sess(update = false) {

                $("#session_minutes_error").empty();
                $('#session_minutes_empty').empty();
                $('#court-price').empty();

                var sport_id = $('#select_sport').val();
                var court_id = $('#court_id').val();
                var sport_id = $('#sport_id').val();

                if (court_id && sport_id != 0) {
                    $.ajax({
                        url: "<?php echo e(route('calendar.session_time')); ?>",
                        data: {
                            court_id: court_id,
                            sport_id: sport_id
                        },
                        type: "POST",
                        success: function(data) {
                            console.log(data.session);
                            $("input[name='book_session_duration']").attr("data-minutes", data.session);
                            recurring_duration = data.session;
                            $('#recurring_duration').val(recurring_duration)
                            if (!update) {
                                $('#book_session_duration').val(data.session);
                            }
                            $('#book_session_duration').attr('disabled', false);
                            each_session_min = data.session
                            $('#book_session_duration').val(each_session_min);
                            price_initial = data.price
                            $('#court-price').val(price_initial.toFixed(2))
                            $('#court_reservation_price').text(price_initial.toFixed(2) + "$");
                            if (parseFloat($('#items_total_price').text())) {
                                total_items_price = parseFloat(($('#items_total_price').text()));
                            }
                            var gd_t = parseFloat(price_initial) + total_items_price;
                            $('#grand_total').text(gd_t.toFixed(2) + '$')
                        }
                    });

                }
            }

            function check_sess_up(update = false, court_id = null, sport_id = null) {
                $("#session_minutes_error").empty();
                $('#session_minutes_empty').empty();

                if (court_id && sport_id) {
                    $.ajax({
                        url: "<?php echo e(route('calendar.session_time')); ?>",
                        data: {
                            court_id: court_id,
                            sport_id: sport_id
                        },
                        type: "POST",
                        success: function(data) {
                            $("input[name='session_min']").attr("data-minutes", data.session);
                            recurring_duration = data.session;
                            if (!update) {
                                minutes.value = data.session;
                            }
                            each_session_min = data.session
                            price_initial = data.price
                        }
                    });

                }
            }

            //status buttons
            $(document).on('click', '.status_button', function(e) {
                if ($(this).val() == 0) {
                    $(this).addClass('btn-clicked text-warning')
                    $('.confirm_button').removeClass('btn-clicked text-success')
                    $('.history_button').removeClass('btn-clicked text-danger')
                } else if ($(this).val() == 1) {
                    $(this).addClass('btn-clicked text-success')
                    $('.pending_button').removeClass('btn-clicked text-warning')
                    $('.history_button').removeClass('btn-clicked text-danger')
                } else {
                    $(this).addClass('btn-clicked text-danger')
                    $('.pending_button').removeClass('btn-clicked text-warning')
                    $('.confirm_button').removeClass('btn-clicked text-success')
                }
            })

            $(document).on('click', '.status_button', function(e) {
                var status = $(this).val()
                var start_date = $('#start_date').val();
                var end_date = $('#end_date').val();

                if (start_date && end_date) {
                    start_date = $('#start_date').val()
                    end_date = $('#end_date').val()
                }
                table.ajax.url("<?php echo e(route('booking.getData')); ?>?start_date=" + start_date +
                    "&end_date=" + end_date + "&status=" + status).load();
            });

            //clear booking
            $(document).on('click', '#clear_bookings', function(e) {
                $('#start_date').val('')
                $('#end_date').val('')
            })

            //search
            $(document).on('click', '#search_bookings', function(e) {

                $('.pending_button').removeClass('btn-clicked text-warning')
                $('.confirm_button').removeClass('btn-clicked text-success')
                $('.history_button').removeClass('btn-clicked text-danger')

                $('#start_date_error').empty()
                $('#end_date_error').empty()
                $('#status_error').empty()

                var start_date = $('#start_date').val();
                if (start_date) {
                    start_date = moment(start_date, "MM/DD/YYYY").format("YYYY-MM-DD");
                }

                var end_date = $('#end_date').val();
                if (end_date) {
                    end_date = moment(end_date, "MM/DD/YYYY").format("YYYY-MM-DD");
                }

                console.log(start_date, end_date);
                if ($('.err').length == 0) {
                    // Update the data table with the new filters
                    table.ajax.url("<?php echo e(route('booking.getData')); ?>?start_date=" + start_date +
                        "&end_date=" + end_date).load();
                }
            })

            //modal button
            $(document).on('click', '#modal_button', function(e) {

                $('#book_event').css('display', 'block');
                $('#update_booking').css('display', 'none');
                //reset modal
                $("#court-price").prop("readonly", true);
                $('#court_id').empty()
                $('#court_id').val(0);
                $('#court-price').val('');
                $('#event-date').val('');
                $('#sport_id').val(0);
                $('textarea[name="description"]').val('');
                $('#book_session_duration').val('')
                $("#session_minutes_error").empty();
                $('#session_minutes_empty').empty();
                $('#court_error').empty()
                $('#sport_error').empty()
                $('#date_error').empty()
                $('#date_error_').empty()
                $('#event_start_error').empty();

                //new
                $('#search-input').val('')
                $('#user-select').empty();
                $('#new_member_button').css('display', 'none')
                $('#new_member_content').css('display', 'none');
                $('#phone_number_valid').empty()
                $('#full_name').val('')
                $('#full_name_error').empty()
                $('#birth_date').val('')
                $('#email').val('')
                $('#phone_number').val('')

                //reset summary
                $('#court_reservation_price').text('')
                $('#grand_total').text('')
                $('#items_total_price').text('')

                //reset items
                $('#plus_court_items').empty()

                //disable unchange fields
                $('#event-date').prop('disabled', false);
                $('#sport_id').prop('disabled', false);
                $('#court_id').prop('disabled', false);

                $("#court-price").prop("readonly", true);

                $('.recurring_space').empty()
            });

            //add book
            $(document).on('click', '#book_event', function(e) {

                $("#session_minutes_error").empty();
                $('#session_minutes_empty').empty();
                $('#court_error').empty()
                $('#sport_error').empty()
                $('#date_error').empty()
                $('#date_error_').empty()
                $('#event_start_error').empty();

                var player_id = $('#user-select').val();
                var is_paid = $('#ispaid_reservation').is(':checked') ? 1 : 0;
                var is_private = $('#private').is(':checked') ? 1 : 0;
                var court_id = $('#court_id').val();
                var starttime = $('#event_start').val();
                var minutes = parseInt($('#book_session_duration').val(), 10);
                var time_from_unformat = moment(starttime, 'HH:mm').format('h:mm A');
                var time_from = moment(starttime, 'h:mm A').format(
                    'HH:mm'); // Convert the timestamp to 24-hour format
                var time_to = moment(starttime, 'h:mm A').add(minutes, 'minutes').format('HH:mm');
                var sport_id = $('#sport_id').val();
                var notes = $('textarea[name="description"]').val();
                var date = $('#event-date').val();
                var weekday = moment(date, 'YYYY-MM-DD').day();
                var total_price = $('#court-price').val()
                var price = parseFloat(total_price);

                var dateTime_from = moment(date + ' ' + time_from).format('YYYY-MM-DD HH:mm:ss');
                var dateTime_to = moment(dateTime_from).add(minutes, 'minutes').format(
                    'YYYY-MM-DD HH:mm:ss');

                var currentDate = moment();
                var formated_date = moment(date, 'YYYY-MM-DD');

                if (!player_id || player_id == 0 || player_id == null) {
                    // $('#player_error').append(`<span class="text-danger text-uppercase err">player is required !!</span>`)
                    player_id = 0;
                } else {
                    $('#player_error').empty();
                }

                if (isNaN(court_id) || court_id == null || court_id == 0) {
                    $('#court_error').append(
                        '<span class="err text-uppercase text-danger">choosing a court is required !!</span>'
                    );
                } else {
                    $('#court_error').empty()
                }

                if (isNaN(sport_id) || sport_id == null || sport_id == 0) {
                    $('#sport_error').append(
                        '<span class="err text-uppercase text-danger">choosing a sport is required !!</span>'
                    );
                } else {
                    $('#sport_error').empty()
                }

                if (!date) {
                    $('#date_error').append(
                        '<span class="err text-uppercase text-danger">date is required !!</span>');
                } else {
                    $('#date_error').empty()
                }

                if (formated_date.isBefore(currentDate, 'day')) {
                    $('#date_error_').append(
                        '<span class="err text-uppercase text-danger">cannot make a reservation for a day back !!</span>'
                    );
                } else {
                    $('#date_error_').empty()
                }

                if (isNaN(minutes)) {
                    $('#session_minutes_empty').append(
                        `<span class="text-danger text-uppercase err">fill the session duration !!</span>`
                    )
                } else {
                    $('#session_minutes_empty').empty();
                }

                if (minutes < each_session_min) {
                    $('#session_minutes_error').append(
                        `<span class="text-danger text-uppercase err">The Session Duration should not be less than <b>${each_session_min}</b></span>`
                    )
                } else {
                    $('#session_minutes_error').empty()
                }

                if (!starttime) {
                    $('#event_start_error').append(
                        `<span class="text-danger text-uppercase err">from time is required !!</span>`
                    )
                } else {
                    $('#event_start_error').empty();
                }

                if ($('.err').length == 0) {
                    $.ajax({
                        url: "<?php echo e(route('calendar.storebooking')); ?>",
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        data: {
                            player_id: player_id,
                            court_id: court_id,
                            weekday: weekday == 0 ? 7 : weekday,
                            date: date,
                            time_from: dateTime_from,
                            time_to: dateTime_to,
                            sport_id: sport_id,
                            is_private: is_private ? 1 : 0,
                            is_paid: is_paid ? 1 : 0,
                            notes: notes,
                            duration: minutes,
                            price: price,
                            total_price: total_price,
                            add_on: total_items_price
                        },
                        type: "POST",
                        success: function(data) {

                            if (!data.available_time) {
                                swal({
                                    title: "Error",
                                    text: 'THIS TIME IS ALREADY TAKEN BY ANOTHER RESERVATION, OR NOT INCLUDED IN COURT OPENING HOURS !!',
                                    icon: "error",
                                });
                                return
                            }
                            if (data.error) {
                                let errorString = "";
                                for (const [key, value] of Object.entries(data.errors)) {
                                    errorString += `${value}\n`;
                                }
                                swal({
                                    title: "Error",
                                    text: errorString,
                                    icon: "error",
                                });
                                return;
                            }
                            if (data.data[0]['id']) {
                                var booking_id = data.data[0]['id'];
                                if ($('.item').length > 0) {
                                    adds_on(booking_id, false)
                                } else {
                                    swal({
                                        title: 'RESERVATION ADDED SUCCESSFULLY',
                                        icon: 'success'
                                    }).then(() => {
                                        location.reload()
                                    })
                                }
                            }
                        },
                        error: function(err) {
                            console.log(err);
                        }
                    });
                }
            })

            //new 
            //search by client
            //searching for adding a member
            $('#search-input').on('input', function() {
                var query = $(this).val();
                if (query.length >= 2) {
                    $.ajax({
                        url: "<?php echo e(route('players.search')); ?>",
                        data: {
                            query: query
                        },
                        success: function(data) {
                            if (data.success) {
                                $('#new_member_button').css('display', 'none');
                                $('#new_member_content').css('display', 'none');
                                $('#user-select').empty();
                                $.each(data.data, function(key, user) {
                                    $('#user-select').append($('<option>', {
                                        value: user.id,
                                        text: user.full_name
                                    }));
                                });
                            } else {
                                $('#user-select').empty();
                                $('#user-select').append($('<option>', {
                                    value: 0,
                                    text: 'no member match'
                                }));
                                $('#new_member_button').css('display', 'block');
                            }
                        }
                    });
                }
            });

            $(document).on('click', '#new_member_button', function(e) {
                $('#new_member_content').css('display', 'block');
                $('#phone_number_valid').empty()
                $('#full_name').val('')
                $('#birth_date').val('')
                $('#email').val('')
                $('#phone_number').val('')
            });

            $(document).on('click', '#save_member', function(e) {

                $('#birth_date_error').empty();
                $('#email_error').empty();
                $('#phone_err').empty();

                var dateInput = $('#birth_date').val();
                var full_name = $('#full_name').val();
                var birth_date = $('#birth_date').val();
                var email = $('#email').val();
                var country_c = country_code
                var phone_number = $('#phone_number').val().replace(/\s/g, "");
                const isValid = validateDateInput(dateInput);
                const isEmailValid = isValidEmail(email);

                if (phone_number == '' || phone_number == 0 || phone_number == null) {
                    $('#phone_err').append(
                        '<span class="err text-danger text-uppercase">required !!</span>');
                } else {
                    $('#phone_err').empty();
                }
                fullnamecheck()

                if (isEmailValid) {
                    $('#email_error').empty();
                } else {
                    $('#email_error').append(
                        `<span class="err">email is invalid</span>`
                    );
                }

                if (isValid) {
                    $('#birth_date_error').empty();
                } else {
                    $('#birth_date_error').append(
                        `<span class="err">date should not be less than ${minYear} and not more than ${maxYear}</span>`
                    );
                }

                if ($('.err').length == 0) {

                    saveButton.disabled = true;
                    $.ajax({
                        url: "<?php echo e(route('players.check_email')); ?>",
                        data: {
                            email: email,
                            phone: phone_number
                        },
                        type: 'POST',
                        success: function(data) {
                            if (data.success) {
                                storeplayer(full_name, email, phone_number, country_c,
                                    birth_date)
                            } else {
                                swal({
                                    title: 'EMAIL OR PHONE NUMBER IS REPEATED !',
                                    icon: 'warning'
                                })
                                saveButton.disabled = false;
                            }
                        }

                    })
                }
            });

            full_name.addEventListener('keyup', function() {
                fullnamecheck()
            });

            // Add a keyup event listener to validate the phone number
            input.on("keyup change", function() {
                $('#phone_err').empty();
                // var isValid = input.intlTelInput("isValidNumber");
                var hasNonDigits = /[^\d]/.test(input.val());
                // if (isValid && !hasNonDigits) {
                if (!hasNonDigits) {
                    phone_valid.html('Valid <i class="ti ti-check"></i>'); // the phone number is valid
                    phone_error.html('').removeClass('err');
                    valid_number = input.intlTelInput("getNumber");
                    country_code = input.intlTelInput("getSelectedCountryData").dialCode;
                } else {
                    phone_error.html('Not Valid X').addClass('err');
                    phone_valid.html('')
                }
            });

            //adds on
            $('.search-container input').on('input', function() {
                var query = $(this).val().trim();
                var court_id = $('#court_id').val()
                if (query.length > 0) {
                    $.ajax({
                        url: "<?php echo e(route('courtitems.search_by_court')); ?>",
                        data: {
                            name: query,
                            id: court_id
                        },
                        type: "POST",
                        success: function(data) {
                            var results = $('.search-results');
                            results.empty();
                            if (data.data.length > 0) {
                                for (var i = 0; i < data.data.length; i++) {
                                    var item = data.data[i];
                                    var li = $('<li style="list-style: none;" class="my-2">');
                                    var text_image = item.img == null ?
                                        'images/courts/no-image.png' : item
                                        .img;
                                    var img = $('<img width="50" height="50">').attr('src',
                                        "<?php echo e(url('')); ?>" + "/" +
                                        text_image);
                                    var title = $('<span class="item_name mx-3">').text(item
                                        .name);
                                    var price = $('<span class="mx-3 item_price">').text(item
                                        .price)
                                    var item_id = item.item_id;

                                    // Use a closure to capture the correct value of item_id
                                    (function(item_id) {
                                        li.on('click', function() {
                                            if (selectedItems.includes(item_id)) {
                                                li.addClass('disabled');
                                                $('#search_input').val('')
                                                results.hide()
                                                return
                                            } else {
                                                $('#search_input').val('')
                                                var title = $(this).find(
                                                        '.item_name')
                                                    .text();
                                                var price_i = $(this).find(
                                                        '.item_price')
                                                    .text();
                                                $('#plus_court_items').removeClass(
                                                    'd-none')
                                                $('#plus_court_items').append(`
                            <div class="row mb-2 px-1 item d-flex align-items-center">
                                <div class="col-3">
                                    ${title}
                                    </div>
                                <div class="col-3">
                                    <input class="price_item form-control" value="${price_i}" type="number">
                                    <input class="id" type="hidden" value="${item_id}"/>
                                </div>
                                <div class="col-3">
                                    <input value="1" type="number" class="qty_hour form-control"/>
                                </div>
                                <div class="col-3">
                                    <i class="ti ti-trash fs-3 text-danger cursor-pointer"></i>
                                </div>
                            </div>
                        `)
                                                // Add the item to the selectedItems array and disable the li element
                                                selectedItems.push(item_id);
                                                $(this).addClass('disabled');
                                                results.hide();
                                                total_items_price += parseFloat(
                                                    price_i);
                                                $('#items_total_price').text((
                                                        total_items_price)
                                                    .toFixed(2) + "$")
                                                if ($('#court_reservation_price')
                                                    .text()) {
                                                    court_price = $(
                                                            '#court_reservation_price'
                                                        )
                                                        .text();
                                                } else {
                                                    court_price = 0;
                                                }
                                                grand_total = parseFloat(
                                                        total_items_price) +
                                                    parseFloat(court_price);
                                                $('#grand_total').text(grand_total
                                                    .toFixed(2) +
                                                    "$")
                                            }
                                        });
                                    })(item_id);
                                    li.append(img);
                                    li.append(title);
                                    li.append(price);
                                    results.append(li);
                                }
                                results.show();
                            } else {
                                results.hide();
                            }
                        }
                    })
                } else {
                    $('.search-results').hide();
                }
            });

            $(document).on('input change', '.qty_hour', function(e) {
                var total_price = 0;
                if ($('#court-price').val()) {
                    court_price = parseFloat($('#court-price').val());
                } else {
                    court_price = 0;
                }
                var value = parseInt($(this).val());
                if (value < 1 || isNaN(value)) {
                    $(this).val(1);
                    return;
                }
                $('.item').each(function() {
                    var price = parseFloat($(this).find('.price_item').val());
                    var quantity = parseInt($(this).find('.qty_hour').val());
                    var item_price = parseFloat(price) * parseInt(quantity);
                    total_price += parseFloat(item_price);
                });
                $('#items_total_price').text(total_price.toFixed(2) + '$')
                grand_total = total_price + court_price;
                $('#grand_total').text(grand_total.toFixed(2) + '$')
                total_items_price = total_price;
            });

            $(document).on('input change', '.price_item', function(e) {
                var total_price = 0;
                if ($('#court-price').val()) {
                    court_price = parseFloat($('#court-price').val());
                } else {
                    court_price = 0;
                }
                var value = parseInt($(this).val());
                if (value < 0 || isNaN(value)) {
                    $(this).val(0);
                    return;
                }
                $('.item').each(function() {
                    var price = parseFloat($(this).find('.price_item').val());
                    var quantity = parseInt($(this).find('.qty_hour').val());
                    var item_price = parseFloat(price) * parseInt(quantity);
                    total_price += parseFloat(item_price);
                });
                $('#items_total_price').text(total_price.toFixed(2) + '$')
                grand_total = total_price + court_price;
                $('#grand_total').text(grand_total.toFixed(2) + '$')
                total_items_price = total_price;
            });

            function adds_on(booking_id, update = false) {
                // create an empty array to hold the items
                var items = [];
                // loop through each div element with the "item" class
                $(".item").each(function() {
                    // get the name and price from the span elements in the div element
                    var item_id = $(this).find(".id").val();
                    var price = $(this).find(".price_item").val();
                    var qty_hour = $(this).find('.qty_hour').val();

                    // create an object with the name and price properties
                    var item = {
                        item_id: item_id,
                        price: price,
                        qty_hour: qty_hour,
                        update: update
                    };
                    // add the object to the items array
                    items.push(item);
                });
                // send the array of objects to the back end using AJAX
                $.ajax({
                    url: "<?php echo e(route('reservation_items.store')); ?>",
                    type: "POST",
                    data: {
                        items: items,
                        booking_id: booking_id,
                        update: update
                    },
                    success: function(response) {
                        if (response.success) {
                            swal({
                                title: 'RESERVATION ADDED SUCCESSFULLY',
                                icon: 'success'
                            }).then(() => {
                                location.reload()
                            })
                        } else {
                            swal({
                                title: 'RESERVATION UPDATED SUCCESSFULLY',
                                icon: 'success'
                            }).then(() => {
                                location.reload()
                            })
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                    }
                });
            }

            var recurring_id;
            var recurring_type;

            $(document).on('change', 'input[name="recurring_interval"]', function(e) {
                var recurring_type = $('input[name="recurring_interval"]:checked').val();
                if (recurring_type != 'all') {
                    $('.specify_times').css('display', 'block')
                } else {
                    $('.specify_times').css('display', 'none')
                }
            });

            $(document).on('click', '#stop_recurring', function(e) {
                recurring_id = $(this).data('stop-recurring');
                myModal.hide();
                stopRecurringModal.show();
            });

            $(document).on('click', '.stop_reccuring', function(e) {
                var recurring_type = $('input[name="recurring_interval"]:checked').val();
                $('.stop_recurring').prop('disabled', true);
                if (recurring_id) {
                    stop_recurring(recurring_id, recurring_type);
                }
            })


            function stop_recurring(recurring_id, recurring_type) {
                var datefrom = $('#datefrom').val();

                if (datefrom) {
                    var formatted_from = moment(datefrom, 'MM/DD/YYYY').format('YYYY-MM-DD');
                } else {
                    var formatted_from = '';
                }

                var dateto = $('#dateto').val();
                if (dateto) {
                    var formatted_to = moment(dateto, 'MM/DD/YYYY').format('YYYY-MM-DD');
                } else {
                    var formatted_to = '';
                }

                $.ajax({
                    url: "<?php echo e(route('calendar.stoprecurring')); ?>",
                    data: {
                        reference_id: recurring_id,
                        recurring_type: recurring_type,
                        datefrom: formatted_from,
                        dateto: formatted_to
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            swal({
                                title: 'Success',
                                text: data.msg,
                                icon: 'success'
                            }).then(() => {
                                location.reload()
                            });
                            return;
                        } else {
                            swal({
                                text: data.msg,
                                icon: 'warning'
                            });
                            $('.stop_recurring').prop('disabled', false);
                        }
                    }
                });
            }
        });

        // Add a click event listener to the trash icon
        $('#plus_court_items').on('click', '.ti-trash', function() {
            // Get the parent element of the trash icon
            var item = $(this).closest('.item');
            // Get the ID of the item from the hidden input field
            var item_id = item.find('.id').val();
            var item_price = item.find('.price_item').val()
            var item_qty = item.find('.qty_hour').val()
            var each_item_total = item_price * item_qty;
            if ($('#court-price').val()) {
                court_price = parseFloat($('#court-price').val())
            } else {
                court_price = 0;
            }
            // Remove the item from the selectedItems array
            var index = selectedItems.indexOf(parseInt(item_id));
            if (index > -1) {
                selectedItems.splice(index, 1);
                // Remove the item from the DOM
                item.remove();
                total_items_price -= parseFloat(each_item_total);
                $('#items_total_price').text(total_items_price + '$')
                grand_total = parseFloat(total_items_price) +
                    parseFloat(court_price);
                $('#grand_total').text(grand_total + '$')
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sportcietyapp/public_html/platform.sportcietyapp.com/resources/views/booking/index.blade.php ENDPATH**/ ?>