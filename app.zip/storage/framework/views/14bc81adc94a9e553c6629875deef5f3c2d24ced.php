
<?php if(Helper::check_permission(config('permissions.sales'),'is_update')): ?>
<a type="button" class="edit_sale" data-bs-toggle="modal"
    data-bs-target="#saleModal" id="modal_button"
    data-sale-id="<?php echo e($row->id); ?>"
    data-date="<?php echo e($row->date); ?>"
    data-player-id="<?php echo e($row->player_id); ?>"
    data-player-name="<?php echo e($row->full_name); ?>"
    data-is-paid="<?php echo e($row->is_paid); ?>"
    data-total="<?php echo e($row->total_amount); ?>">
    <i class="ti ti-pencil fs-6"></i>
</a>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/sales_items/actions.blade.php ENDPATH**/ ?>