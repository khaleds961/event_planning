<!--  Import Js Files -->
<script src="<?php echo e(asset('dist/libs/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/libs/simplebar/dist/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>

<!--  core files -->
<script src="<?php echo e(asset('dist/js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/app.init.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/app-style-switcher.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/sidebarmenu.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('dist/libs/prismjs/prism.js')); ?>"></script>

<!--  current page js files -->
<script src="<?php echo e(asset('dist/libs/owl.carousel/dist/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/libs/apexcharts/dist/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/dashboard.js')); ?>"></script>


<script src="<?php echo e(asset('dist/libs/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/forms/form-bootstrap-touchspin.init.js')); ?>"></script>


<script src="<?php echo e(asset('dist/js/apex-chart/apex.radial.init.js')); ?>"></script>
<script src="<?php echo e(asset('dist/libs/apexcharts/dist/apexcharts.min.js')); ?>"></script>



<script src="<?php echo e(asset('dist/js/apex-chart/apex.bar.init.js')); ?>"></script>


<script src="<?php echo e(asset('dist/libs/bootstrap-switch/dist/js/bootstrap-switch.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/forms/bootstrap-switch.js')); ?>"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"
    integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>


<script src="<?php echo e(asset('dist/libs/dropify/js/dropify.js')); ?>"></script>
<script src="<?php echo e(asset('dist/libs/dropify/js/dropify.min.js')); ?>"></script>


<script src="<?php echo e(asset('dist/libs/fullcalendar/index.global.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/apps/calendar-init.js')); ?>"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>


<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.1.7/js/intlTelInput.min.js"
    integrity="sha512-DguTdnmuGKK87piEuhLZV1XZtEHUhfUmFC12IIQXVW36lbJ84tS9zHBBo2gMrXNJWxT8VZWsv/9Vu0k/vSpdpg=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.1.7/js/intlTelInput-jquery.js"
    integrity="sha512-gkm7yhRikPhWl3Swwnj8iVWfRIttFHb1LyAfiJm/U+uzAE8hLyEMeJvYEIu8brD5ueBZzrv6l+9VaAuInmOhiQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.1.7/js/utils.js"></script>


<script src="<?php echo e(asset('dist/libs/select2/dist/js/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/libs/select2/dist/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/forms/select2.init.js')); ?>"></script>


<script src="<?php echo e(asset('dist/libs/jquery-steps/build/jquery.steps.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/libs/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/forms/form-wizard.js')); ?>"></script>


<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>

<script type="text/javascript">
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(document).ready(function() {
        $("#loginTogglePassword").click(function() {
            var passwordInput = $("#exampleInputPassword1");
            var passwordIcon = $("#loginTogglePassword i");

            if (passwordInput.attr("type") === "password") {
                passwordInput.attr("type", "text");
                passwordIcon.removeClass("ti-eye").addClass("ti-eye-closed");
            } else {
                passwordInput.attr("type", "password");
                passwordIcon.removeClass("ti-eye-closed").addClass("ti-eye");
            }
        });
    });

    //register form password
    $(document).ready(function() {
        $("#togglePassword").click(function() {
            var passwordInput = $("#password");
            var passwordIcon = $("#togglePassword i");

            if (passwordInput.attr("type") === "password") {
                passwordInput.attr("type", "text");
                passwordIcon.removeClass("ti-eye").addClass("ti-eye-closed");
            } else {
                passwordInput.attr("type", "password");
                passwordIcon.removeClass("ti-eye-closed").addClass("ti-eye");
            }
        });
    });

    $(document).ready(function() {
        $("#toggleConfirmPassword").click(function() {
            var confirmPasswordInput = $("#confirm_password");
            var confirmPasswordIcon = $("#toggleConfirmPassword i");

            if (confirmPasswordInput.attr("type") === "password") {
                confirmPasswordInput.attr("type", "text");
                confirmPasswordIcon.removeClass("ti-eye").addClass("ti-eye-closed");
            } else {
                confirmPasswordInput.attr("type", "password");
                confirmPasswordIcon.removeClass("ti-eye-closed").addClass("ti-eye");
            }
        });
    });

    //show confirm court
    $(document).on('click', '.show_confirm_court', function(event) {
        var id = $(this).data("id");
        var table_name = $(this).data("table_name");
        event.preventDefault();
        swal({
                title: `Are you sure you want to delete this record, It may delete Items related to this Court?`,
                text: "If you delete this, it will be gone forever.",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "<?php echo e(route('custom_delete_court')); ?>",
                        method: 'post',
                        data: {
                            id: id,
                            table_name: table_name,
                        },
                        success: function(result) {
                            console.log(result);
                            swal("Poof! Your imaginary file has been deleted!", {
                                    icon: "success",
                                })
                                .then(() => {
                                    location.reload();
                                });
                        }
                    });
                }
            });
    });

    //show confirm category
    $(document).on('click', '.show_confirm_category', function(event) {
        var id = $(this).data("id");
        var table_name = $(this).data("table_name");
        event.preventDefault();
        swal({
                title: `Are you sure you want to delete this record, It may delete Items related to this Category?`,
                text: "If you delete this, it will be gone forever.",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "<?php echo e(route('custom_delete_category')); ?>",
                        method: 'post',
                        data: {
                            id: id,
                            table_name: table_name,
                        },
                        success: function(result) {
                            console.log(result);
                            swal("Poof! Your imaginary file has been deleted!", {
                                    icon: "success",
                                })
                                .then(() => {
                                    location.reload();
                                });
                        }
                    });
                }
            });
    });

    //show confirm sport
    $(document).on('click', '.show_confirm_sport', function(event) {
        var id = $(this).data("id");
        var table_name = $(this).data("table_name");
        event.preventDefault();
        swal({
                title: `Are you sure you want to delete this record, It may delete Items related to this sport?`,
                text: "If you delete this, it will be gone forever.",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "<?php echo e(route('custom_delete_sport')); ?>",
                        method: 'post',
                        data: {
                            id: id,
                            table_name: table_name,
                        },
                        success: function(result) {
                            console.log(result);
                            swal("Poof! Your imaginary file has been deleted!", {
                                    icon: "success",
                                })
                                .then(() => {
                                    history.back();
                                });
                        }
                    });
                }
            });
    });


    $(document).on('click', '.show_confirm', function(event) {
        var id = $(this).data("id");
        var table_name = $(this).data("table_name");
        event.preventDefault();
        swal({
                title: `Are you sure you want to delete this record ?`,
                text: "If you delete this, it will be gone forever.",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "<?php echo e(route('custom_delete')); ?>",
                        method: 'post',
                        data: {
                            id: id,
                            table_name: table_name,
                        },
                        success: function(result) {
                            console.log(result);
                            swal("Poof! Your imaginary file has been deleted!", {
                                    icon: "success",
                                })
                                .then(() => {
                                    location.reload();
                                });
                        }
                    });
                }
            });
    });

    //deleted instead of is_delete
    $(document).on('click', '.show_confirmed', function(event) {
        var id = $(this).data("id");
        var table_name = $(this).data("table_name");
        event.preventDefault();
        swal({
                title: `Are you sure you want to delete this record ?`,
                text: "If you delete this, it will be gone forever.",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "<?php echo e(route('custom_deleted')); ?>",
                        method: 'post',
                        data: {
                            id: id,
                            table_name: table_name,
                        },
                        success: function(result) {
                            if (result == 'success') {
                                swal("Poof! Your imaginary file has been deleted!", {
                                        icon: "success",
                                    })
                                    .then(() => {
                                        location.reload();
                                    });
                            }

                        }
                    });
                }
            });
    });

    // start change status function
    $(document).on('change', '.change_status', function(event) {
        var id = $(this).data("id");
        var table_name = $(this).data("table_name");
        var action = $(this).data("action");

        event.preventDefault();
        swal({
                title: "Are you sure?",
                text: "Are you sure you want to the change the status!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: table_name == 'item_category' ?
                            "<?php echo e(route('change_status_category')); ?>" : table_name == 'club_court' ?
                            "<?php echo e(route('change_status_court')); ?>" : "<?php echo e(route('change_status')); ?>",
                        method: 'post',
                        data: {
                            id: id,
                            table_name: table_name,
                            action: action
                        },
                        success: function(result) {
                            console.log(result)
                            swal("Poof! Your status has been changed successfully!", {
                                icon: "success",
                            }).then(() => {
                                location.reload();
                            });
                        }
                    });
                } else {
                    if ($(this).prop('checked') == true) {
                        $(this).prop('checked', false);
                    } else {
                        $(this).prop('checked', true);
                    }
                }
            });
    });

    //category
    $(document).on('change', '.change_status_category', function(event) {
        var id = $(this).data("id");
        var table_name = $(this).data("table_name");
        var action = $(this).data("action");

        event.preventDefault();
        swal({
                title: "Are you sure?",
                text: "Are you sure you want to the change the status!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "<?php echo e(route('change_status_category')); ?>",
                        method: 'post',
                        data: {
                            id: id,
                            table_name: table_name,
                            action: action
                        },
                        success: function(result) {
                            console.log(result)
                            swal("Poof! Your status has been changed successfully!", {
                                icon: "success",
                            });
                            location.reload();
                        }
                    });
                } else {
                    if ($(this).prop('checked') == true) {
                        $(this).prop('checked', false);
                    } else {
                        $(this).prop('checked', true);
                    }
                }
            });
    });
    // end change status function

    function validateDateInput(dateInput) {
        // Convert the date input to a Date object
        const date = new Date(dateInput);
        // Check if the year is within the allowed range
        const year = date.getFullYear();
        if (year > maxYear || year < minYear) {
            return false;
        }

        // Check if the date is valid
        if (isNaN(date.getTime())) {
            return false;
        }

        // If all checks pass, return true
        return true;
    }

    function isValidEmail(email) {
        // Regular expression pattern for matching email addresses
        const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        // Use the test() method of the pattern to check if the email address matches
        return pattern.test(email);
    }

    var saveButton = document.querySelector('#save_member');

    function storeplayer(full_name, email, phone_number, phone_code, birth_date, from_sales_page = false) {
        $.ajax({
            url: "<?php echo e(route('players.store')); ?>",
            data: {
                full_name: full_name,
                email: email,
                phone_number: phone_number,
                phone_code: phone_code,
                birth_date: birth_date
            },
            type: 'POST',
            success: function(data) {
                if (data.success) {
                    // Get the ID of the newly created member from the response data
                    const newMemberId = data.player.id;

                    console.log(newMemberId);
                    // Create a new option element with the member's name and ID
                    const newOption = $('<option>', {
                        value: newMemberId,
                        text: full_name
                    });

                    // Append the new option to the select element
                    $('#user-select').append(newOption);

                    // Select the new option in the dropdown list
                    newOption.prop('selected', true);

                    swal({
                        title: "NEW PLAYER ADDED SUCCESSFULLY",
                        icon: "success"
                    });
                    if (!from_sales_page) {
                        $('#new_member_button').css('display', 'none')
                    }
                    $('#new_member_content').css('display', 'none');
                    $('#phone_number_valid').empty()
                    $('#full_name').val('')
                    $('#birth_date').val('')
                    $('#email').val('')
                    $('#phone_number').val('')
                    $('#search-input').val('')
                    saveButton.disabled = false;
                }
            }
        })
    }

    function fullnamecheck() {
        const full_nameValue = full_name.value.trim();
        if (full_nameValue.length > 30) {
            full_nameValidation.textContent = 'full name must not be longer than 30 characters';
            full_nameValidation.classList.add('err');
        } else if (full_nameValue.length < 3) {
            full_nameValidation.textContent = 'full name must be 3 characters or more';
            full_nameValidation.classList.add('err');
        } else {
            full_nameValidation.textContent = '';
            full_nameValidation.classList.remove('err');
        }
    }

    //DATE PICKER
    $(".datepicker").datepicker();
    
</script>

<?php echo $__env->yieldPushContent('after-scripts'); ?>
<?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/layouts/foot.blade.php ENDPATH**/ ?>