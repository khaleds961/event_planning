
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-sm-12 col-md-3">
            <div class="mb-3">
                <label for="datefrom" class="control-label col-form-label">FROM</label>
                <input type="text" class="form-control datepicker" id="datefrom"
                    value="<?php echo e(request()->get('date_from')); ?>" />
            </div>
        </div>

        <div class="col-sm-12 col-md-3">
            <div>
                <label for="dateto" class="control-label col-form-label">TO</label>
                <input type="text" class="form-control datepicker" id="dateto"
                    value="<?php echo e(request()->get('date_to')); ?>" />
            </div>
        </div>

        <div class="col-sm-12 col-md-3">
            <div>
                <label for="sports" class="control-label col-form-label">SPORTS</label>
                <select class="form-control" id="sports" onchange="getCourts()">
                    <option selected value="none">--None--</option>
                    <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sport['id']); ?>"
                            <?php echo e(request()->get('sport_id') == $sport['id'] ? 'selected' : ''); ?>><?php echo e($sport['name']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="col-sm-12 col-md-3">
            <div>
                <label for="courts" class="control-label col-form-label">COURTS</label>
                <select class="form-control" id="courts">
                    <option selected value="none">--None--</option>
                </select>
            </div>
        </div>

    </div>

    <div class="d-flex mt-3 mt-md-0">
        
        <div>
            <button class="btn btn-danger" onclick="search()">
                <i class="ti ti-search"></i>
                <span class="mx-2">Search</span>
            </button>
        </div>
        
        <div class="mx-2"></div>
        
        <div>
            <button class="btn btn-primary" onclick="clearsearch()">
                <i class="ti ti-eraser"></i>
                <span class="mx-2">Clear</span>
            </button>
        </div>
        
    </div>

    <div class="row mt-4">
        <div class="col-sm-6 col-lg-3 col-xl-3">
            <a class="p-4 text-center bg-light-primary card shadow-none rounded-2">
                <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/svgs/icon-user-male.svg"
                    width="50" height="50" class="mb-6 mx-auto" alt="">
                <p class="fw-semibold text-primary mb-1">Customers</p>
                <h4 class="fw-semibold text-primary mb-0"><?php echo e($customers); ?></h4>
            </a>
        </div>
        <div class="col-sm-6 col-lg-3 col-xl-3">
            <a class="p-4 text-center bg-light-warning card shadow-none rounded-2">
                <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/svgs/icon-briefcase.svg"
                    width="50" height="50" class="mb-6 mx-auto" alt="">
                <p class="fw-semibold text-warning mb-1">Bookings</p>
                <h4 class="fw-semibold text-warning mb-0"><?php echo e($bookings); ?></h4>
            </a>
        </div>

        <div class="col-sm-6 col-lg-3 col-xl-3">
            <a class="p-4 text-center bg-light-danger card shadow-none rounded-2">
                <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/svgs/icon-favorites.svg"
                    width="50" height="50" class="mb-6 mx-auto" alt="">
                <p class="fw-semibold text-danger mb-1">Revenue</p>
                <div class="d-flex justify-content-center">
                    <h4 class="fw-semibold text-danger mb-0" style="cursor: pointer"
                    data-bs-container="body" data-bs-toggle="popover" data-bs-placement="bottom" 
                      data-bs-content=" Revenue From Reservations: $<?php echo e(number_format(($revenue+$sales), 0, '', ',')); ?>

                      Revenue From Sales: $<?php echo e(number_format($sales, 0, '', ',')); ?>" style="white-space: pre-line;">
                        $<?php echo e(number_format(($revenue+$sales), 0, '', ',')); ?>

                    </h4>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-lg-3 col-xl-3">
            <a class="p-4 text-center bg-light-info card shadow-none rounded-2">
                <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/svgs/icon-connect.svg"
                    width="50" height="50" class="mb-6 mx-auto" alt="">
                <p class="fw-semibold text-info mb-1">Expenses</p>
                <h4 class="fw-semibold text-info mb-0">$<?php echo e(number_format($expenses, 0, '', ',')); ?></h4>
            </a>
        </div>

    </div>

    <div class="row">
        <div class="col">
            <a class="p-4 text-center bg-light-success card shadow-none rounded-2">
                <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/svgs/icon-speech-bubble.svg"
                    width="50" height="50" class="mb-6 mx-auto" alt="">
                <p class="fw-semibold text-success mb-1">Net Profit</p>
                <h4 class="fw-semibold text-success mb-0">$<?php echo e(number_format($net_profit, 0, '', ',')); ?></h4>
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-body p-4 d-flex align-items-center gap-3">
                    <div>
                        <h5 class="fw-semibold mb-0">Average Number Of Reservations Per Day</h5>
                    </div>
                    <button class="btn py-1 px-2 ms-auto"
                        style="background: #1E90FF;color:white"><?php echo e(number_format($avg_booking_, 2)); ?></button>
                </div>
            </div>
        </div>
        <div class="col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-body p-4 d-flex align-items-center gap-3">
                    <div>
                        <h5 class="fw-semibold mb-0">Average Duration Of Reservations</h5>
                    </div>
                    <button class="btn btn-primary py-1 px-2 ms-auto" style="background: #1E90FF;color:white">
                        <?php echo e(number_format($avg_duration_, 2)); ?> MINUTES
                    </button>
                </div>
            </div>
        </div>
        <div class="col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-body p-4 d-flex align-items-center gap-3">
                    <div>
                        <h5 class="fw-semibold mb-0">Cancelation Rate</h5>
                    </div>
                    <button class="btn btn-primary py-1 px-2 ms-auto"
                        style="background: #1E90FF;color:white"><?php echo e($canceled_booking_perc); ?> %</button>
                </div>
            </div>
        </div>
    </div>

    <section>
        <div class="row">
            <!-- Start Basic Bar Chart -->
            <div class="col-12 col-lg-4">
                <div class="card" style="height: 100%;">
                    <div class="card-body">
                        <h4>BOOKINGS</h4>
                        <div id="chart-bar-basic"></div>
                    </div>
                </div>
            </div>
            <!-- End Basic Bar Chart -->

            <!-- Start top per card -->
            <div class="col-12 col-lg-4">
                <div class="card" style="height: 100%;">
                    <div class="card-body">
                        <h4>TOP PERFORMING</h4>
                        <table class="mb-3 table">
                            <thead class="bg-success text-white">
                                <tr>
                                    <th>COURT</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $court_booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($cb['title_en']); ?></td>
                                        <td><?php echo e($cb['booking_count']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End top per card -->

            <!-- Start top per card -->
            <div class="col-12 col-lg-4">
                <div class="card" style="height: 100%;">
                    <div class="card-body">
                        <h4>CUSTOMERS</h4>
                        <table class="mb-3 table">
                            <thead class="bg-warning text-white">
                                <tr>
                                    <th>NAME</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $clients_booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client_booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($client_booking['full_name']); ?></td>
                                        <td><?php echo e($client_booking['booking_count']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End top per card -->

        </div>

    </section>

    



<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });
        // Get the URL parameters
        const urlParams = new URLSearchParams(window.location.search);

        var first_day_of_month = moment().startOf('month').format('YYYY-MM-DD');
        var last_day_of_month = moment().endOf('month').format('YYYY-MM-DD');

        var date_from = urlParams.get('date_from');
        var date_to = urlParams.get('date_to');

        // if (!date_from && !date_to) {
        //     $('#datefrom').val(first_day_of_month);
        //     $('#dateto').val(last_day_of_month);
        // }
        var courtId = urlParams.get('court_id');
        // Extract the sport_id parameter from the URL
        const sportId = urlParams.get('sport_id');
        // Check if sport_id exists and has a valid value
        if (sportId && sportId !== '') {
            // Sport ID exists and is not empty
            getCourts(sportId)
        } else {
            // Sport ID does not exist or is empty
            console.log('Sport ID does not exist or is empty');
        }


        function getCourts(sport_id = 0) {
            if (!sport_id) {
                var sport_id = $('#sports').val();
            }
            $('#courts').empty();
            $('#courts').append('<option selected disabled>--None--</option>');
            if (sport_id && sport_id != 0) {
                $.ajax({
                    url: "<?php echo e(route('booking.sportsbycourt')); ?>",
                    data: {
                        sport_id: sport_id
                    },
                    type: 'POST',
                    success: function(response) {
                        console.log(response);
                        if (response.success) {
                            var data = response.data;
                            for (var i = 0; i < data.length; i++) {
                                var option = $('<option>', {
                                    value: data[i].id,
                                    text: data[i].title_en
                                });
                                $('#courts').append(option);
                                // Check if court_id exists and has a valid value
                                if (courtId && courtId !== '') {
                                    $('#courts').val(courtId);
                                }
                            }
                        }
                    }
                });
            }
        }

        function search() {
            var URL = "<?php echo e(route('index')); ?>";
            var date_from = $('#datefrom').val().trim();
            if (date_from) {
                var parsedDate = moment(date_from, "MM/DD/YYYY", true);
                var convertedDate = parsedDate.isValid() ? parsedDate.format("YYYY-MM-DD") : date_from;
                date_from = convertedDate;
            }
            var date_to = $('#dateto').val().trim();
            if (date_to) {
                var parsedDate = moment(date_to, "MM/DD/YYYY", true);
                var convertedDate = parsedDate.isValid() ? parsedDate.format("YYYY-MM-DD") : date_to;
                date_to = convertedDate;
            }
            var sport_id = $('#sports').val().trim();
            var court_id = $('#courts').val();

            var element = [];

            if (date_from && date_to) {
                element.push('date_from=' + date_from);
                element.push('date_to=' + date_to);
            }

            if (sport_id && sport_id != null && sport_id != 'none') {
                element.push('sport_id=' + sport_id);
            }

            if (court_id && court_id != null && court_id != 'none') {
                element.push('court_id=' + court_id)
            }

            if (element.length > 0) {
                URL += '?' + element.join('&');
            } else {
                location.href = "<?php echo e(route('expensehistory.index')); ?>";
            }

            location.href = URL;

        }

        function clearsearch() {
            var URL = "<?php echo e(route('index')); ?>";
            $('#datefrom').val('');
            $('#dateto').val('');
            $('#sports').val('none');
            $('#courts').val('none')
        }

        //bar chart (CMS, OTHERS)
        var options_basic = {
            series: [{
                data: [<?php echo e($from_user); ?>, <?php echo e($from_club); ?>],
            }, ],
            chart: {
                fontFamily: '"Nunito Sans", sans-serif',
                type: "bar",
                height: 350,
                toolbar: {
                    show: false,
                },
            },
            grid: {
                borderColor: "transparent",
            },
            colors: ["var(--bs-primary)"],
            plotOptions: {
                bar: {
                    horizontal: false
                    //if you make it true so it becomes horizontal
                },
            },
            dataLabels: {
                enabled: false,
            },
            xaxis: {
                categories: [
                    "APP",
                    "OTHERS",
                ],
                labels: {
                    style: {
                        colors: [
                            "#a1aab2",
                            "#a1aab2",
                        ],
                    },
                },
            },
            yaxis: {
                labels: {
                    style: {
                        colors: [
                            "#a1aab2",
                            "#a1aab2",
                        ],
                    },
                },
            },
            tooltip: {
                theme: "dark",
            },
        };

        var chart_bar_basic = new ApexCharts(
            document.querySelector("#chart-bar-basic"),
            options_basic
        );
        chart_bar_basic.render();
        //bar chart (CMS, OTHERS)

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sportcietyapp/public_html/platform.sportcietyapp.com/resources/views/dashboard/index.blade.php ENDPATH**/ ?>