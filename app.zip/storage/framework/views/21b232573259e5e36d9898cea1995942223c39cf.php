<!-- Sidebar Start -->
<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div>
        <div class="brand-logo d-flex align-items-center justify-content-between">
            <a href="index.html" class="text-nowrap logo-img mx-2">
                <img src="<?php echo e(asset('images/logos/logo.png')); ?>" class="dark-logo" width="180" alt="" />
                <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/logos/light-logo.svg"
                    class="light-logo" width="180" alt="" />
            </a>
            <div class="close-btn d-lg-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
                <i class="ti ti-x fs-8"></i>
            </div>
        </div>

        <!-- Sidebar navigation-->
        <nav class="sidebar-nav scroll-sidebar mt-3" data-simplebar>
            <ul id="sidebarnav">

                <li class="sidebar-item <?php echo e(request()->routeIs('index') ? 'selected' : ''); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('index')); ?>" aria-expanded="false">
                        <span>
                            <i class="ti ti-gauge"></i>
                        </span>
                        <span class="hide-menu">Dashboard</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a class="sidebar-link" href="<?php echo e(route('multiple.index')); ?>" aria-expanded="false">
                        <span>
                            <i class="ti ti-calendar-event"></i>
                        </span>
                        <span class="hide-menu">Schedule</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a class="sidebar-link" href="<?php echo e(route('booking.index')); ?>" aria-expanded="false">
                        <span>
                            <i class="ti ti-brand-booking"></i>
                        </span>
                        <span class="hide-menu">Bookings</span>
                    </a>
                </li>

                <li
                    class="sidebar-item <?php echo e(request()->routeIs('clients.clientbookings') || request()->routeIs('clients.index') ? 'selected' : ''); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('clients.index')); ?>" aria-expanded="false">
                        <span>
                            <i class="ti ti-user-dollar"></i>
                        </span>
                        <span class="hide-menu">Clients</span>
                    </a>
                </li>



                <li
                    class="sidebar-item <?php echo e(request()->routeIs('courts.index') ||
                    request()->routeIs('courts.editsportpage') ||
                    request()->routeIs('courts.addsportpage') ||
                    request()->routeIs('courts.addcourtpage') ||
                    request()->routeIs('calendar.index') ||
                    request()->routeIs('courtitems.index') ||
                    request()->routeIs('courts.show')
                        ? 'selected'
                        : ''); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('courts.index')); ?>" aria-expanded="false">
                        <span><i class="ti ti-soccer-field"></i></span>
                        <span class="hide-menu">Courts</span>
                    </a>
                </li>

                <li class="sidebar-item ">
                    <a class="sidebar-link" href="<?php echo e(route('items.index')); ?>" aria-expanded="false">
                        <span><i class="ti ti-box-multiple"></i></span>
                        <span class="hide-menu">Items</span>
                    </a>
                </li>

                <li
                    class="sidebar-item <?php echo e(request()->routeIs('staff.index') ||
                    request()->routeIs('staff.storepage') ||
                    request()->routeIs('staff.update_staff_page') ||
                    request()->routeIs('staff.show_attendance_page')
                        ? 'selected'
                        : ''); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('staff.index')); ?>" aria-expanded="false">
                        <span>
                            <i class="ti ti-user"></i>
                        </span>
                        <span class="hide-menu">Staff</span>
                    </a>
                </li>

                

                <li
                    class="sidebar-item <?php echo e(request()->routeIs('expenses_type.index') || request()->routeIs('expenses.index') ? 'selected' : ''); ?>">
                    <a class="sidebar-link" href="#" aria-expanded="false">
                        <span>
                            <i class="ti ti-currency-dollar"></i>
                        </span>
                        <span class="hide-menu">Accounting</span>
                    </a>
                    <ul aria-expanded="false" class="collapse first-level">
                        <li class="sidebar-item">
                            <a href="<?php echo e(route('expenses_type.index')); ?>" class="sidebar-link">
                                <div class="round-16 d-flex align-items-center justify-content-center">
                                    <i class="ti ti-circle"></i>
                                </div>
                                <span class="hide-menu">Expenses</span>
                            </a>
                        </li>

                        <li class="sidebar-item">
                            <a href="<?php echo e(route('expensehistory.index')); ?>" class="sidebar-link">
                                <div class="round-16 d-flex align-items-center justify-content-center">
                                    <i class="ti ti-circle"></i>
                                </div>
                                <span class="hide-menu">Expenses History</span>
                            </a>
                        </li>
                    </ul>
                </li>

                

                <li
                    class="sidebar-item <?php echo e(request()->routeIs('permission.index') || request()->routeIs('permission.show') ? 'selected' : ''); ?>">
                    <a class="sidebar-link" href="<?php echo e(route('permission.index')); ?>" aria-expanded="false">
                        <span>
                            <i class="ti ti-users"></i>
                        </span>
                        <span class="hide-menu">Admins</span>
                    </a>
                </li>


            </ul>


            


        </nav>

        


        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>
<!--  Sidebar End -->
<?php /**PATH /home/sportcietyapp/public_html/beta/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>