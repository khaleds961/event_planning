<?php $__env->startSection('title', 'Add New Court'); ?>
<?php $__env->startSection('content'); ?>

    
    
    <nav aria-label="breadcrumb" class="mb-1">
        <ol class="breadcrumb border border-warning px-3 py-2 rounded">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                        class="ti ti-home fs-4 mt-1"></i></a>
            </li>
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('courts.index')); ?>" class="text-warning">Courts</a>
            </li>

            <li class="breadcrumb-item">
                <a class="text-warning">Add New Court</a>
            </li>
        </ol>
    </nav>

    <div class="card mt-3">
        <div class="card-body my-4">

            <form action="<?php echo e(route('courts.store')); ?>" method="POST" enctype="multipart/form-data" id="add_court_form">
                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-6">
                        <h6>Title<b style="color: #e86945">*</b></h6>
                        <input class="form-control my-2" type="text" name="title_en" id="title"
                            value="<?php echo e(old('title_en')); ?>" />
                        <span id="title_error"></span>
                    </div>
                </div>

                <div class="my-2">
                    <h6>Image</h6>
                    <input type="file" name="image" class="dropify" data-max-file-size="2M"
                        data-allowed-file-extensions="png jpg jpeg">
                </div>


                <div class="row mt-3">

                    <div class="col">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="list1"
                                name="is_private_court">
                            <label class="form-check-label" for="list1">
                                <h6>
                                    Private Court
                                </h6>
                            </label>
                        </div>
                    </div>

                    <div class="col">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input danger check-outline outline-danger" type="radio"
                                id="danger2-outline-radio" name="court_type" value="0" checked>
                            <label class="form-check-label" for="danger2-outline-radio">
                                <h6>
                                    Indoor
                                </h6>
                            </label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input danger check-outline outline-danger" type="radio"
                                id="danger3-outline-radio" name="court_type" value="1">
                            <label class="form-check-label" for="danger3-outline-radio">
                                <h6>
                                    Outdoor
                                </h6>
                            </label>
                        </div>
                    </div>

                </div>

                <div class="row mt-4">
                    <div class="col">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="days_specification"
                                name="day_specification">
                            <label class="form-check-label" for="days_specification">
                                <h6>
                                    Specify For Each Day
                                </h6>
                            </label>
                        </div>
                    </div>
                </div>


                <div id="container">
                    <div class="row" id="one_schedule">
                        <div class="col">
                            <div class="mb-3">
                                <label class="control-label col-form-label">Opening From <b
                                        style="color: #e86945">*</b></label>
                                <div class="input-group">
                                    <span class="input-group-text" id="basic-addon1">
                                        <i class="ti ti-clock-hour-4 fs-4"></i>
                                    </span>
                                    <input type="time" class="form-control" aria-describedby="basic-addon1"
                                        name="opening_from_all" id="opening_from_all">
                                </div>
                            </div>
                        </div>

                        <div class="col">
                            <div class="mb-3">
                                <label class="control-label col-form-label">Opening To <b
                                        style="color: #e86945">*</b></label>
                                <div class="input-group">
                                    <span class="input-group-text" id="basic-addon1">
                                        <i class="ti ti-clock-hour-4 fs-4"></i>
                                    </span>
                                    <input type="time" class="form-control" aria-describedby="basic-addon1"
                                        name="opening_to_all" id="opening_to_all">
                                </div>
                            </div>
                        </div>

                        <span id="opening_all_error"></span>

                    </div>

                    <div id="container_foreach_schedule">

                        <div id="foreach_schedule" style="display:none">
                            <div>
                                <div class="add_monday mt-1">
                                    <button type="button"
                                        class="btn mb-1 waves-effect waves-light btn-rounded btn-outline-danger add_monday_button">
                                        <span class="d-flex align-items-center">
                                            Monday
                                            <i class="mx-1 ti ti-circle-plus fs-4"></i>
                                        </span>
                                    </button>
                                </div>

                                <div id="monday_schedule">
                                    <div class="monday_row" data-id="1" id="monday_1">
                                        <div class="row d-flex align-items-center">
                                            <div class="col-sm-12 col-md-5">
                                                <div class="mb-3">
                                                    <label class="control-label col-form-label">Opening From <b
                                                            style="color: #e86945">*</b></label>
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="ti ti-clock-hour-4 fs-4"></i>
                                                        </span>
                                                        <input type="time"
                                                            class="form-control opening_from_monday flatpickr_from_monday_1"
                                                            aria-describedby="basic-addon1"
                                                            onchange="validate_time(1,'monday')"
                                                            name="opening_from_monday[]" id="opening_from_monday1"
                                                            data-id='1'>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-5">
                                                <div class="mb-3">
                                                    <label class="control-label col-form-label">Opening To <b
                                                            style="color: #e86945">*</b></label>
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="ti ti-clock-hour-4 fs-4"></i>
                                                        </span>
                                                        <input type="time"
                                                            class="form-control opening_to_monday flatpickr_to_monday_1"
                                                            aria-describedby="basic-addon1"
                                                            onchange="validate_time(1,'monday')"
                                                            name="opening_to_monday[]" id="opening_to_monday1"
                                                            data-id='1'>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-2">
                                                <div class='delete_row_monday margin_schedule_responsive' data-id='1'>
                                                    <div class="mt-sm-0 mt-md-4">
                                                        <button type="button" onclick="delete_row(event,'monday',1)"
                                                            class="btn waves-effect waves-light btn-rounded btn-outline-warning p-2">
                                                            <i class="ti ti-trash"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="foreach_schedule_tuesday" style="display:none">
                            <div>
                                <div class="add_tuesday mt-1">
                                    <button type="button"
                                        class="btn mb-1 waves-effect waves-light btn-rounded btn-outline-danger add_tuesday_button">
                                        <span class="d-flex align-items-center">
                                            Tuesday
                                            <i class="mx-1 ti ti-circle-plus fs-4"></i>
                                        </span>
                                    </button>
                                </div>

                                <div id="tuesday_schedule">
                                    <div class="tuesday_row" data-id="1" id="tuesday_1">
                                        <div class="row d-flex align-items-center">
                                            <div class="col-sm-12 col-md-5">
                                                <div class="mb-3">
                                                    <label class="control-label col-form-label">Opening From <b
                                                            style="color: #e86945">*</b></label>
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="ti ti-clock-hour-4 fs-4"></i>
                                                        </span>
                                                        <input type="time"
                                                            class="form-control opening_from_tuesday flatpickr_from_tuesday_1"
                                                            aria-describedby="basic-addon1"
                                                            onchange="validate_time(1,'tuesday')"
                                                            name="opening_from_tuesday[]" id="opening_from_tuesday1"
                                                            data-id='1'>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-5">
                                                <div class="mb-3">
                                                    <label class="control-label col-form-label">Opening To <b
                                                            style="color: #e86945">*</b></label>
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="ti ti-clock-hour-4 fs-4"></i>
                                                        </span>
                                                        <input type="time"
                                                            class="form-control opening_to_tuesday flatpickr_to_tuesday_1"
                                                            aria-describedby="basic-addon1"
                                                            onchange="validate_time(1,'tuesday')"
                                                            name="opening_to_tuesday[]" id="opening_to_tuesday1"
                                                            data-id='1'>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-2">
                                                <div class='delete_row_tuesday margin_schedule_responsive' data-id='1'>
                                                    <div class="mt-sm-0 mt-md-4">
                                                        <button type="button" onclick="delete_row(event,'tuesday',1)"
                                                            class="btn waves-effect waves-light btn-rounded btn-outline-warning p-2">
                                                            <i class="ti ti-trash"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="foreach_schedule_wednesday" style="display:none">
                            <div>
                                <div class="add_wednesday mt-1">
                                    <button type="button"
                                        class="btn mb-1 waves-effect waves-light btn-rounded btn-outline-danger add_wednesday_button">
                                        <span class="d-flex align-items-center">
                                            Wednesday
                                            <i class="mx-1 ti ti-circle-plus fs-4"></i>
                                        </span>
                                    </button>
                                </div>

                                <div id="wednesday_schedule">
                                    <div class="wednesday_row" data-id="1" id="wednesday_1">
                                        <div class="row d-flex align-items-center">
                                            <div class="col-sm-12 col-md-5">
                                                <div class="mb-3">
                                                    <label class="control-label col-form-label">Opening From <b
                                                            style="color: #e86945">*</b></label>
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="ti ti-clock-hour-4 fs-4"></i>
                                                        </span>
                                                        <input type="time"
                                                            class="form-control opening_from_wednesday flatpickr_from_wednesday_1"
                                                            aria-describedby="basic-addon1"
                                                            onchange="validate_time(1,'wednesday')"
                                                            name="opening_from_wednesday[]" id="opening_from_wednesday1"
                                                            data-id='1'>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-5">
                                                <div class="mb-3">
                                                    <label class="control-label col-form-label">Opening To <b
                                                            style="color: #e86945">*</b></label>
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="ti ti-clock-hour-4 fs-4"></i>
                                                        </span>
                                                        <input type="time"
                                                            class="form-control opening_to_wednesday flatpickr_to_wednesday_1"
                                                            aria-describedby="basic-addon1"
                                                            onchange="validate_time(1,'wednesday')"
                                                            name="opening_to_wednesday[]" id="opening_to_wednesday1"
                                                            data-id='1'>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-2">
                                                <div class='delete_row_wednesday margin_schedule_responsive'
                                                    data-id='1'>
                                                    <div class="mt-sm-0 mt-md-4">
                                                        <button type="button" onclick="delete_row(event,'wednesday',1)"
                                                            class="btn waves-effect waves-light btn-rounded btn-outline-warning p-2">
                                                            <i class="ti ti-trash"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="foreach_schedule_thursday" style="display:none">
                            <div>
                                <div class="add_thursday mt-1">
                                    <button type="button"
                                        class="btn mb-1 waves-effect waves-light btn-rounded btn-outline-danger add_thursday_button">
                                        <span class="d-flex align-items-center">
                                            Thursday
                                            <i class="mx-1 ti ti-circle-plus fs-4"></i>
                                        </span>
                                    </button>
                                </div>

                                <div id="thursday_schedule">
                                    <div class="thursday_row" data-id="1" id="thursday_1">
                                        <div class="row d-flex align-items-center">
                                            <div class="col-sm-12 col-md-5">
                                                <div class="mb-3">
                                                    <label class="control-label col-form-label">Opening From <b
                                                            style="color: #e86945">*</b></label>
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="ti ti-clock-hour-4 fs-4"></i>
                                                        </span>
                                                        <input type="time"
                                                            class="form-control opening_from_thursday flatpickr_from_thursday_1"
                                                            aria-describedby="basic-addon1"
                                                            onchange="validate_time(1,'thursday')"
                                                            name="opening_from_thursday[]" id="opening_from_thursday1"
                                                            data-id='1'>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-5">
                                                <div class="mb-3">
                                                    <label class="control-label col-form-label">Opening To <b
                                                            style="color: #e86945">*</b></label>
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="ti ti-clock-hour-4 fs-4"></i>
                                                        </span>
                                                        <input type="time"
                                                            class="form-control opening_to_thursday flatpickr_to_thursday_1"
                                                            aria-describedby="basic-addon1"
                                                            onchange="validate_time(1,'thursday')"
                                                            name="opening_to_thursday[]" id="opening_to_thursday1"
                                                            data-id='1'>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-2">
                                                <div class='delete_row_thursday margin_schedule_responsive'
                                                    data-id='1'>
                                                    <div class="mt-sm-0 mt-md-4">
                                                        <button type="button" onclick="delete_row(event,'thursday',1)"
                                                            class="btn waves-effect waves-light btn-rounded btn-outline-warning p-2">
                                                            <i class="ti ti-trash"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="foreach_schedule_friday" style="display:none">
                            <div>
                                <div class="add_friday mt-1">
                                    <button type="button"
                                        class="btn mb-1 waves-effect waves-light btn-rounded btn-outline-danger add_friday_button">
                                        <span class="d-flex align-items-center">
                                            Friday
                                            <i class="mx-1 ti ti-circle-plus fs-4"></i>
                                        </span>
                                    </button>
                                </div>

                                <div id="friday_schedule">
                                    <div class="friday_row" data-id="1" id="friday_1">
                                        <div class="row d-flex align-items-center">
                                            <div class="col-sm-12 col-md-5">
                                                <div class="mb-3">
                                                    <label class="control-label col-form-label">Opening From <b
                                                            style="color: #e86945">*</b></label>
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="ti ti-clock-hour-4 fs-4"></i>
                                                        </span>
                                                        <input type="time"
                                                            class="form-control opening_from_friday flatpickr_from_friday_1"
                                                            aria-describedby="basic-addon1"
                                                            onchange="validate_time(1,'friday')"
                                                            name="opening_from_friday[]" id="opening_from_friday1"
                                                            data-id='1'>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-5">
                                                <div class="mb-3">
                                                    <label class="control-label col-form-label">Opening To <b
                                                            style="color: #e86945">*</b></label>
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="ti ti-clock-hour-4 fs-4"></i>
                                                        </span>
                                                        <input type="time"
                                                            class="form-control opening_to_friday flatpickr_to_friday_1"
                                                            aria-describedby="basic-addon1"
                                                            onchange="validate_time(1,'friday')"
                                                            name="opening_to_friday[]" id="opening_to_friday1"
                                                            data-id='1'>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-2">
                                                <div class='delete_row_friday margin_schedule_responsive' data-id='1'>
                                                    <div class="mt-sm-0 mt-md-4">
                                                        <button type="button" onclick="delete_row(event,'friday',1)"
                                                            class="btn waves-effect waves-light btn-rounded btn-outline-warning p-2">
                                                            <i class="ti ti-trash"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="foreach_schedule_saturday" style="display:none">
                            <div>
                                <div class="add_saturday mt-1">
                                    <button type="button"
                                        class="btn mb-1 waves-effect waves-light btn-rounded btn-outline-danger add_saturday_button">
                                        <span class="d-flex align-items-center">
                                            Saturday
                                            <i class="mx-1 ti ti-circle-plus fs-4"></i>
                                        </span>
                                    </button>
                                </div>

                                <div id="saturday_schedule">
                                    <div class="saturday_row" data-id="1" id="saturday_1">
                                        <div class="row d-flex align-items-center">
                                            <div class="col-sm-12 col-md-5">
                                                <div class="mb-3">
                                                    <label class="control-label col-form-label">Opening From <b
                                                            style="color: #e86945">*</b></label>
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="ti ti-clock-hour-4 fs-4"></i>
                                                        </span>
                                                        <input type="time"
                                                            class="form-control opening_from_saturday flatpickr_from_saturday_1"
                                                            aria-describedby="basic-addon1"
                                                            onchange="validate_time(1,'saturday')"
                                                            name="opening_from_saturday[]" id="opening_from_saturday1"
                                                            data-id='1'>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-5">
                                                <div class="mb-3">
                                                    <label class="control-label col-form-label">Opening To <b
                                                            style="color: #e86945">*</b></label>
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="ti ti-clock-hour-4 fs-4"></i>
                                                        </span>
                                                        <input type="time"
                                                            class="form-control opening_to_saturday flatpickr_to_saturday_1"
                                                            aria-describedby="basic-addon1"
                                                            onchange="validate_time(1,'saturday')"
                                                            name="opening_to_saturday[]" id="opening_to_saturday1"
                                                            data-id='1'>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-2">
                                                <div class='delete_row_saturday margin_schedule_responsive'
                                                    data-id='1'>
                                                    <div class="mt-sm-0 mt-md-4">
                                                        <button type="button" onclick="delete_row(event,'saturday',1)"
                                                            class="btn waves-effect waves-light btn-rounded btn-outline-warning p-2">
                                                            <i class="ti ti-trash"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="foreach_schedule_sunday" style="display:none">
                            <div>
                                <div class="add_sunday mt-1">
                                    <button type="button"
                                        class="btn mb-1 waves-effect waves-light btn-rounded btn-outline-danger add_sunday_button">
                                        <span class="d-flex align-items-center">
                                            Sunday
                                            <i class="mx-1 ti ti-circle-plus fs-4"></i>
                                        </span>
                                    </button>
                                </div>

                                <div id="sunday_schedule">
                                    <div class="sunday_row" data-id="1" id="sunday_1">
                                        <div class="row d-flex align-items-center">
                                            <div class="col-sm-12 col-md-5">
                                                <div class="mb-3">
                                                    <label class="control-label col-form-label">Opening From <b
                                                            style="color: #e86945">*</b></label>
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="ti ti-clock-hour-4 fs-4"></i>
                                                        </span>
                                                        <input type="time"
                                                            class="form-control opening_from_sunday flatpickr_from_sunday_1"
                                                            aria-describedby="basic-addon1"
                                                            onchange="validate_time(1,'sunday')"
                                                            name="opening_from_sunday[]" id="opening_from_sunday1"
                                                            data-id='1'>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-5">
                                                <div class="mb-3">
                                                    <label class="control-label col-form-label">Opening To <b
                                                            style="color: #e86945">*</b></label>
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="ti ti-clock-hour-4 fs-4"></i>
                                                        </span>
                                                        <input type="time"
                                                            class="form-control opening_to_sunday flatpickr_to_sunday_1"
                                                            aria-describedby="basic-addon1"
                                                            onchange="validate_time(1,'sunday')"
                                                            name="opening_to_sunday[]" id="opening_to_sunday1"
                                                            data-id='1'>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-2">
                                                <div class='delete_row_sunday margin_schedule_responsive' data-id='1'>
                                                    <div class="mt-sm-0 mt-md-4">
                                                        <button type="button" onclick="delete_row(event,'sunday',1)"
                                                            class="btn waves-effect waves-light btn-rounded btn-outline-warning p-2">
                                                            <i class="ti ti-trash"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>

                <div class="row mt-2">
                    <div class="col-sm-12 col-md-6">
                        <span class="block">
                            <h6>
                                Description
                            </h6>
                        </span>
                        <textarea placeholder="Enter Text" class="form-control rounded h-100" name="description"></textarea>
                    </div>
                </div>

                <div class="d-flex justify-content-end mt-5">
                    <button type="button" class="btn mb-1 waves-effect waves-light btn-light-success text-success fs-4"
                        type="submit" id="save">
                        <i class="ti ti-device-floppy"></i>
                        <span>Save</span>
                    </button>
                </div>


        </div>


        </form>
    </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-scripts'); ?>
    <script>
        function validate_time(id, day) {
            var opening_from = $(`#opening_from_${day}${id}`).val();
            var opening_to = $(`#opening_to_${day}${id}`).val();

            //the original one
            // if (opening_from == opening_to || opening_from > opening_to) {
            
            //updated
            if (opening_from == opening_to) {
                $(`.flatpickr_to_${day}_${id}`).val("")
            }
        }

        function delete_row(e, day, id) {
            e.preventDefault();
            // Get all elements with class name "monday_row"
            var divs = $(`.${day}_row`);

            //this is new 2 lines ---> the rest is the original
            $(`.flatpickr_from_${day}_${id}`).val('')
            $(`.flatpickr_to_${day}_${id}`).val('')
            return;
            
            // Check if there is only one row
            if (divs.length <= 1) {
                swal("CANNOT DELETE THE LAST ROW", {
                    icon: "warning",
                });
                return;
            }
            // Delete the corresponding div element
            $(`.${day}_row[data-id=${id}]`).remove();
        }

        $(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('.dropify').dropify();

            //original version --
            // //add Schedule Monday
            // var lastOpeningToMonday = $('.opening_from_monday').last();
            // var lastId = lastOpeningToMonday.data('id');

            // $(document).on('click', '.add_monday_button', function(e) {

            //     var last_opening_from = $('.opening_from_monday').last().val();
            //     var last_opening_to = $('.opening_to_monday').last().val();

            //     if (last_opening_from != '' && last_opening_to != '') {

            //         if (lastOpeningToMonday.length > 0) {
            //             lastId++;
            //             $('#monday_schedule').append(`
        //             <div class="monday_row" data-id="${lastId}" id="monday_${lastId}">
        //                             <div class="row d-flex align-items-center">
        //                                 <div class="col-sm-12 col-md-5">
        //                                     <div class="mb-3">
        //                                         <label class="control-label col-form-label">Opening From <b
        //                                                 style="color: #e86945">*</b></label>
        //                                         <div class="input-group">
        //                                             <span class="input-group-text" id="basic-addon1">
        //                                                 <i class="ti ti-clock-hour-4 fs-4"></i>
        //                                             </span>
        //                                             <input type="time"
        //                                                 class="form-control opening_from_monday flatpickr_from_monday_${lastId}"
        //                                                 aria-describedby="basic-addon1"
        //                                                 onchange="validate_time(${lastId},'monday')"
        //                                                 name="opening_from_monday[]" id="opening_from_monday${lastId}"
        //                                                 data-id='${lastId}'>
        //                                         </div>
        //                                     </div>
        //                                 </div>

        //                                 <div class="col-sm-12 col-md-5">
        //                                     <div class="mb-3">
        //                                         <label class="control-label col-form-label">Opening To <b
        //                                                 style="color: #e86945">*</b></label>
        //                                         <div class="input-group">
        //                                             <span class="input-group-text" id="basic-addon1">
        //                                                 <i class="ti ti-clock-hour-4 fs-4"></i>
        //                                             </span>
        //                                             <input type="time"
        //                                                 class="form-control opening_to_monday flatpickr_to_monday_${lastId}"
        //                                                 aria-describedby="basic-addon1"
        //                                                 onchange="validate_time(${lastId},'monday')"
        //                                                 name="opening_to_monday[]" id="opening_to_monday${lastId}"
        //                                                 data-id='${lastId}'>
        //                                         </div>
        //                                     </div>
        //                                 </div>

        //                                 <div class="col-sm-12 col-md-2">
        //                                 <div class='delete_row_monday margin_schedule_responsive' data-id='${lastId}'>
        //                                     <div class="mt-sm-0 mt-md-4">
        //                                     <button type="button" onclick="delete_row(event,'monday',${lastId})"
        //                                         class="btn waves-effect waves-light btn-rounded btn-outline-warning p-2">
        //                                         <i class="ti ti-trash"></i>
        //                                     </button>
        //                                 </div>
        //                                 </div>
        //                                 </div>

        //                             </div>
        //                         </div>`)

            //         }
            //     } else {
            //         swal("OPENING FROM AND OPENING TO SHOULD NOT BE EMPTY!", {
            //             icon: "warning",
            //         })
            //         return
            //     }
            // })

            // //add Schedule tuesday
            // var lastOpeningTotuesday = $('.opening_from_tuesday').last();
            // var lastId = lastOpeningTotuesday.data('id');

            // $(document).on('click', '.add_tuesday_button', function(e) {

            //     var last_opening_from = $('.opening_from_tuesday').last().val();
            //     var last_opening_to = $('.opening_to_tuesday').last().val();

            //     if (last_opening_from != '' && last_opening_to != '') {

            //         if (lastOpeningTotuesday.length > 0) {
            //             lastId++;
            //             $('#tuesday_schedule').append(`
        //             <div class="tuesday_row" data-id="${lastId}" id="tuesday_${lastId}">
        //             <div class="row d-flex align-items-center">
        //                 <div class="col-sm-12 col-md-5">
        //                     <div class="mb-3">
        //                         <label class="control-label col-form-label">Opening From <b
        //                                 style="color: #e86945">*</b></label>
        //                         <div class="input-group">
        //                             <span class="input-group-text" id="basic-addon1">
        //                                 <i class="ti ti-clock-hour-4 fs-4"></i>
        //                             </span>
        //                             <input type="time"
        //                                 class="form-control opening_from_tuesday flatpickr_from_tuesday_${lastId}"
        //                                 aria-describedby="basic-addon1"
        //                                 onchange="validate_time(${lastId},'tuesday')"
        //                                 name="opening_from_tuesday[]" id="opening_from_tuesday${lastId}"
        //                                 data-id='${lastId}'>
        //                         </div>
        //                     </div>
        //                 </div>

        //                 <div class="col-sm-12 col-md-5">
        //                     <div class="mb-3">
        //                         <label class="control-label col-form-label">Opening To <b
        //                                 style="color: #e86945">*</b></label>
        //                         <div class="input-group">
        //                             <span class="input-group-text" id="basic-addon1">
        //                                 <i class="ti ti-clock-hour-4 fs-4"></i>
        //                             </span>
        //                             <input type="time"
        //                                 class="form-control opening_to_tuesday flatpickr_to_tuesday_${lastId}"
        //                                 aria-describedby="basic-addon1"
        //                                 onchange="validate_time(${lastId},'tuesday')"
        //                                 name="opening_to_tuesday[]" id="opening_to_tuesday${lastId}"
        //                                 data-id='${lastId}'>
        //                         </div>
        //                     </div>
        //                 </div>

        //                 <div class="col-sm-12 col-md-2">
        //                 <div class='delete_row_tuesday margin_schedule_responsive' data-id='${lastId}'>
        //                     <div class="mt-sm-0 mt-md-4">
        //                     <button type="button" onclick="delete_row(event,'tuesday',${lastId})"
        //                         class="btn waves-effect waves-light btn-rounded btn-outline-warning p-2">
        //                         <i class="ti ti-trash"></i>
        //                     </button>
        //                 </div>
        //                 </div>
        //                 </div>

        //             </div>
        //         </div>`)

            //         }
            //     } else {
            //         swal("OPENING FROM AND OPENING TO SHOULD NOT BE EMPTY!", {
            //             icon: "warning",
            //         })
            //         return
            //     }
            // })

            // //add Schedule wednesday
            // var lastOpeningTowednesday = $('.opening_from_wednesday').last();
            // var lastId = lastOpeningTowednesday.data('id');

            // $(document).on('click', '.add_wednesday_button', function(e) {

            //     var last_opening_from = $('.opening_from_wednesday').last().val();
            //     var last_opening_to = $('.opening_to_wednesday').last().val();

            //     if (last_opening_from != '' && last_opening_to != '') {

            //         if (lastOpeningTowednesday.length > 0) {
            //             lastId++;
            //             $('#wednesday_schedule').append(`
        //             <div class="wednesday_row" data-id="${lastId}" id="wednesday_${lastId}">
        //             <div class="row d-flex align-items-center">
        //                 <div class="col-sm-12 col-md-5">
        //                     <div class="mb-3">
        //                 <label class="control-label col-form-label">Opening From <b
        //                         style="color: #e86945">*</b></label>
        //                 <div class="input-group">
        //                     <span class="input-group-text" id="basic-addon1">
        //                         <i class="ti ti-clock-hour-4 fs-4"></i>
        //                     </span>
        //                     <input type="time"
        //                         class="form-control opening_from_wednesday flatpickr_from_wednesday_${lastId}"
        //                         aria-describedby="basic-addon1"
        //                         onchange="validate_time(${lastId},'wednesday')"
        //                         name="opening_from_wednesday[]" id="opening_from_wednesday${lastId}"
        //                         data-id='${lastId}'>
        //             </div>
        //             </div>
        //             </div>
        //             <div class="col-sm-12 col-md-5">
        //                 <div class="mb-3">
        //                     <label class="control-label col-form-label">Opening To <b
        //                             style="color: #e86945">*</b></label>
        //                     <div class="input-group">
        //                         <span class="input-group-text" id="basic-addon1">
        //                             <i class="ti ti-clock-hour-4 fs-4"></i>
        //                         </span>
        //                         <input type="time"
        //                             class="form-control opening_to_wednesday flatpickr_to_wednesday_${lastId}"
        //                             aria-describedby="basic-addon1"
        //                             onchange="validate_time(${lastId},'wednesday')"
        //                             name="opening_to_wednesday[]" id="opening_to_wednesday${lastId}"
        //                             data-id='${lastId}'>
        //                     </div>
        //                 </div>
        //             </div>

        //             <div class="col-sm-12 col-md-2">
        //             <div class='delete_row_wednesday margin_schedule_responsive' data-id='${lastId}'>
        //                 <div class="mt-sm-0 mt-md-4">
        //                 <button type="button" onclick="delete_row(event,'wednesday',${lastId})"
        //                     class="btn waves-effect waves-light btn-rounded btn-outline-warning p-2">
        //                     <i class="ti ti-trash"></i>
        //                 </button>
        //             </div>
        //             </div>
        //             </div>
        //             </div>
        //             </div>`)

            //         }
            //     } else {
            //         swal("OPENING FROM AND OPENING TO SHOULD NOT BE EMPTY!", {
            //             icon: "warning",
            //         })
            //         return
            //     }
            // })

            // //add Schedule thursday
            // var lastOpeningTothursday = $('.opening_from_thursday').last();
            // var lastId = lastOpeningTothursday.data('id');

            // $(document).on('click', '.add_thursday_button', function(e) {

            //     var last_opening_from = $('.opening_from_thursday').last().val();
            //     var last_opening_to = $('.opening_to_thursday').last().val();

            //     if (last_opening_from != '' && last_opening_to != '') {

            //         if (lastOpeningTothursday.length > 0) {
            //             lastId++;
            //             $('#thursday_schedule').append(`
        //             <div class="thursday_row" data-id="${lastId}" id="thursday_${lastId}">
        //             <div class="row d-flex align-items-center">
        //                 <div class="col-sm-12 col-md-5">
        //                     <div class="mb-3">
        //                 <label class="control-label col-form-label">Opening From <b
        //                         style="color: #e86945">*</b></label>
        //                 <div class="input-group">
        //                     <span class="input-group-text" id="basic-addon1">
        //                         <i class="ti ti-clock-hour-4 fs-4"></i>
        //                     </span>
        //                     <input type="time"
        //                         class="form-control opening_from_thursday flatpickr_from_thursday_${lastId}"
        //                         aria-describedby="basic-addon1"
        //                         onchange="validate_time(${lastId},'thursday')"
        //                         name="opening_from_thursday[]" id="opening_from_thursday${lastId}"
        //                         data-id='${lastId}'>
        //                         </div>
        //                         </div>
        //                         </div>
        //                         <div class="col-sm-12 col-md-5">
        //                             <div class="mb-3">
        //                                 <label class="control-label col-form-label">Opening To <b
        //                                         style="color: #e86945">*</b></label>
        //                                 <div class="input-group">
        //                                     <span class="input-group-text" id="basic-addon1">
        //                                         <i class="ti ti-clock-hour-4 fs-4"></i>
        //                                     </span>
        //                                     <input type="time"
        //                                         class="form-control opening_to_thursday flatpickr_to_thursday_${lastId}"
        //                                         aria-describedby="basic-addon1"
        //                                         onchange="validate_time(${lastId},'thursday')"
        //                                         name="opening_to_thursday[]" id="opening_to_thursday${lastId}"
        //                                         data-id='${lastId}'>
        //                                 </div>
        //                             </div>
        //                         </div>

        //                         <div class="col-sm-12 col-md-2">
        //                         <div class='delete_row_thursday margin_schedule_responsive' data-id='${lastId}'>
        //                             <div class="mt-sm-0 mt-md-4">
        //                             <button type="button" onclick="delete_row(event,'thursday',${lastId})"
        //                                 class="btn waves-effect waves-light btn-rounded btn-outline-warning p-2">
        //                                 <i class="ti ti-trash"></i>
        //                             </button>
        //                         </div>
        //                         </div>
        //                         </div>
        //                         </div>
        //                         </div>`)

            //         }
            //     } else {
            //         swal("OPENING FROM AND OPENING TO SHOULD NOT BE EMPTY!", {
            //             icon: "warning",
            //         })
            //         return
            //     }
            // })

            // //add Schedule friday
            // var lastOpeningTofriday = $('.opening_from_friday').last();
            // var lastId = lastOpeningTofriday.data('id');

            // $(document).on('click', '.add_friday_button', function(e) {

            //     var last_opening_from = $('.opening_from_friday').last().val();
            //     var last_opening_to = $('.opening_to_friday').last().val();

            //     if (last_opening_from != '' && last_opening_to != '') {

            //         if (lastOpeningTofriday.length > 0) {
            //             lastId++;
            //             $('#friday_schedule').append(`
        //         <div class="friday_row" data-id="${lastId}" id="friday_${lastId}">
        //         <div class="row d-flex align-items-center">
        //             <div class="col-sm-12 col-md-5">
        //                 <div class="mb-3">
        //             <label class="control-label col-form-label">Opening From <b
        //                     style="color: #e86945">*</b></label>
        //             <div class="input-group">
        //                 <span class="input-group-text" id="basic-addon1">
        //                     <i class="ti ti-clock-hour-4 fs-4"></i>
        //                 </span>
        //                 <input type="time"
        //                     class="form-control opening_from_friday flatpickr_from_friday_${lastId}"
        //                     aria-describedby="basic-addon1"
        //                     onchange="validate_time(${lastId},'friday')"
        //                     name="opening_from_friday[]" id="opening_from_friday${lastId}"
        //                     data-id='${lastId}'>
        //                     </div>
        //                     </div>
        //                     </div>
        //                     <div class="col-sm-12 col-md-5">
        //                         <div class="mb-3">
        //                             <label class="control-label col-form-label">Opening To <b
        //                                     style="color: #e86945">*</b></label>
        //                             <div class="input-group">
        //                                 <span class="input-group-text" id="basic-addon1">
        //                                     <i class="ti ti-clock-hour-4 fs-4"></i>
        //                                 </span>
        //                                 <input type="time"
        //                                     class="form-control opening_to_friday flatpickr_to_friday_${lastId}"
        //                                     aria-describedby="basic-addon1"
        //                                     onchange="validate_time(${lastId},'friday')"
        //                                     name="opening_to_friday[]" id="opening_to_friday${lastId}"
        //                                     data-id='${lastId}'>
        //                             </div>
        //                         </div>
        //                     </div>

        //                     <div class="col-sm-12 col-md-2">
        //                     <div class='delete_row_friday margin_schedule_responsive' data-id='${lastId}'>
        //                         <div class="mt-sm-0 mt-md-4">
        //                         <button type="button" onclick="delete_row(event,'friday',${lastId})"
        //                             class="btn waves-effect waves-light btn-rounded btn-outline-warning p-2">
        //                             <i class="ti ti-trash"></i>
        //                         </button>
        //                     </div>
        //                     </div>
        //                     </div>
        //                     </div>
        //                     </div>`)

            //         }
            //     } else {
            //         swal("OPENING FROM AND OPENING TO SHOULD NOT BE EMPTY!", {
            //             icon: "warning",
            //         })
            //         return
            //     }
            // })

            // //add Schedule saturday
            // var lastOpeningTosaturday = $('.opening_from_saturday').last();
            // var lastId = lastOpeningTosaturday.data('id');

            // $(document).on('click', '.add_saturday_button', function(e) {

            //     var last_opening_from = $('.opening_from_saturday').last().val();
            //     var last_opening_to = $('.opening_to_saturday').last().val();

            //     if (last_opening_from != '' && last_opening_to != '') {

            //         if (lastOpeningTosaturday.length > 0) {
            //             lastId++;
            //             $('#saturday_schedule').append(`
        //         <div class="saturday_row" data-id="${lastId}" id="saturday_${lastId}">
        //         <div class="row d-flex align-items-center">
        //             <div class="col-sm-12 col-md-5">
        //                 <div class="mb-3">
        //             <label class="control-label col-form-label">Opening From <b
        //                     style="color: #e86945">*</b></label>
        //             <div class="input-group">
        //                 <span class="input-group-text" id="basic-addon1">
        //                     <i class="ti ti-clock-hour-4 fs-4"></i>
        //                 </span>
        //                 <input type="time"
        //                     class="form-control opening_from_saturday flatpickr_from_saturday_${lastId}"
        //                     aria-describedby="basic-addon1"
        //                     onchange="validate_time(${lastId},'saturday')"
        //                     name="opening_from_saturday[]" id="opening_from_saturday${lastId}"
        //                     data-id='${lastId}'>
        //                     </div>
        //                     </div>
        //                     </div>
        //                     <div class="col-sm-12 col-md-5">
        //                         <div class="mb-3">
        //                             <label class="control-label col-form-label">Opening To <b
        //                                     style="color: #e86945">*</b></label>
        //                             <div class="input-group">
        //                                 <span class="input-group-text" id="basic-addon1">
        //                                     <i class="ti ti-clock-hour-4 fs-4"></i>
        //                                 </span>
        //                                 <input type="time"
        //                                     class="form-control opening_to_saturday flatpickr_to_saturday_${lastId}"
        //                                     aria-describedby="basic-addon1"
        //                                     onchange="validate_time(${lastId},'saturday')"
        //                                     name="opening_to_saturday[]" id="opening_to_saturday${lastId}"
        //                                     data-id='${lastId}'>
        //                             </div>
        //                         </div>
        //                     </div>

        //                     <div class="col-sm-12 col-md-2">
        //                     <div class='delete_row_saturday margin_schedule_responsive' data-id='${lastId}'>
        //                         <div class="mt-sm-0 mt-md-4">
        //                         <button type="button" onclick="delete_row(event,'saturday',${lastId})"
        //                             class="btn waves-effect waves-light btn-rounded btn-outline-warning p-2">
        //                             <i class="ti ti-trash"></i>
        //                         </button>
        //                     </div>
        //                     </div>
        //                     </div>
        //                     </div>
        //                     </div>`)

            //         }
            //     } else {
            //         swal("OPENING FROM AND OPENING TO SHOULD NOT BE EMPTY!", {
            //             icon: "warning",
            //         })
            //         return
            //     }
            // })

            // //add Schedule sunday
            // var lastOpeningTosunday = $('.opening_from_sunday').last();
            // var lastId = lastOpeningTosunday.data('id');

            // $(document).on('click', '.add_sunday_button', function(e) {

            //     var last_opening_from = $('.opening_from_sunday').last().val();
            //     var last_opening_to = $('.opening_to_sunday').last().val();

            //     if (last_opening_from != '' && last_opening_to != '') {

            //         if (lastOpeningTosunday.length > 0) {
            //             lastId++;
            //             $('#sunday_schedule').append(`
        //         <div class="sunday_row" data-id="${lastId}" id="sunday_${lastId}">
        //         <div class="row d-flex align-items-center">
        //             <div class="col-sm-12 col-md-5">
        //                 <div class="mb-3">
        //             <label class="control-label col-form-label">Opening From <b
        //                     style="color: #e86945">*</b></label>
        //             <div class="input-group">
        //                 <span class="input-group-text" id="basic-addon1">
        //                     <i class="ti ti-clock-hour-4 fs-4"></i>
        //                 </span>
        //                 <input type="time"
        //                     class="form-control opening_from_sunday flatpickr_from_sunday_${lastId}"
        //                     aria-describedby="basic-addon1"
        //                     onchange="validate_time(${lastId},'sunday')"
        //                     name="opening_from_sunday[]" id="opening_from_sunday${lastId}"
        //                     data-id='${lastId}'>
        //                     </div>
        //                     </div>
        //                     </div>
        //                     <div class="col-sm-12 col-md-5">
        //                         <div class="mb-3">
        //                             <label class="control-label col-form-label">Opening To <b
        //                                     style="color: #e86945">*</b></label>
        //                             <div class="input-group">
        //                                 <span class="input-group-text" id="basic-addon1">
        //                                     <i class="ti ti-clock-hour-4 fs-4"></i>
        //                                 </span>
        //                                 <input type="time"
        //                                     class="form-control opening_to_sunday flatpickr_to_sunday_${lastId}"
        //                                     aria-describedby="basic-addon1"
        //                                     onchange="validate_time(${lastId},'sunday')"
        //                                     name="opening_to_sunday[]" id="opening_to_sunday${lastId}"
        //                                     data-id='${lastId}'>
        //                             </div>
        //                         </div>
        //                     </div>

        //                     <div class="col-sm-12 col-md-2">
        //                     <div class='delete_row_sunday margin_schedule_responsive' data-id='${lastId}'>
        //                         <div class="mt-sm-0 mt-md-4">
        //                         <button type="button" onclick="delete_row(event,'sunday',${lastId})"
        //                             class="btn waves-effect waves-light btn-rounded btn-outline-warning p-2">
        //                             <i class="ti ti-trash"></i>
        //                         </button>
        //                     </div>
        //                     </div>
        //                     </div>
        //                     </div>
        //                     </div>`)

            //         }
            //     } else {
            //         swal("OPENING FROM AND OPENING TO SHOULD NOT BE EMPTY!", {
            //             icon: "warning",
            //         })
            //         return
            //     }
            // })

            //delete tuesday rows
            // $(document).on('click', '.delete_row_tuesday', function(e) {
            //     console.log(';kdkdkkd');
            //     e.preventDefault()
            //     // Get all elements with class name "my-div"
            //     var divs = $('.tuesday_row');

            //     // Get the ID of the clicked delete button
            //     var id = $(this).data('id');

            //     // Find the largest ID
            //     var largestId = 0;
            //     divs.each(function() {
            //         var divId = $(this).data('id');
            //         if (divId > largestId) {
            //             largestId = divId;
            //         }
            //     });

            //     // Check if the clicked div is the largest one
            //     if (id == largestId) {
            //         swal("CANNOT DELETE THE LAST ROW", {
            //             icon: "warning",
            //         })
            //     } else {
            //         // Delete the corresponding div element
            //         $('.tuesday_row[data-id="' + id + '"]').remove();
            //     }
            // })

            // //delete wednesday rows
            // $(document).on('click', '.delete_row_wednesday', function(e) {
            //     e.preventDefault()
            //     // Get all elements with class name "my-div"
            //     var divs = $('.wednesday_row');

            //     // Get the ID of the clicked delete button
            //     var id = $(this).data('id');

            //     // Find the largest ID
            //     var largestId = 0;
            //     divs.each(function() {
            //         var divId = $(this).data('id');
            //         if (divId > largestId) {
            //             largestId = divId;
            //         }
            //     });

            //     // Check if the clicked div is the largest one
            //     if (id == largestId) {
            //         swal("CANNOT DELETE THE LAST ROW", {
            //             icon: "warning",
            //         })
            //     } else {
            //         // Delete the corresponding div element
            //         $('.wednesday_row[data-id="' + id + '"]').remove();
            //     }
            // })

            // //delete thursday rows
            // $(document).on('click', '.delete_row_thursday', function(e) {
            //     e.preventDefault()
            //     // Get all elements with class name "my-div"
            //     var divs = $('.thursday_row');

            //     // Get the ID of the clicked delete button
            //     var id = $(this).data('id');

            //     // Find the largest ID
            //     var largestId = 0;
            //     divs.each(function() {
            //         var divId = $(this).data('id');
            //         if (divId > largestId) {
            //             largestId = divId;
            //         }
            //     });

            //     // Check if the clicked div is the largest one
            //     if (id == largestId) {
            //         swal("CANNOT DELETE THE LAST ROW", {
            //             icon: "warning",
            //         })
            //     } else {
            //         // Delete the corresponding div element
            //         $('.thursday_row[data-id="' + id + '"]').remove();
            //     }
            // })

            // //delete friday rows
            // $(document).on('click', '.delete_row_friday', function(e) {
            //     e.preventDefault()
            //     // Get all elements with class name "my-div"
            //     var divs = $('.friday_row');

            //     // Get the ID of the clicked delete button
            //     var id = $(this).data('id');

            //     // Find the largest ID
            //     var largestId = 0;
            //     divs.each(function() {
            //         var divId = $(this).data('id');
            //         if (divId > largestId) {
            //             largestId = divId;
            //         }
            //     });

            //     // Check if the clicked div is the largest one
            //     if (id == largestId) {
            //         swal("CANNOT DELETE THE LAST ROW", {
            //             icon: "warning",
            //         })
            //     } else {
            //         // Delete the corresponding div element
            //         $('.friday_row[data-id="' + id + '"]').remove();
            //     }
            // })

            // //delete saturday rows
            // $(document).on('click', '.delete_row_saturday', function(e) {
            //     e.preventDefault()
            //     // Get all elements with class name "my-div"
            //     var divs = $('.saturday_row');

            //     // Get the ID of the clicked delete button
            //     var id = $(this).data('id');

            //     // Find the largest ID
            //     var largestId = 0;
            //     divs.each(function() {
            //         var divId = $(this).data('id');
            //         if (divId > largestId) {
            //             largestId = divId;
            //         }
            //     });

            //     // Check if the clicked div is the largest one
            //     if (id == largestId) {
            //         swal("CANNOT DELETE THE LAST ROW", {
            //             icon: "warning",
            //         })
            //     } else {
            //         // Delete the corresponding div element
            //         $('.saturday_row[data-id="' + id + '"]').remove();
            //     }
            // })

            // //delete saturday rows
            // $(document).on('click', '.delete_row_sunday', function(e) {
            //     e.preventDefault()
            //     // Get all elements with class name "my-div"
            //     var divs = $('.sunday_row');

            //     // Get the ID of the clicked delete button
            //     var id = $(this).data('id');

            //     // Find the largest ID
            //     var largestId = 0;
            //     divs.each(function() {
            //         var divId = $(this).data('id');
            //         if (divId > largestId) {
            //             largestId = divId;
            //         }
            //     });

            //     // Check if the clicked div is the largest one
            //     if (id == largestId) {
            //         swal("CANNOT DELETE THE LAST ROW", {
            //             icon: "warning",
            //         })
            //     } else {
            //         // Delete the corresponding div element
            //         $('.sunday_row[data-id="' + id + '"]').remove();
            //     }
            // })

            //days_specification for all the days of the week
            var is_checked = false;
            $('#days_specification').change(function() {
                if ($(this).is(':checked')) {
                    $('#one_schedule').remove();
                    $('#foreach_schedule').css('display', 'block')
                    $('#foreach_schedule_tuesday').css('display', 'block')
                    $('#foreach_schedule_wednesday').css('display', 'block')
                    $('#foreach_schedule_thursday').css('display', 'block')
                    $('#foreach_schedule_friday').css('display', 'block')
                    $('#foreach_schedule_saturday').css('display', 'block')
                    $('#foreach_schedule_sunday').css('display', 'block')
                } else {
                    $('#foreach_schedule').css('display', 'none')
                    $('#foreach_schedule_tuesday').css('display', 'none')
                    $('#foreach_schedule_wednesday').css('display', 'none')
                    $('#foreach_schedule_thursday').css('display', 'none')
                    $('#foreach_schedule_friday').css('display', 'none')
                    $('#foreach_schedule_saturday').css('display', 'none')
                    $('#foreach_schedule_sunday').css('display', 'none')
                    $('#container').append(`
                    <div class="row" id="one_schedule">
                        <div class="col">
                            <div class="mb-3">
                                <label class="control-label col-form-label">Opening From <b
                                        style="color: #e86945">*</b></label>
                                <div class="input-group">
                                    <span class="input-group-text" id="basic-addon1">
                                        <i class="ti ti-clock-hour-4 fs-4"></i>
                                    </span>
                                    <input type="time" class="form-control"
                                        aria-describedby="basic-addon1" name="opening_from_all" id="opening_from_all">
                                </div>
                            </div>
                        </div>

                        <div class="col">
                            <div class="mb-3">
                                <label class="control-label col-form-label">Opening To <b
                                        style="color: #e86945">*</b></label>
                                <div class="input-group">
                                    <span class="input-group-text" id="basic-addon1">
                                        <i class="ti ti-clock-hour-4 fs-4"></i>
                                    </span>
                                    <input type="time" class="form-control"
                                        aria-describedby="basic-addon1" name="opening_to_all" id="opening_to_all">
                                </div>
                            </div>
                        </div>

                        <span id="opening_all_error"></span>

                    </div>`);
                }
            });

            //onsubmit button 
            $('#save').on('click', function(e) {
                e.preventDefault();
                $('#opening_all_error').empty();
                $('#session_minutes_error').empty();
                $('#session_price_error').empty();
                $('#title_error').empty();
                $('#capacity_error').empty();
                $('#sport_error').empty();

                var opening_from_all = $('#opening_from_all').val();
                var opening_to_all = $('#opening_to_all').val();
                var title = $('#title').val();

                if (!title) {
                    $('#title_error').append(
                        '<span class="text-danger err"><b>TITLE IS REQUIRED!</b></span>')
                }

                if (opening_from_all == '' || opening_to_all == '') {
                    $('#opening_all_error').append(
                        '<span class="text-danger err"><b>OPENING FROM, OPENING TO ARE REQUIRED!</b></span>'
                    )
                }

                if (opening_from_all == opening_to_all) {
                    $('#opening_all_error').append(
                        '<span class="text-danger err"><b>OPENING FROM, OPENING TO SHOULD NOT BE EQUAL!</b></span>'
                    )
                }

                // if (opening_from_all > opening_to_all) {
                //     $('#opening_all_error').append(
                //         '<span class="text-danger err"><b>OPENING TO SHOULD BE GREATER THAN OPENING FROM!</b></span>'
                //     )
                // }

                if ($('.err').length == 0) {
                    $(this).prop('disabled', true);
                    $('#add_court_form').submit()
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/courts/addcourt.blade.php ENDPATH**/ ?>