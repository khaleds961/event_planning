<head>
    <!--  Title -->
    <title>Sportciety Management System | <?php echo $__env->yieldContent('title'); ?></title>

    <!--  Required Meta Tag -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="handheldfriendly" content="true" />
    <meta name="MobileOptimized" content="width" />
    <meta name="description" content="Mordenize" />
    <meta name="author" content="" />
    <meta name="keywords" content="Mordenize" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="base-url" content="<?php echo e(url('/')); ?>">

    <!--  Favicon -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/favicon/icon.png')); ?>" />

    <!-- Owl Carousel  -->
    <link rel="stylesheet" href="<?php echo e(asset('dist/libs/owl.carousel/dist/assets/owl.carousel.min.css')); ?>">

    <!-- Core Css -->
    <link id="themeColors" rel="stylesheet" href="<?php echo e(asset('dist/css/style.css')); ?>" />

    
    <link rel="stylesheet" href="<?php echo e(asset('dist/libs/select2/dist/css/select2.min.css')); ?>">

    <!-- Prism Js -->
    <link rel="stylesheet" href="<?php echo e(asset('dist/libs/prismjs/themes/prism.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('dist/libs/bootstrap-switch/dist/css/bootstrap3/bootstrap-switch.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('dist/libs/dropify/css/dropify.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dist/libs/dropify/css/dropify.min.css')); ?>">
    
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.1.7/css/intlTelInput.css" rel="stylesheet">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
</head>
<?php /**PATH /home/sportcietyapp/public_html/beta/resources/views/layouts/head.blade.php ENDPATH**/ ?>