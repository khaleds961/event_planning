
<?php $__env->startSection('title', 'Add New Court'); ?>
<?php $__env->startSection('content'); ?>
<div id='calendar'></div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>

    
    <script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.js'></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');

            var calendar = new FullCalendar.Calendar(calendarEl, {
                header: {
                    left: '',
                    center: '',
                    right: ''
                },
                plugins: ['resourceDayGrid'],
                defaultView: 'resourceDayGrid',
                resourceLabelText: 'Courts',
                resources: [{
                        id: 'court1',
                        title: 'Court 1'
                    },
                    {
                        id: 'court2',
                        title: 'Court 2'
                    },
                    {
                        id: 'court3',
                        title: 'Court 3'
                    }
                ],
                events: [{
                        resourceId: 'court1',
                        title: 'Reservation 1',
                        start: '2023-06-08T09:00:00',
                        end: '2023-06-08T11:00:00'
                    },
                    {
                        resourceId: 'court2',
                        title: 'Reservation 2',
                        start: '2023-06-08T10:00:00',
                        end: '2023-06-08T12:00:00'
                    },
                    {
                        resourceId: 'court3',
                        title: 'Reservation 3',
                        start: '2023-06-08T11:00:00',
                        end: '2023-06-08T13:00:00'
                    },
                    // add more events for more reservations
                ]
            });

            calendar.render();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/schedule/index.blade.php ENDPATH**/ ?>