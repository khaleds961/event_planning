
<?php $__env->startSection('title', 'Clients'); ?>
<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <div class="d-md-flex justify-content-between">
            <ol class="breadcrumb border border-warning px-3 py-2 rounded">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                            class="ti ti-home fs-4 mt-1"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="#" class="text-warning">Clients</a>
                </li>
            </ol>

            
        </div>
    </nav>

    


    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="my-2">
                        <div class="table-responsive">
                            <table id="expenses_table"
                                class="table border table-striped table-bordered display text-nowrap">
                                <thead>
                                    <!-- start row -->
                                    <tr>

                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">fullname</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">phone</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">email</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">total reservations</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">last reservation</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">history</h6>
                                        </th>
                                    </tr>
                                    <!-- end row -->
                                </thead>
                                <tbody>
                                    <!-- start row -->
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                            </table>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#expenses_table').DataTable({
                processing: true,
                serverSide: true,
                scrollY: '470px',
                scrollCollapse: true,
                paging: true,
                responsive: true,
                ajax: "<?php echo e(route('clients.index')); ?>",
                columns: [{
                        data: 'full_name',
                        name: 'full_name',
                    },
                    {
                        data: 'phone',
                        name: 'phone'
                    },
                    {
                        data: 'email',
                        name: 'email',
                    },
                    {
                        data: 'total_reservations',
                        name: 'total_reservations',
                    },
                    {
                        data: 'last_reservation',
                        name: 'last_reservation',
                    },
                    {
                        data: 'history',
                        name: 'history',
                        className: 'text-center'
                    },
                ],
                order: [3, 'desc']
            });


            var store_expense = document.querySelector('#store_expense')
            store_expense.addEventListener('click', function(e) {
                var expenses_type = document.querySelector('#expenses_type').value;
                var expense_name = document.querySelector('#expense_name').value;
                var phone_number = document.querySelector('#phone_number').value;
                var email = document.querySelector('#email').value;
            })

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sportcietyapp/public_html/beta/resources/views/clients/index.blade.php ENDPATH**/ ?>