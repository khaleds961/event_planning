
<?php $__env->startSection('title', 'Expenses'); ?>
<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <div class="d-md-flex justify-content-between">
            <ol class="breadcrumb border border-warning px-3 py-2 rounded">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                            class="ti ti-home fs-4 mt-1"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('expenses_type.index')); ?>" class="text-warning d-flex align-items-center">
                        Expenses Types
                    </a>
                </li>
                <li class="breadcrumb-item">
                    <a href="#" class="text-warning">Expenses</a>
                </li>
            </ol>

            <div>
                <a type="button" class="btn mb-1 waves-effect waves-light btn-light text-dark fs-4 mx-2"
                    data-bs-toggle="modal" data-bs-target="#eventModal" id="modal_button">
                    <i class="ti ti-circle-plus"></i>
                    <span>Add New Expense</span>
                </a>
            </div>
        </div>
    </nav>

    <div class="d-md-flex justify-content-end">
        <!-- BEGIN MODAL -->
        <div class="modal fade" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="eventModalLabel">
                            Add Expense
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="row mx-2">
                        <div class="col-md-6">
                            <label for="expenses_type" class="form-label">Expense<b class="text-danger">*</b></label>
                            <select class="form-control my-1" name="expenses_type" id="expenses_type">
                                <option disabled="" value="0" selected="">--Select Expense--</option>
                                <?php $__currentLoopData = $expenses_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span id="expenses_type_error" class="errorContainer text-uppercase text-danger"></span>
                        </div>
                        <div class="col-md-6">
                            <label for="expense_name" class="form-label">Name<b class="text-danger">*</b></label>
                            <input type="text" class="form-control" id="expense_name" name="expense_name">
                            <span id="expense_name_error" class="errorContainer text-uppercase text-danger"></span>
                        </div>
                    </div>

                    <div class="row m-2">

                        <div class="col-md-6" id="type_form">
                            <label for="email" class="form-label">Email</label>
                            <input type="text" class="form-control" id="email">
                            <span id="email_error" class="errorContainer text-uppercase text-danger"></span>
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="phone_number">Phone Number
                                <b class="text-danger">*</b>
                            </label>
                            <div>
                                <input type="tel" class="form-control" name="phone_number" id="phone_number"
                                    placeholder="Phone Number" required>
                            </div>
                            <span id="phone_number_error" class="text-uppercase text-danger h6"></span>
                            <span id="phone_number_valid" class="text-uppercase text-success h6"></span>
                            <span id="phone_err" class="text-uppercase text-success h6"></span>
                        </div>

                    </div>

                    <div class="d-flex justify-content-end my-2">
                        <button type="submit" class="btn btn-success btn-add-event mx-2" id="store_expense">
                            <i class="ti ti-device-floppy fs-3"></i>
                            Save Expense
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit expenses -->
    <div class="d-md-flex justify-content-end">
        <!-- BEGIN MODAL -->
        <div class="modal fade" id="editeventModal" tabindex="-1" aria-labelledby="editeventModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editeventModalLabel">
                            Edit Expense
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="row mx-2">
                        <div class="col-md-6">
                            <label for="edit_expenses_type" class="form-label">Expense<b
                                    class="text-danger">*</b></label>
                            <select class="form-control my-1" name="edit_expenses_type" id="edit_expenses_type">
                                <option disabled="" value="0" selected="">--Select Expense--</option>
                                <?php $__currentLoopData = $expenses_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span id="edit_expenses_type_error"
                                class="edit_errorContainer text-uppercase text-danger"></span>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_expense_name" class="form-label">Name<b class="text-danger">*</b></label>
                            <input type="text" class="form-control" id="edit_expenses_name" name="edit_expense_name">
                            <span id="edit_expenses_name_error"
                                class="edit_errorContainer text-uppercase text-danger"></span>
                        </div>
                    </div>

                    <div class="row m-2">

                        <div class="col-md-6" id="type_form">
                            <label for="edit_email" class="form-label">Email</label>
                            <input type="text" class="form-control" id="edit_email">
                            <span id="edit_email_error" class="edit_errorContainer text-uppercase text-danger"></span>
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="edit_phone_number">Phone Number
                                <b class="text-danger">*</b>
                            </label>
                            <div>
                                <input type="tel" class="form-control" name="edit_phone_number"
                                    id="edit_phone_number" placeholder="Phone Number" required>
                            </div>
                            <span id="edit_phone_number_error" class="text-uppercase text-danger h6"></span>
                            <span id="edit_phone_number_valid" class="text-uppercase text-success h6"></span>
                            <span id="edit_phone_err" class="text-uppercase text-success h6"></span>
                        </div>

                    </div>

                    <div class="d-flex justify-content-end my-2">
                        <button type="submit" class="btn btn-success btn-add-event mx-2" id="edit_store_expense">
                            <i class="ti ti-device-floppy fs-3"></i>
                            Update Expense
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="my-2">

                        <div class="table-responsive">
                            <table id="expenses_table"
                                class="table border table-striped table-bordered display text-nowrap">
                                <thead>
                                    <!-- start row -->
                                    <tr>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">#id</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">name</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">expense type</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">email</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">phone</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">amount</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">payment</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">is active</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">action</h6>
                                        </th>
                                    </tr>
                                    <!-- end row -->
                                </thead>
                                <tbody>
                                    <!-- start row -->
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                            </table>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            // Initialize the intlTelInput plugin on the phone number input field
            var phone_valid_error = false;
            var input = $("#phone_number");
            var phone_error = $('#phone_number_error');
            var phone_valid = $('#phone_number_valid');

            input.intlTelInput({
                preferredCountries: ["lb"],
                separateDialCode: true,
                utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.1.7/js/utils.js"
            });

            // Add a keyup event listener to validate the phone number
            input.on("keyup change", function() {
                $('#phone_err').empty();
                var isValid = input.intlTelInput("isValidNumber");
                var hasNonDigits = /[^\d]/.test(input.val());
                if (isValid && !hasNonDigits) {
                    phone_valid.html('Valid <i class="ti ti-check"></i>'); // the phone number is valid
                    phone_error.html('').removeClass('err');
                    valid_number = input.intlTelInput("getNumber");
                    country_code = input.intlTelInput("getSelectedCountryData").dialCode;
                    phone_valid_error = false;
                } else {
                    phone_valid_error = true;
                    phone_error.html('Not Valid X').addClass('err');
                    phone_valid.html('')
                }
            });

            ////////////////////////////////

            var table = $('#expenses_table').DataTable({
                processing: true,
                serverSide: true,
                responsive: true,
                ajax: "<?php echo e(route('expenses.index')); ?>",
                columns: [{
                        data: 'id',
                        id: 'id'
                    },
                    {
                        data: 'name',
                        name: 'name',
                    },
                    {
                        data: 'type_name',
                        name: 'type_name',
                    },
                    {
                        data: 'email',
                        name: 'email',
                    },
                    {
                        data: 'phone_number',
                        name: 'phone_number',
                    },
                    {
                        data: 'amount',
                        name: 'amount',
                        className: 'text-success'
                    },
                    {
                        data: 'payment',
                        name: 'payment',
                        className: 'text-danger'
                    },
                    {
                        data: 'is_active',
                        name: 'is_active'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    }
                ],
                order: [0, 'desc'],
            });

            var modal_buton = document.querySelector('#modal_button');
            modal_buton.addEventListener('click', function(e) {

                e.preventDefault()
                var errorContainers = document.querySelectorAll('.errorContainer');
                errorContainers.forEach(function(errorContainer) {
                    errorContainer.innerHTML = ''; // Clear previous error messages
                });

                var inputFields = document.querySelectorAll('input');
                inputFields.forEach(function(inputField) {
                    inputField.value = ''; // Clear input values
                });

                $('#edit_phone_number_error').text('')
                $('#edit_phone_number_valid').text('')
                $('#edit_phone_err').text('')

            })

            var store_expense = document.querySelector('#store_expense');
            store_expense.addEventListener('click', function(e) {
                e.preventDefault(); // Prevent form submission

                var expenses_type = parseInt(document.querySelector('#expenses_type').value);
                var expense_name = document.querySelector('#expense_name').value;
                var phone_number = document.querySelector('#phone_number').value;
                var email = document.querySelector('#email').value;
                var hasError = false;

                var errorContainers = document.querySelectorAll('.errorContainer');
                errorContainers.forEach(function(errorContainer) {
                    errorContainer.innerHTML = ''; // Clear previous error messages
                });

                if (!phone_number) {
                    phone_error.html('Not Valid X').addClass('err');
                    phone_valid.html('')
                    hasError = true
                }

                if (!expenses_type || expenses_type <= 0 || isNaN(expenses_type)) {
                    // Handle invalid expenses_type input
                    displayError('expenses_type',
                        'Invalid expense. Please enter a valid option.');
                    hasError = true;
                }

                if (!expense_name || expense_name.length < 3) {
                    // Handle invalid expense_name input
                    displayError('expense_name',
                        'Invalid name. Please enter a name with at least 3 characters.');
                    hasError = true;
                }

                if (email && !validateEmail(email)) {
                    // Handle invalid email input
                    displayError('email',
                        'Invalid email. Please enter a valid email address or leave it blank.');
                    hasError = true;
                }

                if (hasError || phone_valid_error) {
                    // Validation failed, do not proceed with AJAX call
                    return;
                }
                // All validations passed, proceed with making the AJAX call
                $.ajax({
                    url: "<?php echo e(route('expenses.store')); ?>",
                    data: {
                        expenses_type: expenses_type,
                        expense_name: expense_name,
                        email: email,
                        country_code: country_code,
                        phone_number: phone_number
                    },
                    method: 'POST',
                    success: function(response) {
                        console.log(response);
                        if (response.success) {
                            swal({
                                title: 'EXPENSE ADDED',
                                icon: 'success'
                            }).then(() => {
                                location.reload();
                            })
                        }
                    },
                    error: function(error) {
                        console.error(error);
                    }
                });

            });

            // Function to display error messages
            function displayError(fieldId, errorMessage) {
                var errorField = document.querySelector('#' + fieldId + '_error');
                errorField.innerHTML = errorMessage;
            }

            // Function to validate email format
            function validateEmail(email) {
                // Regular expression pattern for email validation
                var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return emailPattern.test(email);
            }

            var edit_id;
            $(document).on('click', '.edit_expenses', function(e) {
                edit_id = $(this).data('id');
                var initial_name = $(this).data('name');
                console.log({
                    initial_name
                });
                var initial_type = $(this).data('type');
                var initial_email = $(this).data('email');
                var countryCode = $(this).data('country-code');
                var phoneNumber = $(this).data('phone-number');

                // Remove spaces from the combined country code and phone number
                var sanitizedPhoneNumber = (countryCode + phoneNumber).replace(/\s/g, '');

                // Extract the country code from the sanitized phone number
                var extractedCountryCode = '+' + sanitizedPhoneNumber.substring(0, 3);
                // Destroy the previous instance of intlTelInput if it exists
                if (edit_input.data("plugin_intlTelInput")) {
                    edit_input.intlTelInput("destroy");
                }
                $('#edit_expenses_type').val(initial_type);
                $('#edit_expenses_name').val(initial_name);
                $('#edit_email').val(initial_email);
                $('#edit_phone_number').val(sanitizedPhoneNumber)
                // Set the initial country value based on the retrieved country code
                edit_input.intlTelInput({
                    separateDialCode: true,
                    utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.1.7/js/utils.js"
                });
                //remove errors 
                var errorContainers = document.querySelectorAll('.edit_errorContainer');
                errorContainers.forEach(function(errorContainer) {
                    errorContainer.innerHTML = ''; // Clear previous error messages
                });

                $('#edit_phone_number_error').text('')
                $('#edit_phone_number_valid').text('')
                $('#edit_phone_err').text('')
            })

            //edit expenses
            // Initialize the intlTelInput plugin on the phone number input field
            var edit_phone_valid_error = false;
            var edit_input = $("#edit_phone_number");
            var edit_phone_error = $('#edit_phone_number_error');
            var edit_phone_valid = $('#edit_phone_number_valid');
            var edit_country_code;

            edit_input.intlTelInput({
                preferredCountries: ["lb"],
                separateDialCode: true,
                utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.1.7/js/utils.js"
            });

            // Add a keyup event listener to validate the phone number
            edit_input.on("keyup change", function() {
                validate_number()
            });

            function validate_number() {
                $('#edit_phone_err').empty();
                var isValid = edit_input.intlTelInput("isValidNumber");
                var hasNonDigits = /[^\d]/.test(edit_input.val());
                if (isValid && !hasNonDigits) {
                    edit_phone_valid.html('Valid <i class="ti ti-check"></i>'); // the phone number is valid
                    edit_phone_error.html('').removeClass('err');
                    edit_valid_number = edit_input.intlTelInput("getNumber");
                    edit_country_code = edit_input.intlTelInput("getSelectedCountryData").dialCode;
                    edit_phone_valid_error = false;
                } else {
                    edit_phone_valid_error = true;
                    edit_phone_error.html('Not Valid X').addClass('err');
                    edit_phone_valid.html('')
                }
            }


            $(document).on('click', '#edit_store_expense', function(e) {
                validate_number()
                var type = $('#edit_expenses_type').val();
                var name = $('#edit_expenses_name').val();
                var email = $('#edit_email').val();
                var phone = $('#edit_phone_number').val()
                var hasError = false;

                var errorContainers = document.querySelectorAll('.edit_errorContainer');
                errorContainers.forEach(function(errorContainer) {
                    errorContainer.innerHTML = ''; // Clear previous error messages
                });

                if (!type || type <= 0 || isNaN(type)) {
                    // Handle invalid expenses_type input
                    displayError('edit_expenses_type',
                        'Invalid expense. Please enter a valid option.');
                    hasError = true;
                }

                if (!name || name.length < 3) {
                    // Handle invalid expense_name input
                    displayError('edit_expenses_name',
                        'Invalid expense name. Please enter a name with at least 3 characters.');
                    hasError = true;
                }

                if (email && !validateEmail(email)) {
                    // Handle invalid email input
                    displayError('edit_email',
                        'Invalid email. Please enter a valid email address or leave it blank.');
                    hasError = true;
                }

                if (hasError || phone_valid_error) {
                    // Validation failed, do not proceed with AJAX call
                    return;
                }
                console.log(edit_id);
                $.ajax({
                    url: "<?php echo e(route('expenses.update')); ?>",
                    data: {
                        id: edit_id,
                        type: type,
                        name: name,
                        email: email,
                        country_code: edit_country_code,
                        phone: phone
                    },
                    type: 'POST',
                    success: function(response) {
                        console.log(response);
                        if (response.success) {
                            swal({
                                title: 'EXPENSE UPDATED',
                                icon: 'success'
                            }).then(() => {
                                location.reload();
                            })
                        }
                    }
                })
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/expenses/index.blade.php ENDPATH**/ ?>