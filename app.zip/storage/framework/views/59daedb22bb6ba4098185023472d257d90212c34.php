
<?php $__env->startSection('title', 'Calendar'); ?>
<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <ol class="breadcrumb border border-warning px-3 py-2 rounded">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                        class="ti ti-home fs-4 mt-1"></i></a>
            </li>
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('courts.index')); ?>" class="text-warning">Courts</a>
            </li>

            <li class="breadcrumb-item">
                <a class="text-warning">Calendar</a>
            </li>
        </ol>

        <div class="row my-3">
            <div class="d-md-flex">
                <div class="col-md-3">
                    <select class="form-control my-1" name="select_court_id" id="select_court_id">
                        <option disabled value="0" selected>--Select Court--</option>
                        <?php $__currentLoopData = $courts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $court): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($court->id); ?>" <?php echo e($court_id == $court->id ? 'selected' : ''); ?>>
                                <?php echo e($court->title_en); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span id="court_id_error"></span>
                </div>

                <div class="mx-md-3 col-md-3">
                    <button class="btn btn-danger my-1" data-bs-toggle="modal" data-bs-target="#notificationModal"
                        id="closing_button">Closing Alert</button>
                </div>


            </div>
        </div>
    </nav>

    <!-- Closing MODAL -->
    <div class="modal fade" id="notificationModal" tabindex="-1" aria-labelledby="notificationModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="notificationModalLabel">
                        Closing Alert
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="row">
                        <div class="col">
                            <div class="">
                                <label class="form-label">Date
                                    <b class="text-danger">*</b>
                                </label>
                                <input id="closing_date" type="date" class="form-control" required />
                                <span id="closing_date_error"></span>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col">
                            <label class="form-label">Closing Reason
                                <b class="text-danger">*</b>
                            </label>
                            <input placeholder="Enter Text" class="form-control" name="closing_reason" id="closing_reason"
                                required>
                            <span id="reason_error"></span>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="send_notification">
                        <i class="ti ti-bell-ringing-filled mx-2"></i>
                        Send Notification
                    </button>
                </div>
            </div>
        </div>
    </div>
    <!-- CLOSING MODAL -->

    <div class="card">
        <div>
            <div class="row gx-0">
                <div class="col-lg-12">
                    <div class="p-4 calender-sidebar app-calendar">
                        <div id="calendar" data-route="<?php echo e(route('events.index')); ?>"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- BEGIN MODAL -->
    <div class="modal fade" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="eventModalLabel">
                        Add / Edit Booking
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-12">
                            <div class="d-flex" style="border: 2px solid orange; border-radius: 5px; padding: 5px;">
                                <input type="text" id="search-input" placeholder="Search player by name"
                                    class="form-control" style="border: none; flex: 1;">
                                <select id="user-select" class="form-control" style="border: none; flex: 1;"></select>
                            </div>
                            <span id="player_error"></span>
                        </div>

                        <div id="new_member">

                            <button type="btn" class="btn btn-primary mt-3" style="display: none"
                                id="new_member_button">
                                <span>Add New Member</span>
                                <i class="ti ti-circle-plus"></i>
                            </button>

                            <div class="p-4 border rounded mt-4" id="new_member_content" style="display: none">
                                <div class="row">
                                    <div class="col-md-6 mt-3">
                                        <label for="full_name">Full Name
                                            <b class="text-danger">*</b>
                                        </label>
                                        <input type="text" class="form-control" id="full_name" name="full_name">
                                        <span class="text-danger text-uppercase" id="full_name_error"></span>
                                    </div>

                                    <div class="col-md-6 mt-3">
                                        <label for="birth_date">Birth Date
                                            <b class="text-danger">*</b>
                                        </label>
                                        <input type="date" class="form-control" id="birth_date" name="birth_date">
                                        <span class="text-danger text-uppercase" id="birth_date_error"></span>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mt-3">
                                        <label for="email">Email
                                            <b class="text-danger">*</b>
                                        </label>
                                        <input type="text" class="form-control" id="email" name="email">
                                        <span class="text-danger text-uppercase" id="email_error"></span>
                                    </div>

                                    <div class="col-md-6 mt-3">
                                        <label for="phone_number">Phone Number
                                            <b class="text-danger">*</b>
                                        </label>
                                        <div>
                                            <input type="tel" class="form-control" name="phone_number"
                                                id="phone_number" placeholder="Phone Number" required>
                                        </div>
                                        <span id="phone_number_error" class="text-uppercase text-danger h6"></span>
                                        <span id="phone_number_valid" class="text-uppercase text-success h6"></span>
                                        <span id="phone_err" class="text-uppercase text-success h6"></span>
                                    </div>


                                </div>


                                <div>
                                    <button type="btn" class="btn btn-success mt-3" id="save_member">
                                        <span>Save</span>
                                        <i class="ti ti-device-floppy"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-6">
                            <div class="">
                                <label class="form-label">Date</label>
                                <input id="event-date" type="text" class="form-control" readonly disabled />
                                <span id="date_error"></span>
                            </div>
                        </div>

                        <input type="hidden" id="booking_id">
                        <div class="col-md-6">
                            <label class="control-label form-label">From</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1">
                                    <i class="ti ti-clock-hour-4 fs-4"></i>
                                </span>
                                <input type="time" class="form-control" aria-describedby="basic-addon1"
                                    id="event_start">
                            </div>
                        </div>

                        <div class="col-md-4 mt-4">
                            <label for="sport_type" class="form-label">Sport Type</label>
                            <select class="form-control my-1" name="sport_id" id="select_sport_id">
                                <option disabled value="0" selected>--Select Sport--</option>
                                <?php $__currentLoopData = $court_sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sport->id); ?>"><?php echo e($sport->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span id="sport_error"></span>
                        </div>

                        <div class="col-md-4 mt-4">
                            <label for="demo6" class="form-label">Session Minutes</label>
                            <input id="demo6" type="text" name="demo6" class="session_minutes" />
                            <span id="session_minutes_error"></span>
                            <span id="session_minutes_empty"></span>
                        </div>

                        <div class="col-md-4 mt-4" id="price_input">
                            <label class="form-label d-flex justify-content-between align-items-center">
                                <span>Price
                                    <i class="ti ti-currency-dollar"></i>
                                </span>
                                <span id="editable_price">
                                    <i class="ti ti-pencil" style="cursor: pointer" data-bs-toggle="tooltip"
                                        title="Make Price Editable"></i>
                                </span>
                            </label>
                            <input id="court-price" type="number" class="form-control" readonly />
                            <span id="price_error"></span>
                        </div>


                        <input type="hidden" id="sport_time_url" data-sport-time="<?php echo e(route('calendar.session_time')); ?>">
                        <input type="hidden" id="get_booking_items"
                            data-url="<?php echo e(route('reservation_items.get_booking_items')); ?>">
                        <input type="hidden" id="search_url" data-url="<?php echo e(route('courtitems.search_by_court')); ?>"
                            data-link="<?php echo e(url('')); ?>">

                        <input type="hidden" data-url="<?php echo e(route('calendar.check_time')); ?>" id="check_time">
                        <input type="hidden" data-court-id="<?php echo e($court_id); ?>" id="court_id">

                        <div class="row mt-4">
                            <div class="col-md-6">
                                <div class="d-flex align-items-center">
                                    <span class="text-dark fw-bolder text-capitalize me-3">Public</span>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input" role="switch" type="checkbox" id="private"
                                            name="private_sport">
                                    </div>
                                    <span class="text-dark fw-bolder text-capitalize ms-2">Private</span>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="d-flex align-items-center justify-content-end">
                                    <span class="text-dark fw-bolder text-capitalize me-3">Not Paid</span>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input" role="switch" type="checkbox"
                                            id="ispaid_reservation" name="ispaid_reservation">
                                    </div>
                                    <span class="text-dark fw-bolder text-capitalize ms-2">Paid</span>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-6" id="status">
                                <label class="form-label">Status</label>
                                <select class="form-control my-1" name="status_id" id="status_id">
                                    <option disabled value="0">Pending</option>
                                    <option value="1">Confirm</option>
                                    <option value="2">Reject</option>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Notes</label>
                                <textarea placeholder="Enter Text" class="form-control rounded h-70" name="description"></textarea>
                            </div>
                        </div>

                        <div class="col mt-4">
                            <span>Add Item(s)
                                <i class="ti ti-shopping-cart mx-2"></i>
                            </span>
                            <div class="search-container">
                                <input type="text" placeholder="Search..." class="form-control" id="search_input">
                                <div class="search-results" id="search-results"></div>
                            </div>
                            <div id="items_labels" class="row my-2">
                                <div class='col-3 text-primary text-uppercase'>name</div>
                                <div class='col-3 text-primary text-uppercase'>price</div>
                                <div class='col-3 text-primary text-uppercase'>quantity</div>
                            </div>
                            <div class="mt-3 d-none" id="plus_court_items">
                            </div>
                        </div>

                        <div class="row">
                            <div class="order-summary border rounded my-4 mx-2">
                                <div class="p-3">
                                    <h5 class="fs-5 fw-semibold mb-4">Reservation Summary</h5>
                                    <div class="d-flex justify-content-between mb-4">
                                        <p class="mb-0 fs-4">Court</p>
                                        <h6 class="mb-0 fs-4 fw-semibold">
                                            <span id="court_reservation_price"></span>
                                        </h6>
                                    </div>
                                    <div class="d-flex justify-content-between mb-4">
                                        <p class="mb-0 fs-4">Items</p>
                                        <h6 class="mb-0 fs-4 fw-semibold text-danger">
                                            <span id="items_total_price"></span>
                                        </h6>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <h6 class="mb-0 fs-4 fw-semibold">Total</h6>
                                        <h6 class="mb-0 fs-5 fw-semibold">
                                            <span id="grand_total" class="text-success"></span>
                                        </h6>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-12 d-none">
                            <div class="">
                                <label class="form-label">Enter Start Date</label>
                                <input id="event-start-date" type="text" class="form-control" />
                            </div>
                        </div>

                        <div class="col-md-12 d-none">
                            <div class="">
                                <label class="form-label">Enter End Date</label>
                                <input id="event-end-date" type="text" class="form-control" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-bs-dismiss="modal">
                        Close
                    </button>
                    <button type="button" class="btn btn-success btn-update-event" data-fc-event-public-id="">
                        Update Booking
                    </button>
                    <button type="button" class="btn btn-danger btn-recurring-event" data-fc-recurring-public-id="">
                        Recurring
                    </button>
                    <input type="hidden" data-update-booking="<?php echo e(route('calendar.updatebooking')); ?>"
                        id="update_booking">
                    <button type="button" class="btn btn-success btn-add-event"
                        data-url="<?php echo e(route('calendar.storebooking')); ?>" id="book_event"
                        data-reservation-items-url="<?php echo e(route('reservation_items.store')); ?>">
                        Add Booking
                    </button>
                </div>
            </div>
        </div>
    </div>
    <!-- END MODAL -->

    
    <div class="modal fade" id="opening_hours" tabindex="-1" aria-labelledby="opening_hoursLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="opening_hoursLabel">
                        OPENING HOURS ON : <span id="day_name" class="text-danger fs-5 mx-2"></span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">

                        <div id="op_hours"></div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-bs-dismiss="modal">
                        Close
                    </button>
                </div>
            </div>
        </div>
    </div>
    


    
    <div class="modal fade" id="recurringModal" tabindex="-1" aria-labelledby="recurringModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="recurringModalLabel">
                        <span>Recurring</span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="col-md-12" id="recurring_content">
                        <div>
                            <label for="recurring_day" class="form-label">Every</label>
                            <select class="form-control my-1" name="recurring_day" id="recurring_day">
                                <option disabled value="0" selected>--Select Day--</option>
                                <option value="1">Monday</option>
                                <option value="2">Tuesday</option>
                                <option value="3">Wednesday</option>
                                <option value="4">Thursday</option>
                                <option value="5">Friday</option>
                                <option value="6">Saturday</option>
                                <option value="7">Sunday</option>
                            </select>
                            <span id="recurring_day_error"></span>
                            <span id="player_reccuring_error"></span>
                        </div>

                        <div>
                            <label class="control-label col-form-label">From</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1">
                                    <i class="ti ti-clock-hour-4 fs-4"></i>
                                </span>
                                <input type="time" class="form-control" aria-describedby="basic-addon1"
                                    value="0" id="recurring_start_time">
                            </div>
                            <span id="recurring_start_error"></span>
                        </div>

                        <div class="col-md-12 mt-4">
                            <label for="recurring_duration" class="form-label">Session Minutes</label>
                            <input id="recurring_duration" type="text" name="recurring_duration"
                                class="session_minutes" />
                            <span id="recurring_duration_error"></span>
                            <span id="recurring_duration_empty"></span>
                        </div>

                        <div>
                            <label class="control-label col-form-label">Start Date</label>
                            <input type="date" class="form-control" id="recurring_start_date">
                            <span id="recurring_start_date_error"></span>
                        </div>

                        <div>
                            <label class="control-label col-form-label">End Date</label>
                            <input type="date" class="form-control" id="recurring_end_date">
                            <span id="recurring_end_date_error"></span>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-bs-dismiss="modal">
                        Close
                    </button>
                    <button type="button" class="btn btn-success btn-add-event"
                        data-url="<?php echo e(route('calendar.storerecurring')); ?>" id="storerecurring">
                        Save
                    </button>
                </div>
            </div>
        </div>
    </div>
    


    
    <div class="modal fade" id="booked_days" tabindex="-1" aria-labelledby="booked_daysLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="booked_daysLabel">
                        Booked/Unbooked Dates: <span id="day_name" class="text-danger fs-5 mx-2"></span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div id="available_days"></div>
                        <div id="not_booked_days"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-bs-dismiss="modal">
                        Close
                    </button>
                </div>
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>

        var valid_number;
        var country_code;
        // Get the current year
        const currentYear = new Date().getFullYear();

        // Set the max and min years
        const maxYear = currentYear - 6;
        const minYear = currentYear - 80;

        const date_min = moment().set({
            year: minYear,
            month: 11, // Note that month values are zero-based
            date: 31,
        });

        const date_max = moment().set({
            year: maxYear,
            month: 11, // Note that month values are zero-based
            date: 31,
        });

        $('#birth_date').attr('min', date_min.format('YYYY-MM-DD'));
        $('#birth_date').attr('max', date_max.format('YYYY-MM-DD'));


        var valid_number;
        var country_code;
        $(document).ready(function() {

            $('#closing_date').val(moment().format('YYYY-MM-DD'))
            $('#closing_date').attr('min', moment().format('YYYY-MM-DD'))

            // Initialize the intlTelInput plugin on the phone number input field
            var input = $("#phone_number");
            var phone_error = $('#phone_number_error');
            var phone_valid = $('#phone_number_valid');

            input.intlTelInput({
                preferredCountries: ["lb"],
                separateDialCode: true,
                utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.1.7/js/utils.js"
            });

            // Add a keyup event listener to validate the phone number
            input.on("keyup change", function() {
                $('#phone_err').empty();
                // var isValid = input.intlTelInput("isValidNumber");
                var hasNonDigits = /[^\d]/.test(input.val());
                // if (isValid && !hasNonDigits) {
                    if (!hasNonDigits) {
                    // phone_valid.html('Valid <i class="ti ti-check"></i>'); 
                    // the phone number is valid
                    phone_error.html('').removeClass('err');
                    valid_number = input.intlTelInput("getNumber");
                    country_code = input.intlTelInput("getSelectedCountryData").dialCode;
                } else {
                    phone_error.html('Not Valid X').addClass('err');
                    phone_valid.html('')
                }
            });
        });

        $(document).on('change', '#select_court_id', function(e) {
            var court_id = $('#select_court_id').val();
            window.location.href = "<?php echo e(route('calendar.index', ['id' => ':court_id'])); ?>".replace(':court_id',
                court_id);
        });

        $('#search-input').on('input', function() {
            var query = $(this).val();
            if (query.length >= 2) {
                $.ajax({
                    url: "<?php echo e(route('players.search')); ?>",
                    data: {
                        query: query
                    },
                    success: function(data) {
                        if (data.success) {
                            $('#new_member_button').css('display', 'none');
                            $('#new_member_content').css('display', 'none');
                            $('#user-select').empty();
                            $.each(data.data, function(key, user) {
                                $('#user-select').append($('<option>', {
                                    value: user.id,
                                    text: user.full_name
                                }));
                            });
                        } else {
                            $('#user-select').empty();
                            $('#user-select').append($('<option>', {
                                value: 0,
                                text: 'no member match'
                            }));
                            $('#new_member_button').css('display', 'block');
                        }
                    }
                });
            }
        });

        $(document).on('click', '#new_member_button', function(e) {
            $('#new_member_content').css('display', 'block');
            $('#phone_number_valid').empty()
            $('#full_name').val('')
            $('#birth_date').val('')
            $('#email').val('')
            $('#phone_number').val('')
        });

        const full_name = document.querySelector('#full_name');
        const full_nameValidation = document.querySelector('#full_name_error');

        full_name.addEventListener('keyup', function() {
            fullnamecheck()
        });

        function fullnamecheck() {
            const full_nameValue = full_name.value.trim();
            if (full_nameValue.length > 30) {
                full_nameValidation.textContent = 'full name must not be longer than 30 characters';
                full_nameValidation.classList.add('err');
            } else if (full_nameValue.length < 3) {
                full_nameValidation.textContent = 'full name must be 3 characters or more';
                full_nameValidation.classList.add('err');
            } else {
                full_nameValidation.textContent = '';
                full_nameValidation.classList.remove('err');
            }
        }

        //CLOSING BUTTON
        $(document).on('click', '#closing_button', function(e) {
            $('#reason_error').empty();
            $('#closing_reason').val('');
        })

        const dateInput = $('#birth_date').val(); // Replace with the date input value
        // const isValid = validateDateInput(dateInput);

        // Create a function to validate the date input
        function validateDateInput(dateInput) {
            // Convert the date input to a Date object
            const date = new Date(dateInput);

            // Check if the year is within the allowed range
            const year = date.getFullYear();
            if (year > maxYear || year < minYear) {
                return false;
            }

            // Check if the date is valid
            if (isNaN(date.getTime())) {
                return false;
            }

            // If all checks pass, return true
            return true;
        }

        function isValidEmail(email) {
            // Regular expression pattern for matching email addresses
            const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            // Use the test() method of the pattern to check if the email address matches
            return pattern.test(email);
        }

        var saveButton = document.getElementById("save_member");

        function storeplayer(full_name, email, phone_number, phone_code, birth_date) {
            $.ajax({
                url: "<?php echo e(route('players.store')); ?>",
                data: {
                    full_name: full_name,
                    email: email,
                    phone_number: phone_number,
                    phone_code: phone_code,
                    birth_date: birth_date
                },
                type: 'POST',
                success: function(data) {
                    if (data.success) {
                        console.log('kdkdkdkdk');
                        // Get the ID of the newly created member from the response data
                        const newMemberId = data.player.id;

                        console.log(newMemberId);
                        // Create a new option element with the member's name and ID
                        const newOption = $('<option>', {
                            value: newMemberId,
                            text: full_name
                        });

                        // Append the new option to the select element
                        $('#user-select').append(newOption);

                        // Select the new option in the dropdown list
                        newOption.prop('selected', true);

                        swal({
                            title: "NEW PLAYER ADDED SUCCESSFULLY",
                            icon: "success"
                        });
                        $('#new_member_button').css('display', 'none')
                        $('#new_member_content').css('display', 'none');
                        $('#phone_number_valid').empty()
                        $('#full_name').val('')
                        $('#birth_date').val('')
                        $('#email').val('')
                        $('#phone_number').val('')
                        $('#search-input').val('')
                        saveButton.disabled = false;
                    }
                }
            })
        }

        //add new member
        var save_member = document.querySelector('#save_member');
        $(document).on('click', '#save_member', function(e) {

            $('#birth_date_error').empty();
            $('#email_error').empty();
            $('#phone_err').empty();

            var dateInput = $('#birth_date').val();
            var full_name = $('#full_name').val();
            var birth_date = $('#birth_date').val();
            var email = $('#email').val();
            var country_c = country_code
            var phone_number = $('#phone_number').val().replace(/\s/g, "");
            const isValid = validateDateInput(dateInput);
            const isEmailValid = isValidEmail(email);

            if (phone_number == '' || phone_number == 0 || phone_number == null) {
                $('#phone_err').append('<span class="err text-danger text-uppercase">required !!</span>');
            } else {
                $('#phone_err').empty();
            }
            fullnamecheck()

            if (isEmailValid) {
                $('#email_error').empty();
            } else {
                $('#email_error').append(
                    `<span class="err">email is invalid</span>`
                );
            }

            if (isValid) {
                $('#birth_date_error').empty();
            } else {
                $('#birth_date_error').append(
                    `<span class="err">date should not be less than ${minYear} and not more than ${maxYear}</span>`
                );
            }

            if ($('.err').length == 0) {
                saveButton.disabled = true;
                $.ajax({
                    url: "<?php echo e(route('players.check_email')); ?>",
                    data: {
                        email: email,
                        phone: phone_number
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            storeplayer(full_name, email, phone_number, country_c, birth_date)
                        } else {
                            swal({
                                title: 'EMAIL OR PHONE NUMBER IS REPEATED !',
                                icon: 'warning'
                            })
                            saveButton.disabled = false;
                        }
                    }

                })
            }
        });

        //reservations players
        $(document).on('click', '#send_notification', function(e) {
            $('#closing_date_error').empty()
            $('#reason_error').empty()

            var date = $('#closing_date').val()
            var reason = $('#closing_reason').val()
            var court_id = $('#select_court_id').val()

            const modal = document.getElementById('notificationModal');
            const modalInstance = bootstrap.Modal.getInstance(modal);

            var min_date = moment().format('YYYY-MM-dd');

            if (min_date < date || !(date)) {
                $('#closing_date_error').append('<span class="text-uppercase text-danger err">wrong date !</span>')
            } else {
                $('#closing_date_error').empty()
            }

            if (!court_id || court_id == 0) {
                $('#court_id_error').append('<span class="text-uppercase text-danger err">error !</span>')
            } else {
                $('#court_id_error').empty()
            }

            if (!reason) {
                $('#reason_error').append(
                    '<span class="text-uppercase text-danger err">reason is required !</span>')
            } else {
                $('#reason_error').empty()
            }

            if ($('.err').length == 0) {
                $.ajax({
                    url: "<?php echo e(route('booking.reservations_players')); ?>",
                    data: {
                        court_id: court_id,
                        date: date,
                        reason: reason
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            swal({
                                title: 'Notification sent successfully!',
                                icon: 'success'
                            }).then((result) => {
                                if (result) { // If user clicks "OK"
                                    $('#myModal').modal('hide'); // Close the modal
                                    location.reload(); // Reload the page
                                }
                            });
                            $('#closing_reason').val('')
                            modalInstance.hide();
                        }
                    }
                })
            }
        })

        // var selectedItems = [];
        // var total_items_price = 0;
        // var grand_total = 0;
        // var court_price;


        // $('.search-container input').on('input', function() {
        //     console.log(selectedItems);
        //     var query = $(this).val().trim();

        //     const url = window.location.href;
        //     // Match the ID in the URL using a regular expression
        //     const match = url.match(/id=(\d+)/);
        //     var id = match[1]

        //     if (query.length > 0) {
        //         $.ajax({
        //             url: "<?php echo e(route('courtitems.search_by_court')); ?>",
        //             data: {
        //                 name: query,
        //                 id: id
        //             },
        //             type: "POST",
        //             success: function(data) {
        //                 var results = $('.search-results');
        //                 results.empty();
        //                 if (data.data.length > 0) {
        //                     for (var i = 0; i < data.data.length; i++) {
        //                         var item = data.data[i];
        //                         var li = $('<li style="list-style: none;" class="my-2">');
        //                         var text_image = item.img == null ?
        //                             'images/courts/no-image.png' : item
        //                             .img;
        //                         var img = $('<img width="50" height="50">').attr('src',
        //                             "<?php echo e(url('')); ?>" + "/" + text_image);
        //                         var title = $('<span class="item_name mx-3">').text(item
        //                             .name);
        //                         var price = $('<span class="mx-3 item_price">').text(item.price)
        //                         var item_id = item.item_id;

        //                         // Use a closure to capture the correct value of item_id
        //                         (function(item_id) {
        //                             li.on('click', function() {
        //                                 if (selectedItems.includes(item_id)) {
        //                                     li.addClass('disabled');
        //                                     $('#search_input').val('')
        //                                     results.hide()
        //                                     return
        //                                 } else {
        //                                     $('#search_input').val('')
        //                                     var title = $(this).find('.item_name')
        //                                         .text();
        //                                     var price_i = $(this).find('.item_price')
        //                                         .text();
        //                                     $('#plus_court_items').removeClass(
        //                                         'd-none')
        //                                     $('#plus_court_items').append(`
    //                             <div class="row mb-2 px-1 item">
    //                                 <div class="col-3">
    //                                     ${title}
    //                                     </div>
    //                                 <div class="col-3">
    //                                     <span class="price_item">${price_i}</span>
    //                                     <input class="id" type="hidden" value="${item_id}"/>
    //                                 </div>
    //                                 <div class="col-3">
    //                                     <input value="1" type="number" class="qty_hour"/>
    //                                 </div>
    //                                 <div class="col-3">
    //                                     <i class="ti ti-trash fs-3 text-danger cursor-pointer"></i>
    //                                 </div>
    //                             </div>
    //                         `)
        //                                     // Add the item to the selectedItems array and disable the li element
        //                                     selectedItems.push(item_id);
        //                                     $(this).addClass('disabled');
        //                                     results.hide();
        //                                     total_items_price += parseFloat(price_i);
        //                                     $('#items_total_price').text(total_items_price)
        //                                     if ($('#court_reservation_price').text()) {
        //                                         court_price = $('#court_reservation_price')
        //                                             .text();
        //                                     } else {
        //                                         court_price = 0;
        //                                     }
        //                                     grand_total = parseFloat(total_items_price) +
        //                                         parseFloat(court_price);
        //                                     $('#grand_total').text(grand_total)
        //                                 }
        //                             });
        //                         })(item_id);
        //                         li.append(img);
        //                         li.append(title);
        //                         li.append(price);
        //                         results.append(li);
        //                     }
        //                     results.show();
        //                 } else {
        //                     results.hide();
        //                 }
        //             }
        //         })
        //     } else {
        //         $('.search-results').hide();
        //     }
        // });

        // const myDiv = document.getElementById("search-results");

        // // Add click event listener to the document object
        // document.addEventListener("click", function(event) {
        //     // Check if the clicked element is not the div or any of its child elements
        //     if (!myDiv.contains(event.target)) {
        //         // Hide the div
        //         myDiv.style.display = "none";
        //         $('#search_input').val('')
        //     }
        // });

        // // Add a click event listener to the trash icon
        // $('#plus_court_items').on('click', '.ti-trash', function() {
        //     // Get the parent element of the trash icon
        //     var item = $(this).closest('.item');
        //     // Get the ID of the item from the hidden input field
        //     var item_id = item.find('.id').val();
        //     var item_price = item.find('.price_item').text()
        //     // Remove the item from the selectedItems array
        //     var index = selectedItems.indexOf(parseInt(item_id));
        //     if (index > -1) {
        //         selectedItems.splice(index, 1);
        //         // Remove the item from the DOM
        //         item.remove();
        //         total_items_price -= parseFloat(item_price);
        //         $('#items_total_price').text(total_items_price)
        //         grand_total = parseFloat(total_items_price) +
        //             parseFloat(court_price);
        //         $('#grand_total').text(grand_total)
        //     }
        // });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\sportciety_club\resources\views/calendar/index.blade.php ENDPATH**/ ?>