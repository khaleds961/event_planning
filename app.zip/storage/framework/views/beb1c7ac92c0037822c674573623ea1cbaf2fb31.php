<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body lang="<?php echo e(app()->getLocale()); ?>">
    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->make('layouts.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<?php /**PATH C:\Users\ProUser\Desktop\sportciety\sportciety_club\resources\views/layouts/master.blade.php ENDPATH**/ ?>