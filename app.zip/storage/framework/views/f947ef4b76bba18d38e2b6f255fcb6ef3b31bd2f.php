<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    
    <!-- Preloader -->
    <div class="preloader">
        
    <div class="spinner-grow lds-ripple img-fluid text-warning" style="width: 5rem; height: 5rem" role="status">
        <span class="visually-hidden">Loading...</span>
        </div>
    </div>

    <!-- Preloader -->
    <div class="preloader">
        
        <div class="spinner-grow lds-ripple img-fluid text-warning" style="width: 5rem; height: 5rem" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
    </div>

    <!--  Body Wrapper -->
    <div class="page-wrapper" id="main-wrapper" data-theme="blue_theme" data-layout="vertical" data-sidebartype="full"
        data-sidebar-position="fixed" data-header-position="fixed">

        <!-- Sidebar Start -->
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--  Sidebar End -->

        <!--  Main wrapper -->
        <div class="body-wrapper">
            <!--  Header Start -->
            <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--  Header End -->
            <div class="full-container" style="padding: 5rem 1rem;">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>

    <!--  Shopping Cart -->
    

    <!--  Mobilenavbar -->
    

    <!--  Search Bar -->
    <?php echo $__env->make('layouts.searchbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--  Customizer setting button -->
    <?php echo $__env->make('layouts.setting_button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--  Customizer Foot -->
    <?php echo $__env->make('layouts.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/layouts/master.blade.php ENDPATH**/ ?>