
<?php $__env->startSection('title', 'Expenses Types'); ?>
<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <div class="d-md-flex justify-content-between">
            <ol class="breadcrumb border border-warning px-3 py-2 rounded">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                            class="ti ti-home fs-4 mt-1"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="#" class="text-warning">Expenses Types</a>
                </li>
            </ol>

            <div>
                <a type="button" class="btn mb-1 waves-effect waves-light btn-light text-dark fs-4 mx-md-2 full_width"
                    data-bs-toggle="modal" data-bs-target="#eventModal" id="modal_button">
                    <i class="ti ti-circle-plus"></i>
                    <span>Add New Type</span>
                </a>

                <a type="button" class="btn mb-1 waves-effect waves-primary btn-primary text-white text-dark fs-4 mx-md-2 full_width"
                href="<?php echo e(route('expenses.index')); ?>">
                    <i class="ti ti-wallet"></i>
                    <span>Expenses Page</span>
                </a>
            </div>
        </div>
    </nav>

    <div class="d-md-flex justify-content-end">
        <!-- BEGIN MODAL -->
        <div class="modal fade" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="eventModalLabel">
                            Add Type
                            <button type="button" class="btn btn-light-info text-info mx-2 add_type" aria-pressed="false">
                                <i class="ti ti-plus fs-3 text"></i>
                            </button>
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="row">
                        <div class="col" id="type_form">
                            <div class="mx-2">
                                <input type="text" class="form-control" name="type_name[]" id="first_type">
                                <span class="invalid-feedback"></span>
                            </div>
                            <div id="type-container">
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end my-2">
                        <button type="submit" class="btn btn-success btn-add-event mx-2" id="save_item">
                            <i class="ti ti-device-floppy fs-3"></i>
                            Save Type(s)
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="my-2">

                        <div class="table-responsive">
                            <table id="expenses_types_table"
                                class="table border table-striped table-bordered display text-nowrap">
                                <thead>
                                    <!-- start row -->
                                    <tr>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">#id</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">name</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">amount</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">payment</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">is active</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">action</h6>
                                        </th>
                                    </tr>
                                    <!-- end row -->
                                </thead>
                                <tbody>
                                    <!-- start row -->
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                            </table>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#expenses_types_table').DataTable({
                processing: true,
                serverSide: true,
                // scrollY: '100%',
                // scrollX: $(window).width() <= 663,
                // scrollCollapse: true,
                // paging: true,
                responsive: true,
                ajax: "<?php echo e(route('expenses_type.index')); ?>",
                columns: [{
                        data: 'id',
                        id: 'id'
                    },
                    {
                        data: 'name',
                        name: 'name',
                        className: 'type_name'
                    },
                    {
                        data: 'amount',
                        name: 'amount',
                        className: 'text-success'
                    },
                    {
                        data: 'payment',
                        name: 'payment',
                        className: 'text-danger'
                    },
                    {
                        data: 'is_active',
                        name: 'is_active'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    }
                ],
                order: [0, 'desc'],
            });

            //add type input
            $(document).on('click', '.add_type', function(e) {
                $('#type-container').append(`
                <div class="d-flex my-3 mx-2 type_append">
                <input type="text" class="form-control" name="type_name[]">
                <div class="mx-2 invalid-feedback"></div>
                <button class="btn p-2 text-danger delete_type">
                    <i class="ti ti-trash"></i>
                </button>
                </div>
                `);
            })

            //delete appended type input
            $(document).on('click', '.delete_type', function(e) {
                $(this).closest('.type_append').remove();
            });

            //
            function validateInput(input) {
                var name = input.val();
                if (name.length === 0 || name.length < 3 || name.length > 30) {
                    input.addClass('is-invalid');
                    input.next('.invalid-feedback').text('Name must be between 3 and 30 characters');
                    return false;
                } else {
                    input.removeClass('is-invalid');
                    input.next('.invalid-feedback').empty();
                    return true;
                }
            }

            $(document).on('click', '#save_item', function(e) {
                var valid = true;

                valid = validateInput($('#first_type')); // Validate the first type input

                $('.type_append input[type="text"]').each(function() {
                    valid = valid && validateInput($(
                        this)); // Validate each type input and update the overall validity
                });

                if (valid) {
                    // Make your AJAX call here
                    var formData = $('#type_form').find('input[type="text"], input[name^="type_name"]')
                        .serializeArray(); // Serialize the form data
                    console.log(formData);
                    $.ajax({
                        url: "<?php echo e(route('expenses_type.store')); ?>",
                        method: 'POST',
                        data: {
                            type_name: formData
                        },
                        success: function(response) {
                            if (response.success) {
                                swal({
                                    title: 'TYPE(S) ADDED SUCCESSFULLY',
                                    icon: 'success'
                                }).then(() => {
                                    location.reload()
                                })
                            }
                        },
                        error: function(xhr, status, error) {
                            // Handle the error
                        }
                    });
                } else {
                    console.log('Invalid name length');
                }
            });

            const modal = document.querySelector('#eventModal');
            modal.addEventListener('hidden.bs.modal', function(event) {
                const elementsToRemove = document.querySelectorAll('div.type_append');
                elementsToRemove.forEach(function(element) {
                    element.remove();
                });
                const in_err = document.querySelector('input.is-invalid');
                in_err.classList.remove('is-invalid');
                in_err.textContent = '';
            });

            $('#expenses_types_table tbody').on('click', '.type_name', function() {

                // Get the td element that was clicked
                var td = $(this);
                // console.log(table.row(this).data());
                var item = table.row(this).data();
                var expenses_name = item.name;

                // Get the current price
                var priceValue = $(this).text();

                // Create two new input elements with type="time" and set their values to the current check-in
                var nameInput = $('<input type="text">').val(priceValue);

                // Append the input elements to the td element
                td.empty().append(nameInput);

                // Set the focus to the check-in input element
                nameInput.focus();

                // Add a blur event listener to both input elements
                nameInput.blur(function() {

                    // Get the new values of the input elements
                    var new_name = nameInput.val();

                    // Get the attendance ID for the row
                    var item_id = item.id;
                    if (new_name.length > 3 && new_name.length < 30) {
                        $.ajax({
                            url: "<?php echo e(route('expenses_type.update')); ?>",
                            type: 'POST',
                            data: {
                                id: item_id,
                                expenses_name: new_name,
                            },
                            success: function(response) {
                                if (response.success) {
                                    var name = response.data.name;
                                    // Replace the input elements with new td elements containing the updated values
                                    var newTd = $('<td>').addClass('type_name').text(
                                            name)
                                        .data('name', name)
                                        .data('item-id', response.data.id);
                                    td.replaceWith(newTd);
                                } else {
                                    var newTd = $('<td>').addClass('type_name').text(
                                            expenses_name)
                                        .data('name', expenses_name)
                                        .data('item-id', item_id);
                                    td.replaceWith(newTd);
                                }
                            },
                            error: function(xhr, status, error) {
                                console.log(xhr.responseText);
                            }
                        });
                    } else {
                        swal({
                            title: 'NAME SHOULD BE BETWEEN 3 AND 30 CHARACTERS',
                            icon: 'warning'
                        }).then(() => {
                            var newTd = $('<td>').addClass('type_name').text(
                                    expenses_name)
                                .data('name', expenses_name)
                                .data('item-id', item_id);
                            td.replaceWith(newTd);
                        })

                    }
                    // Send an AJAX request to update the check-in and check-out times
                });
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/expenses_types/index.blade.php ENDPATH**/ ?>