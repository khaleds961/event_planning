
<?php $__env->startSection('title', 'Items'); ?>
<?php $__env->startSection('content'); ?>
    
    <nav aria-label="breadcrumb" class="mb-1">
        <div class="d-md-flex justify-content-between">
            <ol class="breadcrumb border border-warning px-3 py-2 rounded">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                            class="ti ti-home fs-4 mt-1"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="#" class="text-warning">Items</a>
                </li>
            </ol>

            <div>
                <a type="button" class="btn mb-1 waves-effect waves-light btn-light text-dark fs-4 mx-md-2 modal_button full_width"
                    data-bs-toggle="modal" data-bs-target="#eventModal" id="modal_button">
                    <i class="ti ti-circle-plus"></i>
                    <span>Add New Item</span>
                </a>
            </div>
        </div>
    </nav>

    <div class="d-md-flex justify-content-end">
        <!-- BEGIN MODAL -->
        <div class="modal fade" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="eventModalLabel">
                            Add Item
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form class="modal-body" action="<?php echo e(route('items.store')); ?>" method="POST"
                        enctype="multipart/form-data" id="store_item_form">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="form-label d-flex justify-content-between align-items-center">
                                    <span>Name
                                    </span>
                                </label>
                                <input id="item_name" name="name" type="text" class="form-control" />
                                <span id="name_error"></span>
                            </div>

                            <div class="col-md-6 mt-2 mt-md-0" id="price_input">
                                <label class="form-label d-flex justify-content-between align-items-center">
                                    <span>Price
                                        <i class="ti ti-currency-dollar"></i>
                                    </span>
                                </label>
                                <input id="item_price" type="number" name="price" class="form-control" value="0" />
                                <span id="price_error"></span>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-md-6" id="price_input">
                                <label class="form-label d-flex justify-content-between align-items-center">
                                    <span>Unit
                                    </span>
                                </label>
                                <select id="item_unit" class="form-control" name="unit">
                                    <option value="0">0</option>
                                    <option value="1">1</option>
                                </select>
                                <span id="price_error"></span>
                            </div>

                            <div class="col-md-6 mt-2 mt-md-0" id="price_input">
                                <label class="form-label d-flex justify-content-between align-items-center">
                                    <span>Quantity/Hour
                                    </span>
                                </label>
                                <select id="item_qty_hour" class="form-control" name="qty_hour">
                                    <option value="none">None</option>
                                    <option value="qty">Quantity</option>
                                    <option value="hour">Hour</option>
                                </select>
                                <span id="price_error"></span>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col mt-2">
                                <h6>Image</h6>
                                <input type="file" name="image" class="dropify" data-max-file-size="2M"
                                    data-allowed-file-extensions="png jpg jpeg">
                            </div>
                        </div>

                        <div class="d-flex justify-content-end my-2">
                            <button type="submit" class="btn btn-success btn-add-event" id="save_item">
                                Save Item
                            </button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="d-md-flex justify-content-end">
        <!-- BEGIN edit MODAL -->
        <div class="modal fade" id="editeventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="eventModalLabel">
                            Edit Item
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form class="modal-body" action="<?php echo e(route('items.update')); ?>" method="POST"
                        enctype="multipart/form-data" id="edit_item_form">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="form-label d-flex justify-content-between align-items-center">
                                    <span>Name
                                    </span>
                                </label>
                                <input id="edititem_name" name="editname" type="text" class="form-control" />
                                <span id="editname_error"></span>
                            </div>

                            <input type="hidden" id="item_id" name="item_id">

                            <div class="col-md-6 mt-2 mt-md-0" id="price_input">
                                <label class="form-label d-flex justify-content-between align-items-center">
                                    <span>Price
                                        <i class="ti ti-currency-dollar"></i>
                                    </span>
                                </label>
                                <input id="edititem_price" type="number" name="editprice" class="form-control" />
                                <span id="editprice_error"></span>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-md-6" id="editunit">
                                <label class="form-label d-flex justify-content-between align-items-center">
                                    <span>Unit
                                    </span>
                                </label>
                                <select id="edititem_unit" class="form-control" name="editunit">
                                    <option value="0">0</option>
                                    <option value="1">1</option>
                                </select>
                            </div>

                            <div class="col-md-6 mt-2 mt-md-0">
                                <label class="form-label d-flex justify-content-between align-items-center">
                                    <span>Quantity/Hour
                                    </span>
                                </label>
                                <select id="edititem_qty_hour" class="form-control" name="editqty_hour">
                                    <option value="none">None</option>
                                    <option value="qty">Quantity</option>
                                    <option value="hour">Hour</option>
                                </select>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col mt-2">
                                <h6>Image</h6>
                                <div id="edit_dropify">
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end my-2">
                            <button type="submit" class="btn btn-success btn-add-event" id="edit_item">
                                Update Item
                            </button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="my-2">

                        <div class="table-responsive">
                            <table id="items-list" class="table border table-striped table-bordered display text-nowrap">
                                <thead>
                                    <!-- start row -->
                                    <tr>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">#id</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">image</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">name</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">price<i class="ti ti-currency-dollar"></i></h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">is active</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">action</h6>
                                        </th>
                                    </tr>
                                    <!-- end row -->
                                </thead>
                                <tbody>
                                    <!-- start row -->
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                            </table>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {

            $('.dropify').dropify();


            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#items-list').DataTable({
                processing: true,
                serverSide: true,
                scrollY: '100%',
                scrollCollapse: true,
                paging: true,
                responsive: true,
                ajax: "<?php echo e(route('items.index')); ?>",
                columns: [{
                        data: 'id',
                        id: 'id'
                    },
                    {
                        data: 'image',
                        name: 'image',
                    },
                    {
                        data: 'name',
                        name: 'name',
                    },
                    {
                        data: 'price',
                        name: 'price',
                    },
                    {
                        data: 'is_active',
                        name: 'is_active'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    }
                ],
                order: [0, 'desc'],
            });

            //show edit modal
            $(document).on('click', '.editmodal_button', function(e) {
                var id = $(this).data('id');
                $('#item_id').val(id)
                $('#editname_error').empty()
                $.ajax({
                    url: "<?php echo e(route('items.show')); ?>",
                    data: {
                        id: id
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            var defaultFilePath = data.data.img ? asset(data.data.img) : asset(
                                'images/courts/no-image.png');
                            $('#edititem_name').val(data.data.name);
                            $('#edititem_price').val(data.data.price);
                            $('#edititem_unit').val(data.data.unit);
                            $('#edititem_qty_hour').val(data.data.qty_hour)
                            $('#edit_dropify').append(`<input type="file" name="editimage" class="edit_dropify" data-max-file-size="2M"
                                    data-allowed-file-extensions="png jpg jpeg">`);
                            $('.edit_dropify').attr('data-default-file', defaultFilePath);
                            $('.edit_dropify').dropify();
                        }
                    }
                })

            });
        });
        
        //store
        $(document).on('click', '#save_item', function(e) {

            e.preventDefault();

            $('#name_error').empty()
            $('#price_error').empty()

            var item_name = $('#item_name').val();
            var item_price = $('#item_price').val();
            var item_unit = $('#item_unit').val();
            var item_qty_hour = $('#item_qty_hour').val();
            var file = $('input[name="image"]')[0].files[0];

            if (item_name.length < 3 || item_name.length > 30) {
                $('#name_error').append(
                    '<span class="err text-uppercase text-danger">name should be between 3 and 30 characters</span>'
                )
            } else {
                $('#name_error').empty()
            }

            if (item_price < 0 || isNaN(parseFloat(item_price))) {
                $('#price_error').append(
                    '<span class="err text-uppercase text-danger">enter a correct number</span>'
                );
            } else {
                $('#price_error').empty();
            }

            if ($('.err').length == 0) {
                $('#store_item_form').submit();
            }

        })

        $('#editeventModal').on('hidden.bs.modal', function() {
            $('#edititem_name').val('');
            $('#edititem_price').val(0);
            $('#edititem_unit').val(0);
            $('#edititem_qty_hour').val('none')
            $('#edit_dropify').empty()
            $('#item_id').val('')
        })

        function asset(path) {
            var baseUrl = document.head.querySelector('meta[name="base-url"]').getAttribute('content');
            return baseUrl + '/' + path;
        }

        //update
        $(document).on('click', '#edit_item', function(e) {

            e.preventDefault();

            $('#editname_error').empty()
            $('#editprice_error').empty()

            var item_name = $('#edititem_name').val();
            var item_price = $('#edititem_price').val();
            var item_unit = $('#edititem_unit').val();
            var item_qty_hour = $('#edititem_qty_hour').val();
            var file = $('input[name="editimage"]')[0].files[0];

            if (item_name.length < 3 || item_name.length > 30) {
                $('#editname_error').append(
                    '<span class="err text-uppercase text-danger">name should be between 3 and 30 characters</span>'
                )
            } else {
                $('#editname_error').empty()
            }

            if (item_price < 0 || isNaN(parseFloat(item_price))) {
                $('#edititem_price').val(0);
                $('#editprice_error').append(
                    '<span class="err text-uppercase text-danger">enter a correct number</span>'
                );
            } else {
                $('#editprice_error').empty();
            }

            if ($('.err').length == 0) {
                $('#edit_item_form').submit();
            }

        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\sportciety_club\resources\views/items/index.blade.php ENDPATH**/ ?>