
<?php $__env->startSection('title', 'Courts'); ?>

<?php $__env->startSection('content'); ?>


<nav aria-label="breadcrumb" class="mb-1">
    <ol class="breadcrumb border border-warning px-3 py-2 rounded">
      <li class="breadcrumb-item">
        <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
            class="ti ti-home fs-4 mt-1"></i></a>
      </li>
      <li class="breadcrumb-item">
        <a href="#" class="text-warning">Courts</a>
      </li>
      <li class="breadcrumb-item active text-warning font-medium" aria-current="page">
        Show Courts
      </li>
    </ol>
  </nav>

  <div class="row mt-4">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
          <div class="my-2">

          <div class="table-responsive">
            <table
              id="courts-list"
              class="table border table-striped table-bordered display text-nowrap"
            >
              <thead>
                <!-- start row -->
                <tr>
                  <th>#</th>
                  <th>Image</th>
                  <th>Title</th>
                  <th>Sport(s)</th>
                  <th>Is Active</th>
                  <th>Action</th>
                </tr>
                <!-- end row -->
              </thead>
              <tbody>
                <!-- start row -->
                <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
            </table>
          </div>

        </div>
      </div>

    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#courts-list').DataTable({
                processing: true,
                serverSide: true,
                scrollY: '470px',
                scrollCollapse: true,
                paging: true,
                responsive: true,
                ajax: "<?php echo e(route('courts.index')); ?>",
                columns: [{
                        data: 'id',
                        id: 'id'
                    },
                    {
                        data: "image",
                        name: 'image'
                    },
                    {
                        data: 'title_en',
                        name: 'title_en'
                    },
                    {
                        data: 'addsport',
                        name: 'addsport'
                    },
                    {
                        data: 'is_active',
                        name: 'is_active'
                    },
                    {
                        data: 'actions',
                        name: 'actions',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    },
                ],
                order: [0, 'desc'],
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\khaled.alhoussein\Desktop\sporciety_new\sportciety_club\resources\views/courts/index.blade.php ENDPATH**/ ?>