
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-sm-12 col-md-3">
            <div class="mb-3">
                <label for="datefrom" class="control-label col-form-label">FROM</label>
                <input type="date" class="form-control" id="datefrom" value="<?php echo e(request()->get('date_from')); ?>" />
            </div>
        </div>

        <div class="col-sm-12 col-md-3">
            <div>
                <label for="dateto" class="control-label col-form-label">TO</label>
                <input type="date" class="form-control" id="dateto" value="<?php echo e(request()->get('date_to')); ?>" />
            </div>
        </div>

        <div class="col-sm-12 col-md-3">
            <div>
                <label for="sports" class="control-label col-form-label">SPORTS</label>
                <select class="form-control" id="sports" onchange="getCourts()">
                    <option selected value="none">--None--</option>
                    <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sport['id']); ?>"
                            <?php echo e(request()->get('sport_id') == $sport['id'] ? 'selected' : ''); ?>><?php echo e($sport['name']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="col-sm-12 col-md-3">
            <div>
                <label for="courts" class="control-label col-form-label">COURTS</label>
                <select class="form-control" id="courts">
                    <option selected value="none">--None--</option>
                </select>
            </div>
        </div>

    </div>

    <div class="d-flex mt-3 mt-md-0">
    
        <div>
            <button class="btn btn-danger" onclick="search()">
                <i class="ti ti-search"></i>
                <span class="mx-2">Search</span>
            </button>
        </div>
    
        <div class="mx-2"></div>
    
        <div>
            <button class="btn btn-primary" onclick="clearsearch()">
                <i class="ti ti-eraser"></i>
                <span class="mx-2">Clear</span>
            </button>
        </div>
    
</div>


    <div class="row mt-4">
        <div class="col-sm-6 col-lg-3 col-xl-3">
            <a class="p-4 text-center bg-light-primary card shadow-none rounded-2">
                <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/svgs/icon-user-male.svg"
                    width="50" height="50" class="mb-6 mx-auto" alt="">
                <p class="fw-semibold text-primary mb-1">Customers</p>
                <h4 class="fw-semibold text-primary mb-0"><?php echo e($customers); ?></h4>
            </a>
        </div>
        <div class="col-sm-6 col-lg-3 col-xl-3">
            <a class="p-4 text-center bg-light-warning card shadow-none rounded-2">
                <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/svgs/icon-briefcase.svg"
                    width="50" height="50" class="mb-6 mx-auto" alt="">
                <p class="fw-semibold text-warning mb-1">Booking</p>
                <h4 class="fw-semibold text-warning mb-0"><?php echo e($bookings); ?></h4>
            </a>
        </div>
        <div class="col-sm-6 col-lg-3 col-xl-3">
            <a class="p-4 text-center bg-light-danger card shadow-none rounded-2">
                <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/svgs/icon-favorites.svg"
                    width="50" height="50" class="mb-6 mx-auto" alt="">
                <p class="fw-semibold text-danger mb-1">Revenue</p>
                <h4 class="fw-semibold text-danger mb-0">$<?php echo e(number_format($revenue, 2)); ?></h4>
            </a>
        </div>
        <div class="col-sm-6 col-lg-3 col-xl-3">
            <a class="p-4 text-center bg-light-success card shadow-none rounded-2">
                <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/svgs/icon-speech-bubble.svg"
                    width="50" height="50" class="mb-6 mx-auto" alt="">
                <p class="fw-semibold text-success mb-1">Net Profit</p>
                <h4 class="fw-semibold text-success mb-0">$<?php echo e(number_format($net_profit, 2)); ?></h4>
            </a>
        </div>
    </div>

    <section>
        <div class="row">
            <!-- Start Basic Bar Chart -->
            <div class="col-12 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <h4>BOOKING</h4>
                        <div id="chart-bar-basic"></div>
                    </div>
                </div>
            </div>
            <!-- End Basic Bar Chart -->

            <!-- Start top per card -->
            <div class="col-12 col-lg-4">
                <div class="card" style="height: 100%;">
                    <div class="card-body">
                        <h4>TOP PERFORMING</h4>
                        <table class="mb-3 table">
                            <thead class="bg-success text-white">
                                <tr>
                                    <th>COURT</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $court_booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($cb['title_en']); ?></td>
                                        <td><?php echo e($cb['booking_count']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End top per card -->

            <!-- Start top per card -->
            <div class="col-12 col-lg-4">
                <div class="card" style="height: 100%;">
                    <div class="card-body">
                        <h4>CUSTOMERS</h4>
                        <table class="mb-3 table">
                            <thead class="bg-warning text-white">
                                <tr>
                                    <th>NAME</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $clients_booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client_booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($client_booking['full_name']); ?></td>
                                        <td><?php echo e($client_booking['booking_count']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End top per card -->

        </div>

    </section>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            // Get the URL parameters
            const urlParams = new URLSearchParams(window.location.search);

            var first_day_of_month = moment().startOf('month').format('YYYY-MM-DD');
            var last_day_of_month = moment().endOf('month').format('YYYY-MM-DD');

            var date_from = urlParams.get('date_from');
            var date_to = urlParams.get('date_to');
            
            if (!date_from && !date_to) {
                $('#datefrom').val(first_day_of_month);
                $('#dateto').val(last_day_of_month);
            }
            // Extract the sport_id parameter from the URL
            const sportId = urlParams.get('sport_id');
            // Check if sport_id exists and has a valid value
            if (sportId && sportId !== '') {
                // Sport ID exists and is not empty
                getCourts(sportId)
            } else {
                // Sport ID does not exist or is empty
                console.log('Sport ID does not exist or is empty');
            }
        });

        function getCourts(sport_id = 0) {
            if (!sport_id) {
                var sport_id = $('#sports').val();
            }
            $('#courts').empty();
            $('#courts').append('<option selected disabled>--None--</option>');
            if (sport_id && sport_id != 0) {
                $.ajax({
                    url: "<?php echo e(route('booking.sportsbycourt')); ?>",
                    data: {
                        sport_id: sport_id
                    },
                    type: 'POST',
                    success: function(response) {
                        console.log(response);
                        if (response.success) {
                            var data = response.data;
                            for (var i = 0; i < data.length; i++) {
                                var option = $('<option>', {
                                    value: data[i].id,
                                    text: data[i].title_en
                                });
                                $('#courts').append(option);
                            }
                        }
                    }
                });
            }
        }

        function search() {
            var URL = "<?php echo e(route('index')); ?>";
            var date_from = $('#datefrom').val().trim();
            var date_to = $('#dateto').val().trim();
            var sport_id = $('#sports').val().trim();
            var court_id = $('#courts').val();

            var element = [];

            if (date_from && date_to) {
                element.push('date_from=' + date_from);
                element.push('date_to=' + date_to);
            }

            if (sport_id && sport_id != null && sport_id != 'none') {
                element.push('sport_id=' + sport_id);
            }

            if (court_id && court_id != null && court_id != 'none') {
                element.push('court_id=' + court_id)
            }

            if (element.length > 0) {
                URL += '?' + element.join('&');
            } else {
                location.href = "<?php echo e(route('expensehistory.index')); ?>";
            }

            location.href = URL;

        }

        function clearsearch() {
            var URL = "<?php echo e(route('index')); ?>";
            $('#datefrom').val('');
            $('#dateto').val('');
            $('#sports').val('none');
            $('#courts').val('none')
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\sportciety_club\resources\views/dashboard/index.blade.php ENDPATH**/ ?>