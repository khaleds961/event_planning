
<?php $__env->startSection('title', 'Edit Sport'); ?>
<?php $__env->startSection('content'); ?>

    

    
    <nav aria-label="breadcrumb" class="mb-1">
        <ol class="breadcrumb border border-warning px-3 py-2 rounded">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                        class="ti ti-home fs-4 mt-1"></i></a>
            </li>
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('courts.index')); ?>" class="text-warning">Courts</a>
            </li>
            <li class="breadcrumb-item active text-warning font-medium" aria-current="page">
                Edit Sport
            </li>
            <li class="breadcrumb-item active text-warning font-medium" aria-current="page">
                <?php echo e($court_title); ?>

            </li>
        </ol>
    </nav>

    <div class="my-3">
        <div class="card">
            <div class="card-body">
                <div class="mb-3 d-flex justify-content-end">
                    <?php if(Helper::check_permission($function_id, 'is_delete')): ?>
                        <button class="btn btn-light-danger text-danger font-medium" type="submit" id="save">
                            <span>Update</span>
                        </button>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('courts.updatesport')); ?>" method="POST" id="sport_update">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" id='court_id' name="court_id">
                    <input type="hidden" id='court_sport_id' name="court_sport_id" value="<?php echo e($court_sport->id); ?>">
                    <div class="form-body">
                        <div class="row">

                            <div class="col">
                                <span>Sport Type<b style="color: #e86945">*</b></span>
                                <select class="form-control my-1" name="sport_id" id="sport_id">
                                    <option disabled value="0" selected>--Select Sport--</option>
                                    <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($sport->id); ?>" <?php echo e($sport->id == $sport_id ? 'selected' : ''); ?>>
                                            <?php echo e($sport->title); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span id="sport_error"></span>
                            </div>

                            <div class="col">
                                <div class="mb-3">
                                    <span>Price<b style="color: #e86945">*</b></span>
                                    <input class="form-control my-1" placeholder="Session Price" type="number"
                                        name="session_price" id="session_price" value="<?php echo e($court_sport->price); ?>" />
                                    <span id="session_price_error"></span>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <label for="session_minutes" class="block my-1">Session Minutes</label>
                                <b style="color: #e86945">*</b>
                                <input id="demo6" type="text" name="demo6" value="<?php echo e($court_sport->session); ?>" />
                                <span id="session_minutes_error"></span>
                            </div>

                            <div class="col">
                                <div class="mb-3">
                                    <span>Capacity<b style="color: #e86945">*</b></span>
                                    <input placeholder="Capacity" type="number" name="capacity" id="capacity"
                                        class="form-control my-1" value="<?php echo e($court_sport->capacity); ?>" />
                                    <span id="capacity_error"></span>
                                </div>
                            </div>


                        </div>
                    </div>
                    <div class="form-actions mt-3">
                        <div class="text-end">
                            <a type="submit" class="btn btn-light-primary text-primary font-medium mx-2"
                                href="<?php echo e(route('courts.index')); ?>">
                                Cancel
                            </a>

                            <?php if(Helper::check_permission($function_id, 'is_delete')): ?>
                                <button class="btn btn-light-warning text-warning font-medium show_confirm_sport"
                                    id="delete" data-id="<?php echo e($court_sport->id); ?>" data-table_name="<?php echo e($table_name); ?>">
                                    <i class="ti ti-trash"></i>
                                    <span>Delete</span>
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#court_id').val(<?php echo json_encode($court_id, 15, 512) ?>);

            //onsubmit button 
            $('#save').on('click', function(e) {
                e.preventDefault();

                $('#session_minutes_error').empty();
                $('#session_price_error').empty();
                $('#capacity_error').empty();
                $('#sport_error').empty();

                var session_minutes = $('#demo6').val();
                var session_price = $('#session_price').val()
                var title = $('#title').val();
                var capacity = $('#capacity').val();
                var sport_id = $('#sport_id').val()

                if (!capacity) {
                    $('#capacity_error').append(
                        '<span class="text-danger err"><b>CAPACITY IS REQUIRED!</b></span>')
                }

                if (!session_minutes || parseFloat(session_minutes) < 30) {
                    $('#session_minutes_error').append(
                        '<span class="text-danger err"><b>SESSION TIME IS REQUIRED AND NOT LESS THAN 30 MIN</b></span>'
                    )
                }

                if (!session_price) {
                    $('#session_price_error').append(
                        '<span class="text-danger block err"><b>SESSION PRICE IS REQUIRED!</b></span>')
                }

                if (sport_id == 0 || sport_id == null) {
                    $('#sport_error').append(
                        '<span class="text-danger block err"><b>SPORT TYPE IS REQUIRED!</b></span>'
                    )
                }

                if ($('.err').length == 0) {
                    $('#sport_update').submit()
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\sportciety_club\resources\views/courts/editsport.blade.php ENDPATH**/ ?>