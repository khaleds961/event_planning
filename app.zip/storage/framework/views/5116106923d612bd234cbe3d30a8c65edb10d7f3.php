<?php if(Helper::check_permission($function_id, 'is_update')): ?>
<a style="cursor:pointer;" data-bs-toggle="modal" data-bs-target="#usertypeModal" id="modal_button_edit"
class="modal_button_edit text-dark"
data-id="<?php echo e($id); ?>" data-table_name="<?php echo e($table_name); ?>" data-type_name="<?php echo e($title); ?>">
    <i class="ti ti-pencil fs-6"></i>
</a>
<?php endif; ?>

<?php if(Helper::check_permission($function_id, 'is_delete')): ?>
<a class="show_confirm_court text-warning delete_icon" data-id="<?php echo e($id); ?>" data-table_name="<?php echo e($table_name); ?>"
    style="cursor: pointer">
    <i class="ti ti-trash me-1 fs-6"></i>
</a>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/permissions/action.blade.php ENDPATH**/ ?>