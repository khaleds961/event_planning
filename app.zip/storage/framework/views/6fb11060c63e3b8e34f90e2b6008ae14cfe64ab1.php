
<?php $__env->startSection('title', 'Staff Attendance'); ?>
<?php $__env->startSection('content'); ?>
    
    <nav aria-label="breadcrumb" class="mb-1">
        <div class="d-md-flex justify-content-between">
            <ol class="breadcrumb border border-warning px-3 py-2 rounded">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                            class="ti ti-home fs-4 mt-1"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('staff.index')); ?>" class="text-warning">Staff</a>
                </li>
                <li class="breadcrumb-item">
                    <a href="#" class="text-warning">Staff Attendance</a>
                </li>
            </ol>

            
        </div>

    </nav>


    <!-- Attendance MODAL -->
    <div class="modal fade" id="attendanceModal" tabindex="-1" aria-labelledby="attendanceModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="attendanceModalLabel">
                        Attendance
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label">Staff
                                <b class="text-danger">*</b>
                            </label>
                            <div class="d-flex" style="border: 1px solid #dfe5ef; border-radius: 5px;">
                                <input type="text" id="search-input" placeholder="Search staff by name"
                                    class="form-control" style="border: none; flex: 1;">
                                <select id="user-select" class="" style="border: none; flex: 1;"></select>
                            </div>
                            <span id="user_error"></span>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Date
                                <b class="text-danger">*</b>
                            </label>
                            <input id="attendance_date" type="date" class="form-control" required />
                            <span id="attendance_date_error"></span>
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-md-6">
                            <div id="check_in"></div>
                            <div id="check_out"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer" id="add_attendance">

                </div>
            </div>
        </div>
    </div>
    <!-- Attendance MODAL -->


    <!-- UPDATE Attendance MODAL -->
    <div class="modal fade" id="updateAttendaceModal" tabindex="-1" aria-labelledby="updateAttendaceModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateAttendaceModalLabel">
                        Update Attendace: <span id="staff_full_name" class="mx-2 text-primary"></span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label">Date
                                <b class="text-danger">*</b>
                            </label>
                            <input id="updateAttendace_date" type="date" class="form-control" required />
                            <span id="updateAttendace_date_error"></span>
                        </div>
                    </div>

                    <div>
                        <div id="in_out_update" class="row mt-2"></div>
                    </div>

                    <div id="attendance_error" class="text-uppercase text-danger"></div>
                </div>
            </div>
        </div>
    </div>
    <!-- Attendance MODAL -->

    <div class="row mt-4">
        <div class="col-12">
            <div class="row">
                <div class="col-md-2">
                    <div class="mb-3 has-success">
                        <label class="control-label">DATE</label>
                        <input type="date" class="form-control" id="start_date">
                        <span id="start_date_error"></span>
                    </div>
                </div>

                <div class="col-md-2">
                    <button class="btn btn-dark margin_top_responsive" id="search_attendance">
                        <i class="ti ti-search"></i>
                        <span>Search</span>
                    </button>

                    <button class="btn btn-primary margin_top_responsive mx-md-2" id="clear_attendance">
                        <i class="ti ti-brush"></i>
                        <span>Clear Date</span>
                    </button>
                </div>



            </div>
            <div class="card">
                <div class="card-body">
                    <div class="my-2">
                        <div class="table-responsive">
                            <table id="attendance-list"
                                class="table border table-striped table-bordered display text-nowrap">
                                <thead>
                                    <!-- start row -->
                                    <tr>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">#id</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">full name</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">date</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">check in</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">check out</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">action</h6>
                                        </th>
                                        
                                    </tr>
                                    <!-- end row -->
                                </thead>
                                <tbody>
                                    <!-- start row -->
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>

                                    </tr>
                            </table>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var today = moment().format('YYYY-MM-DD');
            $('#attendance_date').val(moment().format('YYYY-MM-DD')).attr('max', moment().format('YYYY-MM-DD'))
            $('#start_date').val(moment().format('YYYY-MM-DD')).attr('max', moment().format('YYYY-MM-DD'))

            var table = $('#attendance-list').DataTable({
                processing: true,
                serverSide: true,
                // scrollY: '100%',
                // scrollX: $(window).width() <= 1740,
                // scrollCollapse: true,
                // paging: true,
                responsive: true,
                ajax: "<?php echo e(route('staff.show_attendance_page')); ?>",
                columns: [{
                        data: 'staff_id',
                        id: 'id'
                    },
                    {
                        data: 'name',
                        name: 'name',
                    },
                    {
                        data: 'date',
                        name: 'date',
                    },
                    {
                        data: 'attendance_in',
                        name: 'attendance_in',
                        className: 'check_in'
                    },
                    {
                        data: 'attendance_out',
                        name: 'attendance_out',
                        className: 'check_out'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    }
                ],
                order: [0, 'desc'],
            });

            $(document).on('change', '#user-select', function(e) {
                check_attendance()
            })

            $(document).on('change', '#attendance_date', function(e) {
                check_attendance()
            })

            function check_attendance() {

                $('#check_in').empty();
                $('#check_out').empty();
                $('#add_attendance').empty();

                var date = $('#attendance_date').val();
                var user_id = $('#user-select').val();

                if (date && user_id) {
                    $.ajax({
                        url: "<?php echo e(route('staff.check_attendance')); ?>",
                        data: {
                            date: date,
                            staff_id: user_id
                        },
                        type: 'POST',
                        success: function(data) {

                            if (data.msg == 'no_check_in') {

                                $('#check_in').empty();
                                $('#add_attendance').empty();

                                $('#check_in').append(`
                                <label class="form-label">Check In<b class="text-danger">*</b></label>
                                <input type="time" id="check_in_time" class="form-control" required/>
                                <span id="check_in_error"></>
                                `);
                                $('#add_attendance').append(`
                                <button type="button" class="btn btn-primary" id="add_check_in">
                                <i class="ti ti-user mx-2"></i>
                                Add Check In
                                </button>
                                `);
                            } else if (data.msg == 'no_check_out') {
                                $('#check_out').empty();
                                $('#add_attendance').empty();

                                $('#check_out').append(`
                                <label class="form-label">Check Out<b class="text-danger">*</b></label>
                                <input type="time" id="check_out_time" class="form-control" required/>
                                `);
                                $('#add_attendance').append(`
                                <button type="button" class="btn btn-primary" id="add_check_out">
                                <i class="ti ti-user mx-2"></i>
                                Add Check Out
                                </button>
                                `);
                            } else {
                                $('#check_out').append(
                                    `<p class="text-uppercase text-danger">Attendance has already been added for this staff member on this date: ${date} !!</p>`
                                )
                            }
                        }
                    });
                }
            }

            $(document).on('click', '#attendance_button', function(e) {
                $('#check_out').empty()
                $('#check_in').empty()
                $('#add_attendance').empty()
                $('#search-input').val('')
                $('#user-select').empty()
            });

            $(document).on('click', '#add_check_in', function(e) {

                $('#check_in_error').empty();
                $('#attendance_date_error').empty();
                $('#user_error').empty();

                var date = $('#attendance_date').val()
                var staff_id = $('#user-select').val()
                var check_in_time = $('#check_in_time').val()

                if (date > today) {
                    $('#attendance_date_error').append(
                        '<span class="err text-uppercase text-danger">date wrong format!</span>');
                } else {
                    $('#attendance_date_error').empty();
                }

                if (!staff_id) {
                    $('#user_error').append(
                        '<span class="err text-uppercase text-danger">choosing staff is required !</span>'
                    );
                } else {
                    $('#user_error').empty();
                }

                if (!check_in_time) {
                    $('#check_in_error').append(
                        '<span class="err text-uppercase text-danger">Check In is required !</span>'
                    );
                } else {
                    $('#check_in_error').empty();
                }

                if ($('.err').length == 0) {
                    $.ajax({
                        url: "<?php echo e(route('staff.add_attendance')); ?>",
                        data: {
                            staff_id: staff_id,
                            date: date,
                            check_in_time: check_in_time,
                            check_in: true
                        },
                        type: 'POST',
                        success: function(data) {
                            if (data.success) {
                                swal({
                                    title: "CHECK IN ADDED",
                                    icon: "success",
                                }).then(() => {
                                    location.reload();
                                });
                                $('#search-input').val('')
                                $('#user-select').empty()
                                $('#check_in').empty()
                                $('#add_attendance').empty()
                            }
                        }
                    });
                }
            })

            $(document).on('click', '#add_check_out', function(e) {
                var date = $('#attendance_date').val()
                var staff_id = $('#user-select').val()
                var check_out_time = $('#check_out_time').val()

                if (date > today) {
                    $('#attendance_date_error').append(
                        '<span class="err text-uppercase text-danger">date wrong format!</span>');
                } else {
                    $('#attendance_date_error').empty();
                }


                $.ajax({
                    url: "<?php echo e(route('staff.add_attendance')); ?>",
                    data: {
                        staff_id: staff_id,
                        date: date,
                        check_out_time: check_out_time,
                        check_out: true
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            swal({
                                title: "CHECK OUT ADDED",
                                icon: "success",
                            }).then(() => {
                                location.reload();
                            });
                            $('#search-input').val('')
                            $('#user-select').empty()
                            $('#check_out').empty()
                            $('#add_attendance').empty()
                        } else {
                            swal({
                                title: `CHECK OUT COULD NOT BE LESS THAN ${moment(data.check_in,'HH:mm:ss').format('h:mm A')}`,
                                icon: 'warning'
                            });
                        }
                    }
                });



            })

            $('#search-input').on('input', function() {

                $('#check_out').empty();
                $('#check_in').empty();
                $('#add_attendance').empty()

                var query = $(this).val();
                if (query.length >= 2) {
                    $.ajax({
                        url: "<?php echo e(route('staff.seacrh_staff')); ?>",
                        data: {
                            query: query
                        },
                        success: function(data) {
                            if (data.success) {
                                $('#new_member_button').css('display', 'none');
                                $('#new_member_content').css('display', 'none');
                                $('#user-select').empty();
                                $.each(data.data, function(key, user) {
                                    $('#user-select').append($('<option>', {
                                        value: user.id,
                                        text: user.full_name
                                    }));
                                });
                                check_attendance()
                            } else {
                                $('#user-select').empty();
                                $('#user-select').append($('<option>', {
                                    value: 0,
                                    text: 'no staff match'
                                }));
                                $('#new_member_button').css('display', 'block');
                            }
                        }
                    });
                }
            });

            var staff_id;
            var staff_full_name;
            $(document).on('click', '.update_attendance_icon', function() {
                $('#staff_full_name').empty()
                console.log('dd');
                staff_id = $(this).data('id')
                staff_full_name = $(this).data('full-name')
                $('#in_out_update').empty()
                $('#staff_full_name').append(staff_full_name);
                $('#updateAttendace_date').val('');
                $('#attenendance_in').val('')
                $('#attenendance_out').val('')
                $('#attendance_error').empty()
            });

            $('#updateAttendace_date').on('change', function(e) {
                $('#in_out_update').empty();
                $('#updateAttendace').empty();
                $('#attendance_error').empty();

                var date = $('#updateAttendace_date').val()

                if (staff_id && date) {
                    $.ajax({
                        url: "<?php echo e(route('staff.getstaffattendance')); ?>",
                        data: {
                            staff_id: staff_id,
                            date: date
                        },
                        type: 'POST',
                        success: function(data) {
                            if (data.success) {
                                $('#in_out_update').append(`
                            <div class="col-md-5">
                            <label for="attenendance_in" class="form-label">Check In
                                <b class="text-danger">*</b>
                            </label>
                            <input id="attenendance_in" type="time" class="form-control" required value="${data.data.attendance_in}"/>
                        </div>

                        <div class="col-md-5">
                            <label for="attenendance_out" class="form-label">Check Out
                                <b class="text-danger">*</b>
                            </label>
                            <input id="attenendance_out" type="time" class="form-control" required value="${data.data.attendance_out}" />
                            <span class="attendance_error"></span>
                        </div>

                        <div class="col-md-2 d-flex justify-content-end align-items-center mt-4" id="updateAttendace">
                    </div>


                            `);

                                $('#updateAttendace').append(`
                        <a type='button' class="btn btn-primary p-2 update_attendance" data-id="${data.data.id}">
                            <i class="ti ti-pencil"></i>
                        </a>
                        <a type='button' class="btn btn-danger p-2 mx-3 show_confirmed delete_icon" data-table_name="staff_attendance" data-id="${data.data.id}">
                            <i class="ti ti-trash"></i>
                        </a>
                        `)
                            } else {
                                $('#attendance_error').append('no attendance for this day')
                            }

                        }
                    })
                }
            });

            $(document).on('click', '.update_attendance', function(e) {

                var attendance_id = $(this).data('id');
                var attendance_in = $('#attenendance_in').val();
                var attendance_out = $('#attenendance_out').val();
                var date = $('#updateAttendace_date').val();

                if (!date) {
                    $('#updateAttendace_date_error').append(
                        '<span class="text-uppercase text-danger">date is required !</span>')
                } else {
                    $('#updateAttendace_date_error').empty()
                }

                if (!attendance_in || !attendance_out) {
                    $('#attendance_error').append(
                        '<span class="err text-uppercase text-danger">attendance required</span>');
                } else {
                    $('#attendance_error').empty()
                }

                if (attendance_in > attendance_out) {
                    $('.attendance_error').append(
                        '<span class="err text-uppercase text-danger">check out should not be greater than check in </span>'
                    );
                } else {
                    $('.attendance_error').empty()
                }

                if ($('.err').length == 0) {
                    $.ajax({
                        url: "<?php echo e(route('staff.update_attendance')); ?>",
                        data: {
                            id: attendance_id,
                            attendance_in: attendance_in,
                            attendance_out: attendance_out,
                        },
                        type: 'POST',
                        success: function(data) {
                            if (data.success) {
                                swal({
                                    title: 'ATTENDANCE UPDATED',
                                    icon: 'success'
                                }).then(function() {
                                    location.reload();
                                });
                            }
                        }
                    })
                }


            })

            //SEARCH 
            $('#search_attendance').on('click', function(e) {
                var date = $('#start_date').val()
                var inputDate = moment(date, "YYYY-MM-DD"); // Assuming "data" is "2023-10-04"
                var isValidFormat = moment(date, "YYYY-MM-DD", true).isValid();
                var maxDate = moment().format("YYYY-MM-DD");
                console.log(maxDate);
                if(isValidFormat && inputDate.isSameOrBefore(maxDate, "day")){
                    var date_check = date ? date : 0;
                }else{
                    swal({
                        title:'Wrong Format!',
                        text:'Date should be today or less',
                        icon:'warning'
                    });
                    return;
                }
                table.ajax.url("<?php echo e(route('satff.get_attendance_search')); ?>?date=" + date_check).load();
            })

            //clear date
            $('#clear_attendance').on('click', function(e) {
                $('#start_date').val('')
            })

            $('#attendance-list tbody').on('click', '.check_in', function() {
                // Get the td element that was clicked
                var td = $(this);
                var attendance = table.row(this).data();
                var attenadance_out = attendance.attendance_out;
                var date = attendance.date;
                var staff_id = attendance.staff_id;
                var intital_check_in = attendance.attenadance_in ? attendance.attenadance_in : '';

                // Get the current check-in
                var checkInValue = $(this).text();

                var convertedTime = moment(checkInValue, 'hh:mm A').format('HH:mm');

                // Create two new input elements with type="time" and set their values to the current check-in
                var checkInInput = $('<input type="time">').val(convertedTime);

                // Append the input elements to the td element
                td.empty().append(checkInInput);

                // Set the focus to the check-in input element
                checkInInput.focus();

                // Add a blur event listener to both input elements
                checkInInput.blur(function() {
                    var check_out = moment(attenadance_out, 'hh:mm A').format('HH:mm')
                    // Get the new values of the input elements
                    var newCheckInValue = moment(checkInInput.val(), 'hh:mm A').format('HH:mm');
                    // Get the attendance ID for the row
                    var attendanceId = attendance.id;
                    console.log(check_out);
                    if (check_out > newCheckInValue) {
                        $.ajax({
                            url: "<?php echo e(route('staff.update_check_in_out')); ?>",
                            type: 'POST',
                            data: {
                                attendance_id: attendanceId,
                                new_check_in_value: newCheckInValue,
                                date: date,
                                staff_id: staff_id,
                                check_in: 1
                            },
                            success: function(response) {
                                if (response.success) {
                                    var new_in = response.data.attendance_in;
                                    var converted_in = moment(new_in, 'HH:mm').format(
                                        'h:mm A');
                                    // Replace the input elements with new td elements containing the updated values
                                    var newTd = $('<td>').addClass('check_in').text(
                                            converted_in)
                                        .data('check-in', converted_in)
                                        .data('attendance-id', response.data.id);
                                    td.replaceWith(newTd);
                                    var date = $('#start_date').val()
                                    var date_check = date ? date : 0;
                                    table.ajax.url(
                                        "<?php echo e(route('satff.get_attendance_search')); ?>?date=" +
                                        date_check).load();
                                }

                            },
                            error: function(xhr, status, error) {
                                console.log(xhr.responseText);
                            }
                        });
                    } else {
                        swal({
                            title: 'WARNING!',
                            text: 'Empty CheckIn! Or CheckIn should be less than CheckOut',
                            icon: 'warning'
                        });
                        td.text(intital_check_in)
                        return
                    }
                    // Send an AJAX request to update the check-in and check-out times

                });
            });

            $('#attendance-list tbody').on('click', '.check_out', function() {
                // Get the td element that was clicked
                var td = $(this);
                var attendance = table.row(this).data();
                var attenadance_in = attendance.attendance_in;
                var initial_check_out = attendance.attendance_out;
                console.log({
                    attenadance_in
                });
                // Get the current check-in
                var checkOutValue = $(this).text();
                var convertedTime = moment(checkOutValue, 'hh:mm A').format('HH:mm');
                // Create two new input elements with type="time" and set their values to the current check-in
                var checkOutInput = $('<input type="time">').val(convertedTime);
                // Append the input elements to the td element
                td.empty().append(checkOutInput);
                // Set the focus to the check-in input element
                checkOutInput.focus();
                // Add a blur event listener to both input elements
                checkOutInput.blur(function() {
                    var check_in = moment(attenadance_in, 'hh:mm A').format('HH:mm')
                    // Get the new values of the input elements
                    var newCheckOutValue = moment(checkOutInput.val(), 'hh:mm A').format('HH:mm');
                    // Get the attendance ID for the row
                    var attendanceId = attendance.id;
                    console.log({
                        newCheckOutValue
                    });
                    if (check_in < newCheckOutValue) {
                        $.ajax({
                            url: "<?php echo e(route('staff.update_check_in_out')); ?>",
                            type: 'POST',
                            data: {
                                attendance_id: attendanceId,
                                new_check_out_value: newCheckOutValue,
                                check_in: 0
                            },
                            success: function(response) {
                                if (response.success) {
                                    console.log(response);
                                    var new_out = response.data.attendance_out;
                                    var converted_out = moment(new_out, 'HH:mm').format(
                                        'h:mm A');
                                    // Replace the input elements with new td elements containing the updated values
                                    var newTd = $('<td>').addClass('check_in').text(
                                            converted_out)
                                        .data('check-in', converted_out)
                                        .data('attendance-id', response.data.id);
                                    td.replaceWith(newTd);
                                    var date = $('#start_date').val()
                                    var date_check = date ? date : 0;
                                    table.ajax.url(
                                        "<?php echo e(route('satff.get_attendance_search')); ?>?date=" +
                                        date_check).load();
                                }
                            },
                            error: function(xhr, status, error) {
                                console.log(xhr.responseText);
                            }
                        });
                    } else {
                        swal({
                            title: 'WARNING!',
                            text: 'Empty CheckOut! Or CheckOut should be greater than CheckIn',
                            icon: 'warning'
                        });
                        td.text(initial_check_out)
                        return
                    }
                });
            });


        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/staff/show_attendance.blade.php ENDPATH**/ ?>