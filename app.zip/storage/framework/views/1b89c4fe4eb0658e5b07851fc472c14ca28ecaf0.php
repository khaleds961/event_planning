
<button class="btn btn-primary p-2 payment_button" data-bs-toggle="modal" data-bs-target="#paymentModal" 
    data-id="<?php echo e($row->id); ?>"
    data-type-id="<?php echo e($row->type_id); ?>" 
    data-staff-id="<?php echo e($row->staff_id); ?>" 
    data-expense-id="<?php echo e($row->expense_id); ?>" 
    data-in-expense="<?php echo e($row->in_expense); ?>"
    >
    <i class="ti ti-circle-plus"></i>
    Add New Payment
</button>
<?php /**PATH C:\Xampp\htdocs\sportciety_club\resources\views/expense_history/storepayment.blade.php ENDPATH**/ ?>