<div>Dear <strong><?php echo e($player_name); ?></strong>,

    We're excited to have you join us at Sportciety !
    <p>
        Your new account has been created and is now ready for you to use.
    </p>

    <p>You can login to your "Sporciety" account with the below credentials:</p>
    <p><strong>Email: <?php echo e($email); ?></strong></p>
    <p><strong>Password: <?php echo e($password); ?> </strong></p>
    <br />
    Best Regards, <br />
    <strong>The Sporciety Team.</strong>
<?php /**PATH C:\Xampp\htdocs\sportciety_club\resources\views/layouts/emails/email.blade.php ENDPATH**/ ?>