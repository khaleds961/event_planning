<?php if($row->date < $today): ?>
    <div></div>
<?php else: ?>
    <?php if($row->status == 0): ?>
        <div>
            <span style="cursor:pointer" data-id="<?php echo e($row->id); ?>" class="mx-2 text-success confirm_booking">
                <i class="ti ti-check"></i>
            </span>
            <span style="cursor:pointer" data-id="<?php echo e($row->id); ?>" class="mx-2 text-danger reject_booking">
                <i class="ti ti-x"></i>
            </span>
        </div>
    <?php elseif($row->status == 1): ?>
        <div>
            <span style="cursor:pointer" data-id="<?php echo e($row->id); ?>" class="mx-2 text-danger reject_booking">
                <i class="ti ti-x"></i>
            </span>
        </div>
    <?php else: ?>
        <div></div>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/booking/change_status.blade.php ENDPATH**/ ?>