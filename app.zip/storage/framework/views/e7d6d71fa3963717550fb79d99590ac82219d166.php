

<a type="button" class="btn mb-1 waves-effect waves-light btn-rounded btn-light-success text-success"
    href="<?php echo e(route('permission.show', ['id' => $id])); ?>">
    Permissions
</a>
<?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/permissions/permission_button.blade.php ENDPATH**/ ?>