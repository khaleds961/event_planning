<?php if(Helper::check_permission(config('permissions.bookings'), 'is_update')): ?>
    <?php if($status == 0): ?>
        <span
            class="badge bg-light-warning rounded-3 py-2 text-warning fw-semibold fs-2 d-inline-flex 
        align-items-center gap-1 ">pending</span>
    <?php elseif($status == 1): ?>
        <span
            class="badge bg-light-success rounded-3 py-2 text-success fw-semibold fs-2 d-inline-flex align-items-center 
            gap-1"
            data-id="<?php echo e($booking_id); ?>">
            confirmed</span>
    <?php else: ?>
        <span
            class="badge bg-light-danger rounded-3 py-2 text-danger fw-semibold fs-2 d-inline-flex align-items-center 
            gap-1"
            data-id="<?php echo e($booking_id); ?>">
            rejected
        </span>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\Xampp\htdocs\sportciety_club\resources\views/booking/action.blade.php ENDPATH**/ ?>