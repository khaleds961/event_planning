
<?php $__env->startSection('title', 'Client Reservations'); ?>
<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <div class="d-md-flex justify-content-between">
            <ol class="breadcrumb border border-warning px-3 py-2 rounded">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                            class="ti ti-home fs-4 mt-1"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('clients.index')); ?>" class="text-warning">Clients</a>
                </li>
                <li class="breadcrumb-item">
                    <a href="#" class="text-primary"><?php echo e($client_name); ?></a>
                </li>
            </ol>
        </div>
    </nav>


    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="my-2">

                        <div class="table-responsive">
                            <table id="clientReservations"
                                class="table border table-striped table-bordered display text-nowrap">
                                <thead>
                                    <!-- start row -->
                                    <tr>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">#reservation id</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">date</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">court</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">from</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">to</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">status</h6>
                                        </th>
                                    </tr>
                                    <!-- end row -->
                                </thead>
                                <tbody>
                                    <!-- start row -->
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                            </table>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var client_id = "<?php echo e($id); ?>";
            var URL = "<?php echo e(url('')); ?>"
            var table = $('#clientReservations').DataTable({
                processing: true,
                serverSide: true,
                responsive: true,
                ajax: URL + '/clients/clientbookings/id=' + client_id + '',
                columns: [{
                        data: 'id',
                        name: 'id',
                    },
                    {
                        data: 'date',
                        name: 'date',
                    },
                    {
                        data: 'title_en',
                        name: 'title_en',
                        searchable:false
                    },
                    {
                        data: 'time_from',
                        name: 'time_from',
                    },
                    {
                        data: 'time_to',
                        name: 'time_to',
                    },
                    {
                        data: 'status',
                        name: 'status',
                        className:'text-center'
                    }
                ],
                order: [1, 'desc'],
            });


        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sportcietyapp/public_html/platform.sportcietyapp.com/resources/views/clients/clientReservations.blade.php ENDPATH**/ ?>