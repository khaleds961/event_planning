
<?php $__env->startSection('title', 'Staff'); ?>
<?php $__env->startSection('content'); ?>
    
    <nav aria-label="breadcrumb" class="mb-1">
        <div class="d-md-flex justify-content-between">
            <ol class="breadcrumb border border-warning px-3 py-2 rounded">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                            class="ti ti-home fs-4 mt-1"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="#" class="text-warning">Staff</a>
                </li>
            </ol>

            <div>
                <a type="button" class="btn my-2 my-md-0 mb-1 waves-effect waves-light btn-light text-dark fs-3"
                    href="<?php echo e(route('staff.storepage')); ?>">
                    <i class="ti ti-circle-plus"></i>
                    <span>Add New Member</span>
                </a>

                

                <a type="button"
                    class="btn my-2 my-md-0 mb-1 mx-md-2 waves-effect waves-light btn-secondary text-light fs-3"
                    href="<?php echo e(route('staff.show_attendance_page')); ?>">
                    <i class="ti ti-user-check"></i>
                    <span>Attendance</span>
                </a>
            </div>
        </div>

    </nav>


    <!-- Attendance MODAL -->
    <div class="modal fade" id="attendanceModal" tabindex="-1" aria-labelledby="attendanceModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="attendanceModalLabel">
                        Attendance
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label">Staff
                                <b class="text-danger">*</b>
                            </label>
                            <div class="d-flex" style="border: 1px solid #dfe5ef; border-radius: 5px;">
                                <input type="text" id="search-input" placeholder="Search staff by name"
                                    class="form-control" style="border: none; flex: 1;">
                                <select id="user-select" class="" style="border: none; flex: 1;"></select>
                            </div>
                            <span id="user_error"></span>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Date
                                <b class="text-danger">*</b>
                            </label>
                            <input id="attendance_date" type="date" class="form-control" required />
                            <span id="attendance_date_error"></span>
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-md-6">
                            <div id="check_in"></div>
                            <div id="check_out"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer" id="add_attendance">
                </div>
            </div>
        </div>
    </div>
    <!-- Attendance MODAL -->


    <!-- UPDATE Attendance MODAL -->
    <div class="modal fade" id="updateAttendaceModal" tabindex="-1" aria-labelledby="updateAttendaceModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateAttendaceModalLabel">
                        Update Attendace: <span id="staff_full_name" class="mx-2 text-primary"></span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label">Date
                                <b class="text-danger">*</b>
                            </label>
                            <input id="updateAttendace_date" type="date" class="form-control" required />
                            <span id="updateAttendace_date_error"></span>
                        </div>
                    </div>

                    <div>
                        <div id="in_out_update" class="row mt-2"></div>
                    </div>

                    <div id="attendance_error" class="text-uppercase text-danger"></div>
                </div>
            </div>
        </div>
    </div>
    <!-- Attendance MODAL -->

    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="my-2">

                        <div class="table-responsive">
                            <table id="staff-list" class="table border table-striped table-bordered display text-nowrap">
                                <thead>
                                    <!-- start row -->
                                    <tr>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">#id</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">full name</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">username</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">position</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">birth date</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">phone</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">amount</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">payment</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">is active</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">action</h6>
                                        </th>
                                    </tr>
                                    <!-- end row -->
                                </thead>
                                <tbody>
                                    <!-- start row -->
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                            </table>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var today = moment().format('YYYY-MM-DD');
            $('#attendance_date').val(moment().format('YYYY-MM-DD')).attr('max', moment().format('YYYY-MM-DD'))

            var table = $('#staff-list').DataTable({
                processing: true,
                serverSide: true,
                // scrollY: '100%',
                // scrollX: $(window).width() <= 1400,
                // scrollCollapse: true,
                paging: true,
                responsive: true,
                ajax: "<?php echo e(route('staff.index')); ?>",
                columns: [{
                        data: 'id',
                        id: 'id'
                    },
                    {
                        data: 'name',
                        name: 'name',
                    },
                    {
                        data: 'username',
                        name: 'username',
                    },
                    {
                        data: 'position',
                        name: 'position',
                    },
                    {
                        data: 'birth_date',
                        name: 'birth_date'
                    },
                    {
                        data: 'phone',
                        name: 'phone'
                    },
                    {
                        data: 'amount',
                        name: 'amount',
                        className: "text-success"
                    },
                    {
                        data: 'payment',
                        name: 'payment',
                        className: "text-danger"
                    },
                    {
                        data: 'active',
                        name: 'active'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    }
                ],
                order: [0, 'desc'],
            });

            $(document).on('change', '#user-select', function(e) {
                check_attendance()
            })

            $(document).on('change', '#attendance_date', function(e) {
                check_attendance()
            })

            function check_attendance() {

                $('#check_in').empty();
                $('#check_out').empty();
                $('#add_attendance').empty();

                var date = $('#attendance_date').val();
                var user_id = $('#user-select').val();

                if (date && user_id) {
                    $.ajax({
                        url: "<?php echo e(route('staff.check_attendance')); ?>",
                        data: {
                            date: date,
                            staff_id: user_id
                        },
                        type: 'POST',
                        success: function(data) {

                            if (data.msg == 'no_check_in') {

                                $('#check_in').empty();
                                $('#add_attendance').empty();

                                $('#check_in').append(`
                                <label class="form-label">Check In<b class="text-danger">*</b></label>
                                <input type="time" id="check_in_time" class="form-control" required/>
                                <span id="check_in_error"></>
                                `);
                                $('#add_attendance').append(`
                                <button type="button" class="btn btn-primary" id="add_check_in">
                                <i class="ti ti-user mx-2"></i>
                                Add Check In
                                </button>
                                `);
                            } else if (data.msg == 'no_check_out') {
                                $('#check_out').empty();
                                $('#add_attendance').empty();

                                $('#check_out').append(`
                                <label class="form-label">Check Out<b class="text-danger">*</b></label>
                                <input type="time" id="check_out_time" class="form-control" required/>
                                `);
                                $('#add_attendance').append(`
                                <button type="button" class="btn btn-primary" id="add_check_out">
                                <i class="ti ti-user mx-2"></i>
                                Add Check Out
                                </button>
                                `);
                            } else {
                                $('#check_out').append(
                                    `<p class="text-uppercase text-danger">Attendance has already been added for this staff member on this date: ${date} !!</p>`
                                )
                            }
                        }
                    });
                }
            }

            $(document).on('click', '#attendance_button', function(e) {
                $('#check_out').empty()
                $('#check_in').empty()
                $('#add_attendance').empty()
                $('#search-input').val('')
                $('#user-select').empty()
            });

            $(document).on('click', '#add_check_in', function(e) {

                $('#check_in_error').empty();
                $('#attendance_date_error').empty();
                $('#user_error').empty();

                var date = $('#attendance_date').val()
                var staff_id = $('#user-select').val()
                var check_in_time = $('#check_in_time').val()

                if (date < today) {
                    $('#attendance_date_error').append(
                        '<span class="err text-uppercase text-danger">date wrong format!</span>');
                } else {
                    $('#attendance_date_error').empty();
                }

                if (!staff_id) {
                    $('#user_error').append(
                        '<span class="err text-uppercase text-danger">choosing staff is required !</span>'
                    );
                } else {
                    $('#user_error').empty();
                }

                if (!check_in_time) {
                    $('#check_in_error').append(
                        '<span class="err text-uppercase text-danger">Check In is required !</span>'
                    );
                } else {
                    $('#check_in_error').empty();
                }

                if ($('.err').length == 0) {
                    $.ajax({
                        url: "<?php echo e(route('staff.add_attendance')); ?>",
                        data: {
                            staff_id: staff_id,
                            date: date,
                            check_in_time: check_in_time,
                            check_in: true
                        },
                        type: 'POST',
                        success: function(data) {
                            if (data.success) {
                                swal({
                                    title: "CHECK IN ADDED",
                                    icon: "success",
                                });
                                $('#search-input').val('')
                                $('#user-select').empty()
                                $('#check_in').empty()
                                $('#add_attendance').empty()
                            }
                        }
                    });
                }
            })

            $(document).on('click', '#add_check_out', function(e) {
                var date = $('#attendance_date').val()
                var staff_id = $('#user-select').val()
                var check_out_time = $('#check_out_time').val()

                if (date < today) {
                    $('#attendance_date_error').append(
                        '<span class="err text-uppercase text-danger">date wrong format!</span>');
                } else {
                    $('#attendance_date_error').empty();
                }


                $.ajax({
                    url: "<?php echo e(route('staff.add_attendance')); ?>",
                    data: {
                        staff_id: staff_id,
                        date: date,
                        check_out_time: check_out_time,
                        check_out: true
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            swal({
                                title: "CHECK OUT ADDED",
                                icon: "success",
                            });
                            $('#search-input').val('')
                            $('#user-select').empty()
                            $('#check_out').empty()
                            $('#add_attendance').empty()
                        } else {
                            swal({
                                title: `CHECK OUT COULD NOT BE LESS THAN ${moment(data.check_in,'HH:mm:ss').format('h:mm A')}`,
                                icon: 'warning'
                            });
                        }
                    }
                });
            })

            $('#search-input').on('input', function() {

                $('#check_out').empty();
                $('#check_in').empty();
                $('#add_attendance').empty()

                var query = $(this).val();
                if (query.length >= 2) {
                    $.ajax({
                        url: "<?php echo e(route('staff.seacrh_staff')); ?>",
                        data: {
                            query: query
                        },
                        success: function(data) {
                            if (data.success) {
                                $('#new_member_button').css('display', 'none');
                                $('#new_member_content').css('display', 'none');
                                $('#user-select').empty();
                                $.each(data.data, function(key, user) {
                                    $('#user-select').append($('<option>', {
                                        value: user.id,
                                        text: user.full_name
                                    }));
                                });
                                check_attendance()
                            } else {
                                $('#user-select').empty();
                                $('#user-select').append($('<option>', {
                                    value: 0,
                                    text: 'no staff match'
                                }));
                                $('#new_member_button').css('display', 'block');
                            }
                        }
                    });
                }
            });

            var staff_id;
            var staff_full_name;
            $(document).on('click', '.update_attendance_icon', function() {
                $('#staff_full_name').empty()
                console.log('dd');
                staff_id = $(this).data('id')
                staff_full_name = $(this).data('full-name')
                $('#in_out_update').empty()
                $('#staff_full_name').append(staff_full_name);
                $('#updateAttendace_date').val('');
                $('#attenendance_in').val('')
                $('#attenendance_out').val('')
                $('#attendance_error').empty()
            });

            $('#updateAttendace_date').on('change', function(e) {
                $('#in_out_update').empty();
                $('#updateAttendace').empty();
                $('#attendance_error').empty();

                var date = $('#updateAttendace_date').val()

                if (staff_id && date) {
                    $.ajax({
                        url: "<?php echo e(route('staff.getstaffattendance')); ?>",
                        data: {
                            staff_id: staff_id,
                            date: date
                        },
                        type: 'POST',
                        success: function(data) {
                            if (data.success) {
                                $('#in_out_update').append(`
                            <div class="col-md-5">
                            <label for="attenendance_in" class="form-label">Check In
                                <b class="text-danger">*</b>
                            </label>
                            <input id="attenendance_in" type="time" class="form-control" required value="${data.data.attendance_in}"/>
                        </div>

                        <div class="col-md-5">
                            <label for="attenendance_out" class="form-label">Check Out
                                <b class="text-danger">*</b>
                            </label>
                            <input id="attenendance_out" type="time" class="form-control" required value="${data.data.attendance_out}" />
                            <span class="attendance_error"></span>
                        </div>

                        <div class="col-md-2 d-flex justify-content-end align-items-center mt-4" id="updateAttendace">
                    </div>


                            `);

                        $('#updateAttendace').append(`
                        <a type='button' class="btn btn-primary p-2 update_attendance" data-id="${data.data.id}">
                            <i class="ti ti-pencil"></i>
                        </a>
                        <a type='button' class="btn btn-danger p-2 mx-3 show_confirmed delete_icon" data-table_name="staff_attendance" data-id="${data.data.id}">
                            <i class="ti ti-trash"></i>
                        </a>
                        `)
                            } else {
                                $('#attendance_error').append('no attendance for this day')
                            }

                        }
                    })
                }
            });

            $(document).on('click','.update_attendance', function(e) {   
                             
                var attendance_id = $(this).data('id');
                var attendance_in = $('#attenendance_in').val();
                var attendance_out = $('#attenendance_out').val();
                var date = $('#updateAttendace_date').val();

                if (!date) {
                    $('#updateAttendace_date_error').append(
                        '<span class="text-uppercase text-danger">date is required !</span>')
                } else {
                    $('#updateAttendace_date_error').empty()
                }

                if (!attendance_in || !attendance_out) {
                    $('#attendance_error').append(
                        '<span class="err text-uppercase text-danger">attendance required</span>');
                } else {
                    $('#attendance_error').empty()
                }

                if(attendance_in > attendance_out){
                    $('.attendance_error').append(
                        '<span class="err text-uppercase text-danger">check out should not be greater than check in </span>');
                }else{
                    $('.attendance_error').empty()
                }

                if ($('.err').length == 0) {
                    $.ajax({
                        url: "<?php echo e(route('staff.update_attendance')); ?>",
                        data: {
                            id: attendance_id,
                            attendance_in: attendance_in,
                            attendance_out: attendance_out,
                        },
                        type:'POST',
                        success: function(data) {
                            if (data.success) {
                                swal({
                                    title: 'ATTENDANCE UPDATED',
                                    icon: 'success'
                                }).then(function() {
                                    location.reload();
                                });
                            }
                        }
                    })
                }


            })
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/staff/index.blade.php ENDPATH**/ ?>