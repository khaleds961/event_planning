<!--  Import Js Files -->
<script src="<?php echo e(asset('dist/libs/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/libs/simplebar/dist/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>

<!--  core files -->
<script src="<?php echo e(asset('dist/js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/app.init.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/app-style-switcher.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/sidebarmenu.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('dist/libs/prismjs/prism.js')); ?>"></script>

<!--  current page js files -->
<script src="<?php echo e(asset('dist/libs/owl.carousel/dist/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/libs/apexcharts/dist/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/dashboard.js')); ?>"></script>


<script src="<?php echo e(asset('dist/libs/select2/dist/js/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/libs/select2/dist/js/select2.min.js')); ?>"></script>



<script src="<?php echo e(asset('dist/js/apex-chart/apex.radial.init.js')); ?>"></script>
<script src="<?php echo e(asset('dist/libs/apexcharts/dist/apexcharts.min.js')); ?>"></script>



<script src="<?php echo e(asset('dist/js/apex-chart/apex.bar.init.js')); ?>"></script>





<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>

<?php echo $__env->yieldPushContent('after-scripts'); ?>
<?php /**PATH C:\Users\khaled.alhoussein\Desktop\sporciety_new\sportciety_club\resources\views/layouts/foot.blade.php ENDPATH**/ ?>