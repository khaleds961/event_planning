<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    
    <!-- Preloader -->
    <div class="preloader">
        <img src="<?php echo e(asset('images/logos/logo-black.png')); ?>" alt="loader" class="lds-ripple img-fluid" />
    </div>

    <!-- Preloader -->
    <div class="preloader">
        <img src="<?php echo e(asset('images/logos/logo-black.png')); ?>" alt="loader" class="lds-ripple img-fluid" />
    </div>

    <!--  Body Wrapper -->
    <div class="page-wrapper" id="main-wrapper" data-theme="blue_theme" data-layout="vertical" data-sidebartype="full"
        data-sidebar-position="fixed" data-header-position="fixed">

        <!-- Sidebar Start -->
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--  Sidebar End -->

        <!--  Main wrapper -->
        <div class="body-wrapper">
            <!--  Header Start -->
            <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--  Header End -->
            <div class="container-fluid">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>

    <!--  Shopping Cart -->
    <?php echo $__env->make('layouts.shopping_cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--  Mobilenavbar -->
    <?php echo $__env->make('layouts.mobilenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--  Search Bar -->
    <?php echo $__env->make('layouts.searchbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--  Customizer setting button -->
    <?php echo $__env->make('layouts.setting_button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--  Customizer Foot -->
    <?php echo $__env->make('layouts.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\khaled.alhoussein\Desktop\sporciety_new\sportciety_club\resources\views/layouts/master.blade.php ENDPATH**/ ?>