<?php if(Helper::check_permission($function_id, 'is_update')): ?>
    <a style="cursor:pointer" class="text-dark" href="<?php echo e(route('staff.update_staff_page', ['id' => $id])); ?>"
        data-id="<?php echo e($id); ?>" data-table_name="<?php echo e($table_name); ?>" data-type_name="<?php echo e($title); ?>">
        <i class="ti ti-pencil fs-6"></i>
    </a>

    
<?php endif; ?>

<?php if(Helper::check_permission($function_id, 'is_delete')): ?>
    <a class="show_confirmed text-warning delete_icon" data-id="<?php echo e($id); ?>"
        data-table_name="<?php echo e($table_name); ?>" style="cursor: pointer">
        <i class="ti ti-trash me-1 fs-6"></i>
    </a>
<?php endif; ?>

<?php if(Helper::check_permission(30, 'is_read')): ?>
<a href="<?php echo e(route('expensehistory.index',['staff_id' => $id])); ?>" class="text-dark" data-bs-toggle="tooltip" title="Expenses History">
    <i class="ti ti-moneybag fs-6"></i>
</a>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/staff/action.blade.php ENDPATH**/ ?>