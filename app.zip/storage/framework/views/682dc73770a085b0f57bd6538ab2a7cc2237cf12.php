
<?php $__env->startSection('title', 'Calendar'); ?>
<?php $__env->startSection('content'); ?>

    <?php
    if ($userdetails) {
        $currency_name = $userdetails->currency_name;
    } else {
        $currency_name = '';
    }
    ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <ol class="breadcrumb border border-warning px-3 py-2 rounded">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                        class="ti ti-home fs-4 mt-1"></i></a>
            </li>

            <li class="breadcrumb-item">
                <a href="#" class="text-warning">Schedule</a>
            </li>
        </ol>

        <div class="row my-3">
            <div class="d-md-flex">
                <div class="col-md-3">
                    <select class="form-control my-1" name="seacrch_by_id" id="seacrch_by_id">
                        <option value="0">--None--</option>
                        <?php $__currentLoopData = $courts_sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courts_sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($courts_sport->id); ?>" <?php echo e($sport_id == $courts_sport->id ? 'selected' : ''); ?>>
                                <?php echo e($courts_sport->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

            </div>
        </div>
    </nav>

    <div class="card">
        <div>
            <div class="row gx-0">
                <div class="col-lg-12">
                    <div class="p-4 calender-sidebar app-calendar">
                        <div id="calendar"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- BEGIN MODAL -->
    <div class="modal fade" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="eventModalLabel">
                        Add / Edit Booking
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-12">
                            <div class="d-flex" style="border: 2px solid orange; border-radius: 5px; padding: 5px;">
                                <input type="text" id="search-input" placeholder="Search player by name"
                                    class="form-control" style="border: none; flex: 1;">
                                <select id="user-select" class="form-control" style="border: none; flex: 1;"></select>
                            </div>
                            <span id="player_error"></span>
                        </div>

                        <div id="new_member">

                            <button type="btn" class="btn btn-primary mt-3" style="display: none"
                                id="new_member_button">
                                <span>Add New Member</span>
                                <i class="ti ti-circle-plus"></i>
                            </button>

                            <div class="p-4 border rounded mt-4" id="new_member_content" style="display: none">
                                <div class="row">
                                    <div class="col-md-6 mt-3">
                                        <label for="full_name">Full Name
                                            <b class="text-danger">*</b>
                                        </label>
                                        <input type="text" class="form-control" id="full_name" name="full_name">
                                        <span class="text-danger text-uppercase" id="full_name_error"></span>
                                    </div>

                                    <div class="col-md-6 mt-3">
                                        <label for="birth_date">Birth Date
                                            <b class="text-danger">*</b>
                                        </label>
                                        <input type="date" class="form-control" id="birth_date" name="birth_date">
                                        <span class="text-danger text-uppercase" id="birth_date_error"></span>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mt-3">
                                        <label for="email">Email
                                            <b class="text-danger">*</b>
                                        </label>
                                        <input type="text" class="form-control" id="email" name="email">
                                        <span class="text-danger text-uppercase" id="email_error"></span>
                                    </div>

                                    <div class="col-md-6 mt-3">
                                        <label for="phone_number">Phone Number
                                            <b class="text-danger">*</b>
                                        </label>
                                        <div>
                                            <input type="tel" class="form-control" name="phone_number" id="phone_number"
                                                placeholder="Phone Number" required>
                                        </div>
                                        <span id="phone_number_error" class="text-uppercase text-danger h6"></span>
                                        <span id="phone_number_valid" class="text-uppercase text-success h6"></span>
                                        <span id="phone_err" class="text-uppercase text-success h6"></span>
                                    </div>


                                </div>


                                <div>
                                    <button type="btn" class="btn btn-success mt-3" id="save_member">
                                        <span>Save</span>
                                        <i class="ti ti-device-floppy"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-6">
                            <div class="">
                                <label class="form-label">Date</label>
                                <input id="event-date" type="text" class="form-control" readonly disabled />
                                <span id="date_error"></span>
                            </div>
                        </div>

                        <input type="hidden" id="booking_id">
                        <div class="col-md-6">
                            <label class="control-label form-label">From</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1">
                                    <i class="ti ti-clock-hour-4 fs-4"></i>
                                </span>
                                <input type="time" class="form-control" aria-describedby="basic-addon1"
                                    id="event_start" readonly disabled>
                            </div>
                        </div>

                        <div class="col-md-4 mt-4">
                            <label for="sport_type" class="form-label">Sport Type</label>
                            <select class="form-control my-1" name="sport_id" id="select_sport">
                                <option disabled value="0" selected>--Select Sport--</option>
                                
                            </select>
                            <span id="sport_error"></span>
                        </div>

                        <div class="col-md-4 mt-4">
                            <label for="session_min" class="form-label">Session Minutes</label>
                            <input id="session_min" type="text" name="session_min" class="session_minutes" />
                            <span id="session_minutes_error"></span>
                            <span id="session_minutes_empty"></span>
                        </div>

                        <div class="col-md-4 mt-4" id="price_input">
                            <label class="form-label d-flex justify-content-between align-items-center">
                                <span>Price
                                    
                                </span>
                                <span id="editable_price">
                                    <i class="ti ti-pencil" style="cursor: pointer" data-bs-toggle="tooltip"
                                        title="Make Price Editable"></i>
                                </span>
                            </label>
                            <input id="court-price" type="number" class="form-control" readonly />
                            <span id="price_error"></span>
                        </div>


                        <input type="hidden" id="sport_time_url" data-sport-time="<?php echo e(route('calendar.session_time')); ?>">
                        <input type="hidden" id="get_booking_items"
                            data-url="<?php echo e(route('reservation_items.get_booking_items')); ?>">
                        <input type="hidden" id="search_url" data-url="<?php echo e(route('courtitems.search_by_court')); ?>"
                            data-link="<?php echo e(url('')); ?>">

                        <input type="hidden" data-url="<?php echo e(route('calendar.check_time')); ?>" id="check_time">
                        

                        <div class="row mt-4">
                            <div class="col-md-6">
                                <div class="d-flex align-items-center">
                                    <span class="text-dark fw-bolder text-capitalize me-3">Public</span>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input" role="switch" type="checkbox" id="private"
                                            name="private_sport">
                                    </div>
                                    <span class="text-dark fw-bolder text-capitalize ms-2">Private</span>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="d-flex align-items-center justify-content-end">
                                    <span class="text-dark fw-bolder text-capitalize me-3"></span>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input" role="switch" type="checkbox" id="has_trainer"
                                            name="has_trainer">
                                    </div>
                                    <span class="text-dark fw-bolder text-capitalize ms-2">Has Trainer</span>
                                </div>
                            </div>

                            
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-6" id="status" style="display: none">
                                <label class="form-label">Status</label>
                                <select class="form-control my-1" name="status_id" id="status_id">
                                    <option disabled value="0">Pending</option>
                                    <option value="1">Confirm</option>
                                    <option value="2">Reject</option>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Notes</label>
                                <textarea placeholder="Enter Text" class="form-control rounded h-70" name="description" id="description"></textarea>
                            </div>
                        </div>

                        <div class="col mt-4">
                            <span>Add Item(s)
                                <i class="ti ti-shopping-cart mx-2"></i>
                            </span>
                            <div class="search-container">
                                <input type="text" placeholder="Search..." class="form-control" id="search_input">
                                <div class="search-results" id="search-results"></div>
                            </div>
                            <div id="items_labels" class="row my-2">
                                <div class='col-3 text-primary text-uppercase'>name</div>
                                <div class='col-3 text-primary text-uppercase'>price</div>
                                <div class='col-3 text-primary text-uppercase'>quantity</div>
                            </div>
                            <div class="mt-3 d-none" id="plus_court_items">
                            </div>
                        </div>

                        <div class="row">
                            <div class="order-summary border rounded my-4 mx-2">
                                <div class="p-3">
                                    <h5 class="fs-5 fw-semibold mb-4">Reservation Summary</h5>
                                    <div class="d-flex justify-content-between mb-4">
                                        <p class="mb-0 fs-4">Court</p>
                                        <h6 class="mb-0 fs-4 fw-semibold">
                                            <span id="court_reservation_price"></span>
                                        </h6>
                                    </div>
                                    <div class="d-flex justify-content-between mb-4">
                                        <p class="mb-0 fs-4">Items</p>
                                        <h6 class="mb-0 fs-4 fw-semibold text-danger">
                                            <span id="items_total_price"></span>
                                        </h6>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <h6 class="mb-0 fs-4 fw-semibold">Total</h6>
                                        <h6 class="mb-0 fs-5 fw-semibold">
                                            <span id="grand_total" class="text-success"></span>
                                        </h6>
                                    </div>

                                    <div id="happy_price_container" class="d-flex justify-content-between mt-4">
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-12 d-none">
                            <div class="">
                                <label class="form-label">Enter Start Date</label>
                                <input id="event-start-date" type="text" class="form-control" />
                            </div>
                        </div>

                        <div class="col-md-12 d-none">
                            <div class="">
                                <label class="form-label">Enter End Date</label>
                                <input id="event-end-date" type="text" class="form-control" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer all_buttons">
                    <button type="button" class="btn btn-success btn-update-event" data-fc-event-public-id="">
                        Update Booking
                    </button>
                    <button type="button" class="btn btn-danger btn-recurring-event" data-fc-recurring-public-id="">
                        Recurring
                    </button>
                    <input type="hidden" data-update-booking="<?php echo e(route('calendar.updatebooking')); ?>"
                        id="update_booking">
                    <button type="button" class="btn btn-success btn-add-event"
                        data-url="<?php echo e(route('calendar.storebooking')); ?>" id="book_event"
                        data-reservation-items-url="<?php echo e(route('reservation_items.store')); ?>">
                        Add Booking
                    </button>
                    <span class="recurring_space"></span>
                </div>
            </div>
        </div>
    </div>
    <!-- END MODAL -->

    <!-- Stop Recurring MODAL -->
    <div class="modal fade" id="stopRecurringModal" tabindex="-1" aria-labelledby="stopRecurringModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="stopRecurringModalLabel">
                        Stop Recurring
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input danger check-outline outline-danger" type="radio"
                                    id="danger2-outline-radio" name="recurring_interval" value="all" checked="">
                                <label class="form-check-label" for="danger2-outline-radio">
                                    <h6>
                                        Stop All Dates
                                    </h6>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input danger check-outline outline-danger" type="radio"
                                    id="danger3-outline-radio" name="recurring_interval" value="specify">
                                <label class="form-check-label" for="danger3-outline-radio">
                                    <h6>
                                        Specify Start/End Recurring Dates
                                    </h6>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="row specify_times" style="display: none">
                        <div class="col-12">
                            <div class="mb-1">
                                <label for="datefrom" class="control-label col-form-label">FROM</label>
                                <input type="text" class="form-control datepicker" id="datefrom" />
                            </div>
                        </div>
                        <div class="col-12">
                            <div>
                                <label for="dateto" class="control-label col-form-label">TO</label>
                                <input type="text" class="form-control datepicker" id="dateto" />
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end mt-4">
                        <button class="btn btn-success stop_reccuring">Stop Recurring</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Stop Recurring MODAL -->

    
    <div class="modal fade" id="opening_hours" tabindex="-1" aria-labelledby="opening_hoursLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="opening_hoursLabel">
                        OPENING HOURS ON : <span id="day_name" class="text-danger fs-5 mx-2"></span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">

                        <div id="op_hours"></div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-bs-dismiss="modal">
                        Close
                    </button>
                </div>
            </div>
        </div>
    </div>
    

    
    <div class="modal fade" id="recurringModal" tabindex="-1" aria-labelledby="recurringModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="recurringModalLabel">
                        <span>Recurring</span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="col-md-12" id="recurring_content">
                        <div>
                            <label for="recurring_day" class="form-label">Every</label>
                            <select class="form-control my-1" name="recurring_day" id="recurring_day">
                                <option disabled value="0" selected>--Select Day--</option>
                                <option value="1">Monday</option>
                                <option value="2">Tuesday</option>
                                <option value="3">Wednesday</option>
                                <option value="4">Thursday</option>
                                <option value="5">Friday</option>
                                <option value="6">Saturday</option>
                                <option value="7">Sunday</option>
                            </select>
                            <span id="recurring_day_error"></span>
                            <span id="player_reccuring_error"></span>
                        </div>

                        <div>
                            <label class="control-label col-form-label">From</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1">
                                    <i class="ti ti-clock-hour-4 fs-4"></i>
                                </span>
                                <input type="time" class="form-control" aria-describedby="basic-addon1"
                                    value="0" id="recurring_start_time">
                            </div>
                            <span id="recurring_start_error"></span>
                        </div>

                        <div class="col-md-12 mt-4">
                            <label for="recurring_duration" class="form-label">Session Minutes</label>
                            <input id="recurring_duration" type="text" name="recurring_duration"
                                class="session_minutes" />
                            <span id="recurring_duration_error"></span>
                            <span id="recurring_duration_empty"></span>
                        </div>

                        <div>
                            <label class="control-label col-form-label">Start Date</label>
                            <input type="date" class="form-control" id="recurring_start_date">
                            <span id="recurring_start_date_error"></span>
                        </div>

                        <div>
                            <label class="control-label col-form-label">End Date</label>
                            <input type="date" class="form-control" id="recurring_end_date">
                            <span id="recurring_end_date_error"></span>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-bs-dismiss="modal">
                        Close
                    </button>
                    <button type="button" class="btn btn-success btn-add-event"
                        data-url="<?php echo e(route('calendar.storerecurring')); ?>" id="storerecurring">
                        Save
                    </button>
                </div>
            </div>
        </div>
    </div>
    

    
    <div class="modal fade" id="booked_days" tabindex="-1" aria-labelledby="booked_daysLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="booked_daysLabel">
                        Booked/Unbooked Dates: <span id="day_name" class="text-danger fs-5 mx-2"></span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div id="available_days"></div>
                        <div id="not_booked_days"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-bs-dismiss="modal">
                        Close
                    </button>
                </div>
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar-scheduler@6.1.8/index.global.min.js'></script>
    <script>
        var currency_name = "<?php echo e(' ' . $currency_name); ?>"
        var myModal = new bootstrap.Modal(document.getElementById("eventModal"));
        var myModalOpening = new bootstrap.Modal(document.getElementById("opening_hours"));
        var recurringModal = new bootstrap.Modal(document.getElementById("recurringModal"));
        var stopRecurringModal = new bootstrap.Modal(document.getElementById("stopRecurringModal"));

        $('#session_min').attr('disabled', true);
        var each_session_min = $('#session_min').val();
        var price_initial;
        var total_items_price = 0;
        var valid_number;
        var country_code;
        var court_id;
        var saveButton = document.getElementById("save_member");
        var selectedItems = [];
        var range_start = '';
        var range_end = '';
        var player_id;
        var player_name;
        var sport_id = $('#select_sport').val();
        var recurring_duration;
        var booking_id;
        // var recurring_duration = document.querySelector('#recurring_duration');


        //buttons
        var getModalAddBtnEl = document.querySelector(".btn-add-event");
        var getModalUpdateBtnEl = document.querySelector(".btn-update-event");
        var getModalRecurringBtnEl = document.querySelector(".btn-recurring-event");
        var bookedDates = new bootstrap.Modal(document.getElementById("booked_days"));

        // Initialize the intlTelInput plugin on the phone number input field
        var input = $("#phone_number");
        var phone_error = $('#phone_number_error');
        var phone_valid = $('#phone_number_valid');

        // Get the current year
        const currentYear = new Date().getFullYear();

        // Set the max and min years
        const maxYear = currentYear - 6;
        const minYear = currentYear - 80;

        const full_name = document.querySelector('#full_name');
        const full_nameValidation = document.querySelector('#full_name_error');

        const date_min = moment().set({
            year: minYear,
            month: 11, // Note that month values are zero-based
            date: 31,
        });

        const date_max = moment().set({
            year: maxYear,
            month: 11, // Note that month values are zero-based
            date: 31,
        });

        $('#birth_date').attr('min', date_min.format('YYYY-MM-DD'));
        $('#birth_date').attr('max', date_max.format('YYYY-MM-DD'));


        input.intlTelInput({
            preferredCountries: ["lb"],
            separateDialCode: true,
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.1.7/js/utils.js"
        });

        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');

            var calendarHeaderToolbar = {
                // left: "prev next addEventButton",
                left: "prev next",
                center: "title",
                right: "dayGridMonth,timeGridWeek,resourceTimeGridDay",
            };

            var calendar = new FullCalendar.Calendar(calendarEl, {
                schedulerLicenseKey: 'CC-Attribution-NonCommercial-NoDerivatives',
                initialView: 'resourceTimeGridDay',
                headerToolbar: calendarHeaderToolbar,
                selectable: true,
                selectLongPressDelay: 25,
                height: 'auto',
                // businessHours: {
                //     // days of week. an array of zero-based day of week integers (0=Sunday)
                //     daysOfWeek: [1, 2, 3, 4], // Monday - Thursday
                //     startTime: '10:00', // a start time (10am in this example)
                //     endTime: '18:00', // an end time (6pm in this example)
                // },
                selectAllow: function(selectInfo) {
                    // Get today's date
                    var today = new Date();
                    today.setHours(0, 0, 0, 0); // Set the time to midnight
                    // Get the selected start date of the event
                    var startDate = selectInfo.start;
                    // Check if the start date of the event is before today
                    if (startDate < today) {
                        // Disable selecting the event
                        return false;
                    }
                    // Allow selecting the event
                    return true;
                },
                resources: <?php echo json_encode($courts); ?>,
                events: function(fetchInfo, successCallback, failureCallback) {
                    // Make an AJAX call to fetch the events
                    $.ajax({
                        url: "<?php echo e(route('multiple.getSchedulesData')); ?>",
                        data: {
                            date_start: moment(fetchInfo.startStr).format('YYYY-MM-DD'),
                            date_end: moment(fetchInfo.endStr).format('YYYY-MM-DD'),
                        },
                        success: function(data) {
                            var events = [];
                            // Call the success callback with the events array
                            successCallback(data);
                        },
                        error: function(xhr, status, error) {
                            // Call the failure callback with the error message
                            failureCallback(error);
                        }
                    });
                },
                views: {
                    resourceTimeGridDay: {
                        allDaySlot: false, // Remove the "all day" slot from the view
                    }
                },
                select: calendarSelect,
                eventClick: calendarEventClick,
                unselect: function() {
                    console.log("unselected");
                },
            });
            calendar.render();
        });

        //select new event
        var calendarSelect = function(info) {

            court_id = info.resource._resource.id;
            $('#happy_price_container').empty()
            $('#select_sport').attr('disabled', false);
            $('#status').css('display', 'none');
            $('#day_name').empty();
            $('#op_hours').empty();
            $('#private').prop('checked', true);
            $('#ispaid_reservation').prop('checked', false);
            $('#has_trainer').prop('checked', false);
            $('#event_start').attr('disabled', true);

            total_items_price = 0;
            grand_total = 0;
            court_price = 0;
            selectedItems = [];

            //empty errors
            $('#op_hours').empty();
            $('#day_name').empty();

            $('#player_error').empty();
            $('#user-select').empty();
            $('#new_member_button').css('display', 'none')
            $('#new_member_content').css('display', 'none');
            $('#phone_number_valid').empty()
            $('#full_name').val('')
            $('#birth_date').val('')
            $('#email').val('')
            $('#phone_number').val('')
            $('#search-input').val('')
            $('textarea[name="description"]').val('')

            //reservation items
            $('#search_input').val('')
            $('#plus_court_items').empty()
            $('#court_reservation_price').text('')
            $('#items_total_price').text('')
            $('#grand_total').text('')
            $('#court-price').val('')
            $('#price_error').empty()

            $('#session_min').val('');
            $('#session_min').attr('disabled', true);
            $('#sport_error').empty();
            $("#session_minutes_error").empty();
            $('#session_minutes_empty').empty();

            //editable price
            $("#court-price").prop("readonly", true);


            var weekday = moment(info.start).day();
            var date = moment(info.start).format('YYYY-MM-DD');
            var start_time = moment(info.startStr).format('HH:mm');
            var end_time = moment(info.endStr).format('HH:mm');

            var start_time_new = moment(info.start).format("YYYY-MM-DD HH:mm:ss");
            var end_time_new = moment(info.endStr).format('YYYY-MM-DD HH:mm:ss');

            if (info.view.type != 'resourceTimeGridDay') {
                return;
            }

            $.ajax({
                url: "<?php echo e(route('calendar.check_time')); ?>",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {
                    court_id: court_id,
                    weekday: weekday == 0 ? 7 : weekday,
                    date: date,
                    time_from: start_time_new,
                    time_to: end_time_new
                },
                type: "POST",
                success: function(data) {
                    if (!data.available_time) {
                        op = data.opening_hours;
                        if (op.length == 0) {
                            swal({
                                title: "NO DATA",
                                text: 'NO DATA FOR THIS DAY !!',
                                icon: "warning",
                            });
                            return
                        }
                        if (!data.same_time_week) {
                            op.sort(function(a, b) {
                                var timeA = moment(a.opening_time, 'HH:mm:ss');
                                var timeB = moment(b.opening_time, 'HH:mm:ss');
                                if (timeA.isBefore(timeB)) {
                                    return -1;
                                } else if (timeA.isAfter(timeB)) {
                                    return 1;
                                } else {
                                    return 0;
                                }
                            });

                            day_number = data.opening_hours[0].weekday == 7 ? 0 : data.opening_hours[0]
                                .weekday;

                            $('#day_name').append(moment().day(day_number).format('dddd'));

                            var html = '<div>';
                            for (var i = 0; i < op.length; i++) {
                                var item = op[i];
                                html += '<div class="col-12 my-3 fs-5 text-primary"><b> Opening Time: ' +
                                    moment(item.opening_time, 'HH:mm:ss').format('h:mm A') + ' | ' +
                                    'Closing Time: ' + moment(item.closing_time, 'HH:mm:ss').format(
                                        'h:mm A') + '</b></div>';
                            }
                            html += '</div>';
                            $('#op_hours').append(html);
                            myModalOpening.show();
                            return
                        } else {
                            $('#day_name').append('EveryDay');
                            var html = '<div>';
                            html += '<div class="col-12 my-3 fs-5 text-primary"><b> Opening Time: ' +
                                moment(op.opening_from, 'HH:mm:ss').format('h:mm A') + ' | ' +
                                'Closing Time: ' + moment(op.opening_to, 'HH:mm:ss').format('h:mm A') +
                                '</b></div>';
                            html += '</div>';
                            $('#op_hours').append(html);
                            myModalOpening.show();
                            return
                        }
                    }
                    $('#event-date').val(date);
                    $('#event_start').val(start_time);
                    getsportsbycourt(court_id)
                    getModalAddBtnEl.style.display = "block";
                    getModalUpdateBtnEl.style.display = "none";
                    getModalRecurringBtnEl.style.display = "none";
                },
                error: function(err) {
                    console.log(err);
                }
            });
        }

        //recurring duration
        $("input[name='recurring_duration']").TouchSpin({
            buttondown_class: "btn btn-light-danger text-danger font-medium",
            buttonup_class: "btn btn-light-success text-success font-medium",
            min: 30,
            max: 300,
            step: 30
        });

        //min date 
        $('#recurring_start_date').change(function() {
            var minDate = $('#recurring_start_date').val();
            $('#recurring_end_date').val('')
            $('#recurring_end_date').attr('min', minDate);
        });

        // Add a keyup event listener to validate the phone number
        input.on("keyup change", function() {
            $('#phone_err').empty();
            // var isValid = input.intlTelInput("isValidNumber");
            var hasNonDigits = /[^\d]/.test(input.val());
            // if (isValid && !hasNonDigits) {
            if (!hasNonDigits) {
                phone_valid.html('Valid <i class="ti ti-check"></i>'); // the phone number is valid
                phone_error.html('').removeClass('err');
                valid_number = input.intlTelInput("getNumber");
                country_code = input.intlTelInput("getSelectedCountryData").dialCode;
            } else {
                phone_error.html('Not Valid X').addClass('err');
                phone_valid.html('')
            }
        });

        // function validateDateInput(dateInput) {
        //     // Convert the date input to a Date object
        //     const date = new Date(dateInput);

        //     // Check if the year is within the allowed range
        //     const year = date.getFullYear();
        //     if (year > maxYear || year < minYear) {
        //         return false;
        //     }

        //     // Check if the date is valid
        //     if (isNaN(date.getTime())) {
        //         return false;
        //     }

        //     // If all checks pass, return true
        //     return true;
        // }

        $("input[name='session_min']").TouchSpin({
            buttondown_class: "btn btn-light-danger text-danger font-medium",
            buttonup_class: "btn btn-light-success text-success font-medium",
            min: 30,
            max: 300,
            step: 30
        });

        //searching for adding a member
        $('#search-input').on('input', function() {
            var query = $(this).val();
            if (query.length >= 2) {
                $.ajax({
                    url: "<?php echo e(route('players.search')); ?>",
                    data: {
                        query: query
                    },
                    success: function(data) {
                        if (data.success) {
                            $('#new_member_button').css('display', 'none');
                            $('#new_member_content').css('display', 'none');
                            $('#user-select').empty();
                            $.each(data.data, function(key, user) {
                                $('#user-select').append($('<option>', {
                                    value: user.id,
                                    text: user.full_name
                                }));
                            });
                        } else {
                            $('#user-select').empty();
                            $('#user-select').append($('<option>', {
                                value: 0,
                                text: 'no member match'
                            }));
                            $('#new_member_button').css('display', 'block');
                        }
                    }
                });
            }
        });

        $(document).on('click', '#new_member_button', function(e) {
            $('#new_member_content').css('display', 'block');
            $('#phone_number_valid').empty()
            $('#full_name').val('')
            $('#birth_date').val('')
            $('#email').val('')
            $('#phone_number').val('')
        });

        //editable price
        $('#editable_price').on('click', function(e) {
            $("#court-price").prop("readonly", false);
        });

        //get sports by court id
        function getsportsbycourt(court_id, sport_id = 0) {

            var selected_sport_id = $('#seacrch_by_id').val();
            $('#select_sport').empty();
            $('#select_sport').append(
                `<option value="0">--Select Sport--</option>`
            )
            if (court_id != 0) {
                $.ajax({
                    url: "<?php echo e(route('multiple.getsportsbycourt')); ?>",
                    data: {
                        court_id: court_id
                    },
                    type: "POST",
                    success: function(response) {
                        if (response.success) {
                            const sports = response.data;
                            // Loop through the sports array
                            for (const sport of sports) {
                                // Create an <option> element
                                const optionElement = $('<option>');
                                // Set the value and text of the option
                                optionElement.val(sport.id);
                                optionElement.text(sport.title);
                                // Append the option to the select element
                                $('#select_sport').append(optionElement);

                                //for update modal
                                if (sport_id != 0) {
                                    $('#select_sport').val(sport_id).prop('disabled', true)
                                } else {
                                    if (selected_sport_id != 0) {
                                        $('#select_sport').val(selected_sport_id).prop('disabled', true)
                                        check_sess()
                                    }
                                }
                            }
                        }
                        myModal.show()
                    }
                })
            }
        }

        $(document).on('change', '#select_sport', function(e) {
            check_sess()
        });

        function check_sess(update = false) {
            $("#session_minutes_error").empty();
            $('#session_minutes_empty').empty();
            $('#court-price').empty();
            var sport_id = $('#select_sport').val();

            if (court_id && sport_id != 0) {
                $.ajax({
                    url: "<?php echo e(route('calendar.session_time')); ?>",
                    data: {
                        court_id: court_id,
                        sport_id: sport_id
                    },
                    type: "POST",
                    success: function(data) {
                        $("input[name='session_min']").attr("data-minutes", data.session);
                        recurring_duration = data.session;
                        $('#recurring_duration').val(recurring_duration)
                        if (!update) {
                            $('#session_min').val(data.session);
                        }
                        $('#session_min').attr('disabled', false);
                        each_session_min = data.session
                        $('#session_min').val(each_session_min);
                        price_initial = data.price
                        $('#court-price').val(price_initial.toFixed(2))
                        $('#court_reservation_price').text(price_initial.toFixed(2) + "$");
                        if (parseFloat($('#items_total_price').text())) {
                            total_items_price = parseFloat(($('#items_total_price').text()));
                        }
                        var gd_t = parseFloat(price_initial) + total_items_price;
                        $('#grand_total').text(gd_t.toFixed(2) + currency_name)
                    }
                });

            }
        }

        function check_sess_up(update = false, court_id = null, sport_id = null) {
            $("#session_minutes_error").empty();
            $('#session_minutes_empty').empty();

            if (court_id && sport_id) {
                $.ajax({
                    url: "<?php echo e(route('calendar.session_time')); ?>",
                    data: {
                        court_id: court_id,
                        sport_id: sport_id
                    },
                    type: "POST",
                    success: function(data) {
                        $("input[name='session_min']").attr("data-minutes", data.session);
                        recurring_duration = data.session;
                        if (!update) {
                            minutes.value = data.session;
                        }
                        // minutes.disabled = false;
                        each_session_min = data.session
                        price_initial = data.price
                    }
                });

            }
        }

        //price up
        $('.bootstrap-touchspin-up').on('click', function(e) {
            var sport_court_price = parseFloat($('#court-price').val())
            var duration = parseInt($('#session_min').val());

            if (each_session_min < duration) {
                if (duration < 300) {
                    sport_court_price += (price_initial * 30) / each_session_min;
                } else if (duration == 300) {
                    sport_court_price = (price_initial * 300) / each_session_min;
                }
            }
            $('#court-price').val(sport_court_price.toFixed(2))
            $('#court_reservation_price').text(sport_court_price.toFixed(2) + currency_name)
            if (parseFloat($('#items_total_price').text())) {
                total_items_price = parseFloat(($('#items_total_price').text()));
            }

            var gd_t = parseFloat(sport_court_price) + total_items_price;
            $('#grand_total').text(gd_t.toFixed(2) + currency_name)
            court_price = sport_court_price;
        })

        //price down
        $('.bootstrap-touchspin-down').on('click', function(e) {
            var sport_court_price = parseFloat($('#court-price').val())
            if (price_initial < sport_court_price) {
                sport_court_price -= (price_initial * 30) / each_session_min;
                $('#court-price').val(sport_court_price.toFixed(2))
                $('#court_reservation_price').text(sport_court_price.toFixed(2) + currency_name)
                if (parseFloat($('#items_total_price').text())) {
                    total_items_price = parseFloat(($('#items_total_price').text()).toFixed(2) + currency_name);
                }
                var gd_t = parseFloat(sport_court_price) + total_items_price;
                $('#grand_total').text(gd_t.toFixed(2) + currency_name)
                court_price = sport_court_price;
            }
        })

        //add new event
        $(document).on("click", '#book_event', function(fetchInfo) {

            $('.recurring_space').empty()
            $("#session_minutes_error").empty();
            $('#session_minutes_empty').empty();
            $('#price_error').empty();
            $('#sport_error').empty();
            $('#player_error').empty();
            $('#search-input').val('');

            var player_id = $('#user-select').val();
            var starttime = $('#event_start').val();
            var minutes = parseInt($('#session_min').val(), 10);
            var time_from = moment(starttime, 'h:mm A').format(
                'HH:mm'); // Convert the timestamp to 24-hour format
            var time_to = moment(starttime, 'h:mm A').add(minutes, 'minutes').format('HH:mm');
            var sport_id = $('#select_sport').val();
            var notes = $('textarea[name="description"]').val();
            var is_private = $('#private').is(':checked') ? 1 : 0;
            var is_paid = $('#ispaid_reservation').is(':checked') ? 1 : 0;
            var has_trainer = $('#has_trainer').is(':checked') ? 1 : 0;
            var date = $('#event-date').val();
            var book_url = $('#book_event').data('url');
            var weekday = moment(date, 'YYYY-MM-DD').day();
            var total_price = $('#court-price').val()
            var price = parseFloat(total_price);

            var dateTime_from = moment(date + ' ' + time_from).format('YYYY-MM-DD HH:mm:ss');
            var dateTime_to = moment(dateTime_from).add(minutes, 'minutes').format('YYYY-MM-DD HH:mm:ss');

            if (!player_id || player_id == 0 || player_id == null) {
                // $('#player_error').append(`<span class="text-danger text-uppercase err">player is required !!</span>`)
                player_id = 0;
            } else {
                $('#player_error').empty();
            }

            if (!isNaN(price) || price < 0) {
                $('#price_error').empty()
            } else {
                $('#price_error').append(`<span class="text-danger text-uppercase err">Price is required !!</span>`)
            }

            if (isNaN(minutes)) {
                $('#session_minutes_empty').append(
                    `<span class="text-danger text-uppercase err">fill the session duration !!</span>`)
            } else {
                $('#session_minutes_empty').empty();
            }

            if (minutes < each_session_min) {
                $('#session_minutes_error').append(
                    `<span class="text-danger text-uppercase err">The Session Duration should not be less than <b>${each_session_min}</b></span>`
                )
            } else {
                $('#session_minutes_error').empty()
            }

            if (sport_id == 0 || !sport_id) {
                $('#sport_error').append(
                    `<span class="text-danger text-uppercase err">Sport Type is required !!</span>`)
            } else {
                $('#sport_error').empty();
            }

            if ($('.err').length == 0) {
                var parameters = {
                    date,
                    court_id,
                    dateTime_from,
                    dateTime_to,
                    sport_id,
                    is_private,
                    has_trainer,
                    notes,
                    minutes,
                    price,
                    weekday,
                    player_id,
                    total_price,
                    total_items_price
                };
                checkHappyHour(parameters)
                // $.ajax({
                //     url: "<?php echo e(route('calendar.storebooking')); ?>",
                //     headers: {
                //         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                //     },
                //     data: {
                //         player_id: player_id,
                //         court_id: court_id,
                //         weekday: weekday == 0 ? 7 : weekday,
                //         date: date,
                //         time_from: dateTime_from,
                //         time_to: dateTime_to,
                //         sport_id: sport_id,
                //         is_private: is_private ? 1 : 0,
                //         is_paid: is_paid ? 1 : 0,
                //         has_trainer: has_trainer ? 1 : 0,
                //         notes: notes,
                //         duration: minutes,
                //         total_price: total_price,
                //         add_on: total_items_price,
                //     },
                //     type: "POST",
                //     success: function(data) {

                //         if (!data.available_time) {
                //             swal({
                //                 title: "Error",
                //                 text: 'THIS TIME IS ALREADY TAKEN BY ANOTHER RESERVATION, OR NOT INCLUDED IN COURT OPENING HOURS !!',
                //                 icon: "error",
                //             });
                //             return
                //         }
                //         if (data.error) {
                //             let errorString = "";
                //             for (const [key, value] of Object.entries(data.errors)) {
                //                 errorString += `${value}\n`;
                //             }
                //             swal({
                //                 title: "Error",
                //                 text: errorString,
                //                 icon: "error",
                //             });
                //             return;
                //         }

                //         if (data.data[0]['id']) {
                //             var booking_id = data.data[0]['id'];
                //             if ($('.item').length > 0) {
                //                 adds_on(booking_id, false)
                //             } else {
                //                 swal({
                //                     title: 'RESERVATION ADDED SUCCESSFULLY',
                //                     icon: 'success'
                //                 }).then(() => {
                //                     location.reload()
                //                 })
                //             }
                //         }
                //     },
                //     error: function(err) {
                //         console.log(err);
                //     }
                // });
            }else{
                $('#happy_price_container').empty()
            }

        })

        function checkHappyHour(parameters, update = false,getPublicID = '') {
            var date = $('#event-date').val()
            var weekday = moment(date).format('d');
            var booking_start = moment($('#event_start').val(), 'h:mm A').format('HH:mm:ss');
            var sport_id = $('#select_sport').val()
            var duration = $('#session_min').val()
            $.ajax({
                url: "<?php echo e(route('calendar.checkHappyHour')); ?>",
                data: {
                    weekday: weekday == 0 ? 7 : weekday,
                    booking_start: booking_start,
                    date: date,
                    court_id: parameters.court_id,
                    sport_id: sport_id,
                    duration: duration
                },
                success: function(response) {
                    if (response.success) {
                        happy_price = response.data;
                        var price_after_discount = parseFloat(response.data) + parseFloat(
                            total_items_price);
                        $('#happy_price_container').css({
                            'border': '4px solid',
                            'padding': '5px'
                        });
                        $('#happy_price_container').append(`<h6 class="mb-0 fs-4">Price After Happy Hour</h6>
                        <h6 class="mb-0 fs-5 fw-semibold">
                        <span id="happy_hour_price">${price_after_discount.toFixed(2) + currency_name}</span>
                        </h6>`);
                        if (!update) {
                            setTimeout(storeBooking(parameters, price_after_discount), 3000);
                        } else {
                            setTimeout(updateReservation(parameters, price_after_discount,getPublicID), 3000);
                        }
                    } else {
                        $('#happy_price_container').removeAttr('style');
                        $('#happy_price_container').empty()
                        happy_price = 0;
                        if (!update) {
                            storeBooking(parameters, price_after_discount);
                        } else {
                            updateReservation(parameters, price_after_discount,getPublicID);
                        }
                    }
                }
            })
        }



        function storeBooking(parameters, price_after_discount = null) {
            // Call your function here
            $.ajax({
                url: "<?php echo e(route('calendar.storebooking')); ?>",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {
                    player_id: parameters.player_id,
                    court_id: court_id,
                    weekday: parameters.weekday == 0 ? 7 : parameters.weekday,
                    date: parameters.date,
                    time_from: parameters.dateTime_from,
                    time_to: parameters.dateTime_to,
                    sport_id: parameters.sport_id,
                    is_private: parameters.is_private ? 1 : 0,
                    is_paid: parameters.is_paid ? 1 : 0,
                    has_trainer: parameters.has_trainer ? 1 : 0,
                    notes: parameters.notes,
                    duration: parameters.minutes,
                    price: price_after_discount ? price_after_discount : parameters.total_price,
                    total_price: price_after_discount ? price_after_discount : parameters.total_price,
                    add_on: parameters.total_items_price
                },
                type: "POST",
                success: function(data) {

                    if (!data.available_time) {
                        swal({
                            title: "Error",
                            text: 'THIS TIME IS ALREADY TAKEN BY ANOTHER RESERVATION, OR NOT INCLUDED IN COURT OPENING HOURS !!',
                            icon: "error",
                        });
                        $('#book_event').prop('disabled', false)
                        return
                    }
                    if (data.error) {
                        let errorString = "";
                        for (const [key, value] of Object.entries(data
                                .errors)) {
                            errorString += `${value}\n`;
                        }
                        swal({
                            title: "Error",
                            text: errorString,
                            icon: "error",
                        });
                        return;
                    }
                    if (data.data[0]['id']) {
                        var booking_id = data.data[0]['id'];
                        if ($('.item').length > 0) {
                            adds_on(booking_id, false)
                        } else {
                            swal({
                                title: 'RESERVATION ADDED SUCCESSFULLY',
                                icon: 'success'
                            }).then(() => {
                                location.reload()
                            })
                        }
                    }
                },
                error: function(err) {
                    console.log(err);
                }
            });
        }

        function updateReservation(parameters, price_after_discount = null) {
            $.ajax({
                url: "<?php echo e(route('calendar.updatebooking')); ?>",
                data: {
                    date: parameters.date,
                    id: unique_id,
                    court_id: parameters.court_id,
                    time_from: parameters.dateTime_from,
                    time_to: parameters.dateTime_to,
                    is_private: parameters.is_private ? 1 : 0,
                    is_paid:  0,
                    has_trainer: parameters.has_trainer ? 1 : 0,
                    notes: parameters.notes,
                    duration: parameters.minutes,
                    price: price_after_discount ? price_after_discount : parameters.price,
                    weekday: parameters.weekday == 0 ? 7 : parameters.weekday,
                    status: status_id.value,
                    player_id: parameters.player_id,
                    total_price: price_after_discount ? price_after_discount : parameters.total_price,
                    add_on: parameters.total_items_price,
                },
                type: "POST",
                success: function(data) {
                    if (data.available_time) {
                        adds_on(parameters.getPublicID, true)
                    } else {
                        swal({
                            title: "Error",
                            text: 'THIS TIME IS ALREADY TAKEN BY ANOTHER RESERVATION, OR NOT INCLUDED IN COURT OPENING HOURS !!',
                            icon: "error",
                        });
                        $('#book_event').prop('disabled', false)
                        return
                    }
                },
                error: function(err) {
                    console.log(err);
                }
            });
        }

        $(document).on('click', '#save_member', function(e) {

            $('#birth_date_error').empty();
            $('#email_error').empty();
            $('#phone_err').empty();

            var dateInput = $('#birth_date').val();
            var full_name = $('#full_name').val();
            var birth_date = $('#birth_date').val();
            var email = $('#email').val();
            var country_c = country_code
            var phone_number = $('#phone_number').val().replace(/\s/g, "");
            const isValid = validateDateInput(dateInput);
            const isEmailValid = isValidEmail(email);

            if (phone_number == '' || phone_number == 0 || phone_number == null) {
                $('#phone_err').append('<span class="err text-danger text-uppercase">required !!</span>');
            } else {
                $('#phone_err').empty();
            }
            fullnamecheck()

            if (isEmailValid) {
                $('#email_error').empty();
            } else {
                $('#email_error').append(
                    `<span class="err">email is invalid</span>`
                );
            }

            if (isValid) {
                $('#birth_date_error').empty();
            } else {
                $('#birth_date_error').append(
                    `<span class="err">date should not be less than ${minYear} and not more than ${maxYear}</span>`
                );
            }

            if ($('.err').length == 0) {
                saveButton.disabled = true;
                $.ajax({
                    url: "<?php echo e(route('players.check_email')); ?>",
                    data: {
                        email: email,
                        phone: phone_number
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            storeplayer(full_name, email, phone_number, country_c, birth_date)
                        } else {
                            swal({
                                title: 'EMAIL OR PHONE NUMBER IS REPEATED !',
                                icon: 'warning'
                            })
                            saveButton.disabled = false;
                        }
                    }

                })
            }
        });

        $(document).on('click', '#new_member_button', function(e) {
            $('#new_member_content').css('display', 'block');
            $('#phone_number_valid').empty()
            $('#full_name').val('')
            $('#birth_date').val('')
            $('#email').val('')
            $('#phone_number').val('')
        });

        full_name.addEventListener('keyup', function() {
            fullnamecheck()
        });

        // function fullnamecheck() {
        //     const full_nameValue = full_name.value.trim();
        //     if (full_nameValue.length > 30) {
        //         full_nameValidation.textContent = 'full name must not be longer than 30 characters';
        //         full_nameValidation.classList.add('err');
        //     } else if (full_nameValue.length < 3) {
        //         full_nameValidation.textContent = 'full name must be 3 characters or more';
        //         full_nameValidation.classList.add('err');
        //     } else {
        //         full_nameValidation.textContent = '';
        //         full_nameValidation.classList.remove('err');
        //     }
        // }

        // function isValidEmail(email) {
        //     // Regular expression pattern for matching email addresses
        //     const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        //     // Use the test() method of the pattern to check if the email address matches
        //     return pattern.test(email);
        // }

        // function storeplayer(full_name, email, phone_number, phone_code, birth_date) {
        //     $.ajax({
        //         url: "<?php echo e(route('players.store')); ?>",
        //         data: {
        //             full_name: full_name,
        //             email: email,
        //             phone_number: phone_number,
        //             phone_code: phone_code,
        //             birth_date: birth_date
        //         },
        //         type: 'POST',
        //         success: function(data) {
        //             if (data.success) {
        //                 // Get the ID of the newly created member from the response data
        //                 const newMemberId = data.player.id;

        //                 console.log(newMemberId);
        //                 // Create a new option element with the member's name and ID
        //                 const newOption = $('<option>', {
        //                     value: newMemberId,
        //                     text: full_name
        //                 });

        //                 // Append the new option to the select element
        //                 $('#user-select').append(newOption);

        //                 // Select the new option in the dropdown list
        //                 newOption.prop('selected', true);

        //                 swal({
        //                     title: "NEW PLAYER ADDED SUCCESSFULLY",
        //                     icon: "success"
        //                 });
        //                 $('#new_member_button').css('display', 'none')
        //                 $('#new_member_content').css('display', 'none');
        //                 $('#phone_number_valid').empty()
        //                 $('#full_name').val('')
        //                 $('#birth_date').val('')
        //                 $('#email').val('')
        //                 $('#phone_number').val('')
        //                 $('#search-input').val('')
        //                 saveButton.disabled = false;
        //             }
        //         }
        //     })
        // }

        var checkWidowWidth = function() {
            if (window.innerWidth <= 1199) {
                return true;
            } else {
                return false;
            }
        };

        $('.search-container input').on('input', function() {
            var query = $(this).val().trim();

            if (query.length > 0) {
                $.ajax({
                    url: "<?php echo e(route('courtitems.search_by_court')); ?>",
                    data: {
                        name: query,
                        id: court_id
                    },
                    type: "POST",
                    success: function(data) {
                        var results = $('.search-results');
                        results.empty();
                        if (data.data.length > 0) {
                            for (var i = 0; i < data.data.length; i++) {
                                var item = data.data[i];
                                var li = $('<li style="list-style: none;" class="my-2">');
                                var text_image = item.img == null ?
                                    'images/courts/no-image.png' : item
                                    .img;
                                var img = $('<img width="50" height="50">').attr('src',
                                    "<?php echo e(url('')); ?>" + "/" +
                                    text_image);
                                var title = $('<span class="item_name mx-3">').text(item
                                    .name);
                                var price = $('<span class="mx-3 item_price">').text(item.price)
                                var item_id = item.item_id;

                                // Use a closure to capture the correct value of item_id
                                (function(item_id) {
                                    li.on('click', function() {
                                        if (selectedItems.includes(item_id)) {
                                            li.addClass('disabled');
                                            $('#search_input').val('')
                                            results.hide()
                                            return
                                        } else {
                                            $('#search_input').val('')
                                            var title = $(this).find('.item_name')
                                                .text();
                                            var price_i = $(this).find('.item_price')
                                                .text();
                                            $('#plus_court_items').removeClass(
                                                'd-none')
                                            $('#plus_court_items').append(`
                            <div class="row mb-2 px-1 item d-flex align-items-center">
                                <div class="col-3">
                                    ${title}
                                    </div>
                                <div class="col-3">
                                    <input class="price_item form-control" value="${price_i}" type="number">
                                    <input class="id" type="hidden" value="${item_id}"/>
                                </div>
                                <div class="col-3">
                                    <input value="1" type="number" class="qty_hour form-control"/>
                                </div>
                                <div class="col-3">
                                    <i class="ti ti-trash fs-3 text-danger cursor-pointer"></i>
                                </div>
                            </div>
                        `)
                                            // Add the item to the selectedItems array and disable the li element
                                            selectedItems.push(item_id);
                                            $(this).addClass('disabled');
                                            results.hide();
                                            total_items_price += parseFloat(price_i);
                                            $('#items_total_price').text((total_items_price)
                                                .toFixed(2) + currency_name)
                                            if ($('#court_reservation_price').text()) {
                                                court_price = $('#court_reservation_price')
                                                    .text();
                                            } else {
                                                court_price = 0;
                                            }
                                            grand_total = parseFloat(total_items_price) +
                                                parseFloat(court_price);
                                            $('#grand_total').text(grand_total.toFixed(2) +
                                                currency_name)
                                        }
                                    });
                                })(item_id);
                                li.append(img);
                                li.append(title);
                                li.append(price);
                                results.append(li);
                            }
                            results.show();
                        } else {
                            results.hide();
                        }
                    }
                })
            } else {
                $('.search-results').hide();
            }
        });

        $(document).on('input change', '.qty_hour', function(e) {
            var total_price = 0;
            if ($('#court-price').val()) {
                court_price = parseFloat($('#court-price').val());
            } else {
                court_price = 0;
            }
            var value = parseInt($(this).val());
            if (value < 1 || isNaN(value)) {
                $(this).val(1);
                return;
            }
            $('.item').each(function() {
                var price = parseFloat($(this).find('.price_item').val());
                var quantity = parseInt($(this).find('.qty_hour').val());
                var item_price = parseFloat(price) * parseInt(quantity);
                total_price += parseFloat(item_price);
            });
            $('#items_total_price').text(total_price.toFixed(2) + currency_name)
            grand_total = total_price + court_price;
            $('#grand_total').text(grand_total.toFixed(2) + currency_name)
            total_items_price = total_price;
        });

        $(document).on('input change', '.price_item', function(e) {
            var total_price = 0;
            if ($('#court-price').val()) {
                court_price = parseFloat($('#court-price').val());
            } else {
                court_price = 0;
            }
            var value = parseInt($(this).val());
            if (value < 0 || isNaN(value)) {
                $(this).val(0);
                return;
            }
            $('.item').each(function() {
                var price = parseFloat($(this).find('.price_item').val());
                var quantity = parseInt($(this).find('.qty_hour').val());
                var item_price = parseFloat(price) * parseInt(quantity);
                total_price += parseFloat(item_price);
            });
            $('#items_total_price').text(total_price.toFixed(2) + currency_name)
            grand_total = total_price + court_price;
            $('#grand_total').text(grand_total.toFixed(2) + currency_name)
            total_items_price = total_price;
        });

        function adds_on(booking_id, update = false) {
            // create an empty array to hold the items
            var items = [];
            // loop through each div element with the "item" class
            $(".item").each(function() {
                // get the name and price from the span elements in the div element
                var item_id = $(this).find(".id").val();
                var price = $(this).find(".price_item").val();
                var qty_hour = $(this).find('.qty_hour').val();

                // create an object with the name and price properties
                var item = {
                    item_id: item_id,
                    price: price,
                    qty_hour: qty_hour,
                    update: update
                };
                // add the object to the items array
                items.push(item);
            });
            // send the array of objects to the back end using AJAX
            $.ajax({
                url: "<?php echo e(route('reservation_items.store')); ?>",
                type: "POST",
                data: {
                    items: items,
                    booking_id: booking_id,
                    update: update
                },
                success: function(response) {
                    if (response.success) {
                        swal({
                            title: 'RESERVATION ADDED SUCCESSFULLY',
                            icon: 'success'
                        }).then(() => {
                            location.reload()
                        })
                    } else {
                        swal({
                            title: 'RESERVATION UPDATED SUCCESSFULLY',
                            icon: 'success'
                        }).then(() => {
                            location.reload()
                        })
                        // myModal.hide()
                    }
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText);
                }
            });
        }

        var unique_id;
        //previous events
        //click previous event
        var calendarEventClick = function(info) {
            console.log({
                info
            });
            
            $('.recurring_space').empty()
            $('#sport_error').empty();
            $('#price_error').empty();
            $('#player_error').empty();
            $('#user-select').empty();
            $('#new_member_button').css('display', 'none')
            $('#new_member_content').css('display', 'none');
            $('#phone_number_valid').empty()
            $('#full_name').val('')
            $('#birth_date').val('')
            $('#email').val('')
            $('#phone_number').val('')
            $('#search-input').val('')
            //reservation items
            $('#search_input').val('')
            $('#plus_court_items').empty()
            $('#court-price').text('')
            $('#court_reservation_price').text('')
            $('#items_total_price').text('')
            $('#grand_total').text('')
            //editable price
            $("#court-price").prop("readonly", true);

            var player_id;
            var eventObj = info.event;
            var start_time = moment(info.startStr).format('HH:mm');
            $('#event_start').val(start_time).prop('disabled', false).prop('readonly', false);

            if (eventObj.url) {
                window.open(eventObj.url);
                info.jsEvent.preventDefault();
            } else {
                var is_recurring = eventObj._def.extendedProps['is_recurring'];
                if (is_recurring) {
                    $('.recurring_space').append(`<button type="button" class="btn btn-warning" id="stop_recurring" data-stop-recurring="${eventObj._def.extendedProps['reference_id']}">
                        Stop Recurring
                    </button>`);
                } else {
                    $('.recurring_space').empty()
                }
                const sport_id = eventObj._def.extendedProps['sport_id'];
                var court_price = (eventObj._def.extendedProps['price']).toFixed(2);
                var total_court_price = (eventObj._def.extendedProps['total_price']).toFixed(2);
                var getModalEventId = eventObj._def.publicId;
                court_id = eventObj._def.extendedProps['court_id'];
                unique_id = info.event._def.extendedProps.booking_id;
                get_booking_items(getModalEventId)
                check_sess_up(true, eventObj._def.extendedProps['court_id'], sport_id)
                document.querySelector("#session_minutes_error").innerHTML = "";
                $('#session_min').attr('disabled', false);
                $('#event_start').attr('disabled', false);
                var orginal_price_per_session = (eventObj._def.extendedProps['minutes'] * eventObj._def.extendedProps['court_original_price']) / eventObj._def.extendedProps['court_original_session'];
                $('#court-price').val(orginal_price_per_session)
                // $('#court-price').val(total_court_price)
                $('#court_reservation_price').text(total_court_price + currency_name);
                $('#event-date').val(eventObj._def.extendedProps['event_date'])
                $('#event_start').val(eventObj._def.extendedProps['event_start_time']);
                range_start = eventObj._instance.range.start;
                range_end = eventObj._instance.range.end;
                getsportsbycourt(eventObj._def.extendedProps['court_id'], eventObj._def.extendedProps['sport_id'])
                $('#session_min').val(eventObj._def.extendedProps['minutes']);
                $('#status').css('display', 'block');
                $('#status_id').val(eventObj._def.extendedProps['status']);
                booking_id = eventObj._def.extendedProps['booking_id']  
                player_id = eventObj._def.extendedProps['player_id'];
                player_name = eventObj._def.extendedProps['player_name'];
                $('#recurring_start_date').attr('min', eventObj._def.extendedProps['event_date']);

                if (eventObj._def.extendedProps['status'] == 2) {
                    $('#status_id').attr('disabled', true)
                } else {
                    $('#status_id').attr('disabled', false)
                }

                if (eventObj._def.extendedProps['is_private'] == 1) {
                    $('#private').attr('checked', true);
                } else {
                    $('#private').attr('checked', false)
                }

                if (eventObj._def.extendedProps['is_paid'] == 1) {
                    $('#ispaid_reservation').attr('checked', true)
                } else {
                    $('#ispaid_reservation').attr('checked', false)
                }

                if (eventObj._def.extendedProps['has_trainer'] == 1) {
                    $('#has_trainer').attr('checked', true)
                } else {
                    $('#has_trainer').attr('checked', false)
                }

                var grand_total_ = eventObj._def.extendedProps['the_grand_total'] ? (eventObj._def.extendedProps[
                        'the_grand_total']).toFixed(2) + currency_name :
                    total_court_price + currency_name;
                $('#description').val(eventObj._def.extendedProps['description']);
                $('#items_total_price').text(eventObj._def.extendedProps['adds_on_total'].toFixed(2) + currency_name);
                $('#grand_total').text(grand_total_);
                total_items_price = eventObj._def.extendedProps['adds_on_total'];

                getModalUpdateBtnEl.setAttribute(
                    "data-fc-event-public-id",
                    getModalEventId
                );

                getModalUpdateBtnEl.setAttribute(
                    'data-court_id', eventObj._def.extendedProps['court_id']
                );

                // $('.btn-update-event').data('court_id',court_id)

                getModalRecurringBtnEl.setAttribute(
                    "data-fc-recurring-public-id",
                    getModalEventId
                );

                const newOption = $('<option>', {
                    value: player_id,
                    text: player_name
                });

                // Append the new option to the select element
                $('#user-select').append(newOption);
                // Select the new option in the dropdown list
                newOption.prop('selected', true);

                getModalAddBtnEl.style.display = "none";
                if (eventObj._def.extendedProps['event_date'] < moment().format('YYYY-MM-DD')) {
                    getModalUpdateBtnEl.style.display = "none";
                    getModalRecurringBtnEl.style.display = "none";
                } else {
                    getModalUpdateBtnEl.style.display = "block";
                    getModalRecurringBtnEl.style.display = "block";
                }

            }
        };

        var recurring_id;
        var recurring_type;

        $(document).on('click', '#stop_recurring', function(e) {
            recurring_id = $(this).data('stop-recurring');
            myModal.hide();
            stopRecurringModal.show();
        });

        $(document).on('click', '.stop_reccuring', function(e) {
            var recurring_type = $('input[name="recurring_interval"]:checked').val();
            $('.stop_recurring').prop('disabled', true);
            if (recurring_id) {
                stop_recurring(recurring_id, recurring_type);
            }
        })


        function stop_recurring(recurring_id, recurring_type) {
            var datefrom = $('#datefrom').val();

            if (datefrom) {
                var formatted_from = moment(datefrom, 'MM/DD/YYYY').format('YYYY-MM-DD');
            } else {
                var formatted_from = '';
            }

            var dateto = $('#dateto').val();
            if (dateto) {
                var formatted_to = moment(dateto, 'MM/DD/YYYY').format('YYYY-MM-DD');
            } else {
                var formatted_to = '';
            }

            $.ajax({
                url: "<?php echo e(route('calendar.stoprecurring')); ?>",
                data: {
                    reference_id: recurring_id,
                    recurring_type: recurring_type,
                    datefrom: formatted_from,
                    dateto: formatted_to
                },
                type: 'POST',
                success: function(data) {
                    if (data.success) {
                        swal({
                            title: 'Success',
                            text: data.msg,
                            icon: 'success'
                        }).then(() => {
                            location.reload()
                        });
                        return;
                    } else {
                        swal({
                            text: data.msg,
                            icon: 'warning'
                        });
                        $('.stop_recurring').prop('disabled', false);
                    }
                }
            });
        }

        $(document).on('change', 'input[name="recurring_interval"]', function(e) {
            var recurring_type = $('input[name="recurring_interval"]:checked').val();
            if (recurring_type != 'all') {
                $('.specify_times').css('display', 'block')
            } else {
                $('.specify_times').css('display', 'none')
            }
        });

        function get_booking_items(booking_id) {
            $.ajax({
                url: "<?php echo e(route('reservation_items.get_booking_items')); ?>",
                data: {
                    booking_id: booking_id
                },
                success: function(data) {
                    if (data.length > 0) {
                        $('#plus_court_items').removeClass(
                            'd-none')
                        for (let index = 0; index < data.length; index++) {
                            const element = data[index];
                            selectedItems.push(element.item_id);
                            $('#plus_court_items').append(`
              <div class="row mb-2 px-1 item d-flex align-items-center">
                  <div class="col-3">
                      ${element.name}
                      </div>
                  <div class="col-3">
                      <input class="price_item form-control" value="${element.price}" type="number"/>
                      <input class="id" type="hidden" value="${element.item_id}"/>
                  </div>
                  <div class="col-3">
                      <input value="${element.qty_hour}" type="number" class="qty_hour form-control"/>
                  </div>
                  <div class="col-3">
                      <i class="ti ti-trash fs-3 text-danger cursor-pointer"></i>
                  </div>
              </div>
              `)
                        }
                    }
                }
            })
        }

        // Add a click event listener to the trash icon
        $('#plus_court_items').on('click', '.ti-trash', function() {
            // Get the parent element of the trash icon
            var item = $(this).closest('.item');
            // Get the ID of the item from the hidden input field
            var item_id = item.find('.id').val();
            var item_price = item.find('.price_item').val()
            var item_qty = item.find('.qty_hour').val()
            var each_item_total = item_price * item_qty;
            if ($('#court-price').val()) {
                court_price = parseFloat($('#court-price').val())
            } else {
                court_price = 0;
            }
            // Remove the item from the selectedItems array
            var index = selectedItems.indexOf(parseInt(item_id));
            if (index > -1) {
                selectedItems.splice(index, 1);
                // Remove the item from the DOM
                item.remove();
                total_items_price -= parseFloat(each_item_total);
                $('#items_total_price').text(total_items_price + currency_name)
                grand_total = parseFloat(total_items_price) +
                    parseFloat(court_price);
                $('#grand_total').text(grand_total + currency_name)
            }
        });

        //update previous event
        getModalUpdateBtnEl.addEventListener("click", function() {

            var getPublicID = $(this).data('fc-event-public-id');
            var court_id = $(this).data('court_id');
            var starttime = $('#event_start').val();
            var minutes = parseInt($('#session_min').val(), 10);
            var time_from = moment(starttime, 'h:mm A').format(
                'HH:mm:ss'); // Convert the timestamp to 24-hour format
            var time_to = moment(starttime, 'h:mm A').add(minutes, 'minutes').format('HH:mm:ss');
            var notes = $('textarea[name="description"]').val();
            var is_private = $('#private').is(':checked') ? 1 : 0;
            var is_paid = $('#ispaid_reservation').is(':checked') ? 1 : 0;
            var has_trainer = $('#has_trainer').is(':checked') ? 1 : 0;
            var price = $('#court-price').val();
            var date = $('#event-date').val();
            var weekday = moment(date, 'YYYY-MM-DD').day();
            var player_id = $('#user-select').val()
            var total_price = $('#court-price').val()
            var dateTime_from = moment(date + ' ' + time_from).format('YYYY-MM-DD HH:mm:ss');
            var dateTime_to = moment(dateTime_from).add(minutes, 'minutes').format('YYYY-MM-DD HH:mm:ss');

            if (player_id == 0 || player_id == '' || player_id == null) {
                // $('#player_error').append(`<span class="text-danger text-uppercase err">player required !!</span>`)
                player_id = 0;
            } else {
                $('#player_error').empty()
            }

            if (isNaN(minutes)) {
                $('#session_minutes_empty').append(
                    `<span class="text-danger text-uppercase err">fill the session duration !!</span>`)
            } else {
                $('#session_minutes_empty').empty();
            }

            if (minutes < each_session_min) {
                $('#session_minutes_error').append(
                    `<span class="text-danger text-uppercase err">The Session Duration should not be less than <b>${each_session_min}</b></span>`
                )
            } else {
                $('#session_minutes_error').empty()
            }


            if (price > 0) {
                $('#price_error').empty()
            } else {
                $('#price_error').append(
                    `<span class="text-danger text-uppercase err">Price is required !!</span>`)
            }

            if ($('.err').length == 0) {
                var parameters = {
                    date,
                    unique_id,
                    court_id,
                    dateTime_from,
                    dateTime_to,
                    is_private,
                    has_trainer,
                    notes,
                    minutes,
                    price,
                    weekday,
                    player_id,
                    total_price,
                    total_items_price,
                    getPublicID
                }
                checkHappyHour(parameters,update=true)
                // $.ajax({
                //     url: "<?php echo e(route('calendar.updatebooking')); ?>",
                //     data: {
                //         date: date,
                //         id: unique_id,
                //         court_id: court_id,
                //         time_from: dateTime_from,
                //         time_to: dateTime_to,
                //         is_private: is_private ? 1 : 0,
                //         is_paid: is_paid ? 1 : 0,
                //         has_trainer: has_trainer ? 1 : 0,
                //         notes: notes,
                //         duration: minutes,
                //         price: price,
                //         weekday: weekday == 0 ? 7 : weekday,
                //         status: status_id.value,
                //         player_id: player_id,
                //         total_price: total_price,
                //         add_on: total_items_price,
                //     },
                //     type: "POST",
                //     success: function(data) {
                //         if (data.available_time) {
                //             adds_on(getPublicID, true)
                //         } else {
                //             swal({
                //                 title: "Error",
                //                 text: 'THIS TIME IS ALREADY TAKEN BY ANOTHER RESERVATION, OR NOT INCLUDED IN COURT OPENING HOURS !!',
                //                 icon: "error",
                //             });
                //             return
                //         }
                //     },
                //     error: function(err) {
                //         console.log(err);
                //     }
                // });
            }else{
                $('#happy_price_container').empty()
            }
        });

        /*===================*/
        //select Reccuring
        getModalRecurringBtnEl.addEventListener("click", function() {

            var getPublicID = $(this).data('fc-recurring-public-id');
            // var getEvent = calendar.getEventById(getPublicID);

            $('#recurring_day').val(0);
            $('#recurring_start_time').val('')
            check_sess();
            $('#recurring_start_date').val('')
            $('#recurring_end_date').val('')

            //empty errors
            $('#recurring_start_error').empty()
            $('#recurring_start_date_error').empty()
            $('#recurring_end_date_error').empty()
            $('#recurring_day_error').empty()
            $('#recurring_duration_empty').empty()
            $('#recurring_duration_error').empty()
            $('#player_reccuring_error').empty()

            //recurring success modal remove previous errors
            $('#available_days').empty();
            $('#not_booked_days').empty();

            myModal.hide()
            recurringModal.show()
        });

        //add recurring 
        $(document).on('click', '#storerecurring', function() {
            //empty errors
            $('#recurring_start_error').empty()
            $('#recurring_start_date_error').empty()
            $('#recurring_end_date_error').empty()
            $('#recurring_day_error').empty()
            $('#recurring_duration_empty').empty()
            $('#recurring_duration_error').empty()

            // Your code to handle the click event goes here
            var weekday = $('#recurring_day').val()
            var starttime = $('#recurring_start_time').val();
            var minutes = parseInt($('#recurring_duration').val(), 10);
            var time_from = moment(starttime, 'h:mm A').format(
                'HH:mm:ss'); // Convert the timestamp to 24-hour format
            var time_to = moment(starttime, 'h:mm A').add(minutes, 'minutes').format('HH:mm:ss');
            var start_date = $('#recurring_start_date').val();
            var end_date = $('#recurring_end_date').val();
            var id_sport = $('#select_sport').val()
            var player_id = $('#user-select').val()

            if (!player_id || player_id < 1) {
                $('#player_reccuring_error').append(
                    `<span class="text-danger text-uppercase err">player is required !!</span>`)
            } else {
                $('#player_reccuring_error').empty()
            }

            if (!starttime) {
                $('#recurring_start_error').append(
                    `<span class="text-danger text-uppercase err">time from is required !!</span>`)
            } else {
                $('#recurring_start_error').empty()
            }
            if (!start_date) {
                $('#recurring_start_date_error').append(
                    `<span class="text-danger text-uppercase err">start date is required !!</span>`)
            } else {
                $('#recurring_start_date_error').empty()
            }
            if (!end_date) {
                $('#recurring_end_date_error').append(
                    `<span class="text-danger text-uppercase err">end date is required !!</span>`)
            } else {
                $('#recurring_end_date_error').empty()
            }
            if (isNaN(weekday) || weekday == 0 || weekday == null) {
                $('#recurring_day_error').append(
                    `<span class="text-danger text-uppercase err">seleting a day is required !!</span>`)
            } else {
                $('#recurring_day_error').empty()
            }
            if (isNaN(minutes)) {
                $('#recurring_duration_empty').append(
                    `<span class="text-danger text-uppercase err">fill the session duration !!</span>`)
            } else {
                $('#recurring_duration_empty').empty();
            }
            if (minutes < each_session_min) {
                $('#recurring_duration_error').append(
                    `<span class="text-danger text-uppercase err">The Session Duration should not be less than <b>${each_session_min}</b></span>`
                )
            } else {
                $('#recurring_duration_error').empty()
            }
            if ($('.err').length == 0) {
                $.ajax({
                    url: "<?php echo e(route('calendar.storerecurring')); ?>",
                    data: {
                        booking_id: booking_id,
                        court_id: court_id,
                        time_from: time_from,
                        time_to: time_to,
                        start_date: start_date,
                        end_date: end_date,
                        duration: minutes,
                        weekday: weekday == 7 ? 0 : weekday,
                        sport_id: id_sport,
                        player_id: player_id
                    },
                    type: "POST",
                    success: function(data) {
                        if (data.success) {

                            recurringModal.hide()
                            bookedDates.show()

                            if (data.booked_dates.length > 0) {
                                var booked_days = data.booked_dates;
                                var html =
                                    '<div> <span class="fs-6 mb-2 text-info text-uppercase">successfully booked sessions in: </span>'
                                for (let i = 0; i < booked_days.length; i++) {
                                    html += '<div class="text-success my-1 h5">' + booked_days[i] +
                                        '</div>';
                                }
                                html += '</div>';
                                $('#available_days').append(html)
                            } else {
                                $('#available_days').append(
                                    `<div class="text-warning text-uppercase h4">unfortunately there is no available reservation !! </b></div>`
                                )
                            }

                            if (data.not_available_dates.length > 0) {
                                var not_booked_days = data.not_available_dates;
                                var html =
                                    '<div> <span class="fs-6 mb-2 text-info text-uppercase">Not Available Dates: </span>'
                                for (let i = 0; i < not_booked_days.length; i++) {
                                    html += '<div class="text-danger my-1 h5">' + not_booked_days[
                                            i] +
                                        '</div>';
                                }
                                html += '</div>';
                                $('#not_booked_days').append(html)
                            } else {
                                $('#not_booked_days').append(``)
                            }
                        }
                    },
                    error: function(err) {
                        console.log(err);
                    }
                });
            }

        })
        // Relaod page on reccuring
        document.getElementById('booked_days').addEventListener('hidden.bs.modal', function(event) {
            console.log('Modal closed');
            location.reload()
        });
        /////////////////////////////////////

        //search 
        $(document).on('change', '#seacrch_by_id', function(e) {
            var sport_id = $('#seacrch_by_id').val();
            var URL = "<?php echo e(route('multiple.index')); ?>";
            if (sport_id != 0) {
                location.href = "<?php echo e(route('multiple.index', ['id' => ''])); ?>" + '/' + sport_id;
            } else {
                location.href = "<?php echo e(route('multiple.index')); ?>"
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/schedulecourts/index.blade.php ENDPATH**/ ?>