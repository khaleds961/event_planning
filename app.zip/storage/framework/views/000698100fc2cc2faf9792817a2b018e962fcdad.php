
<?php $__env->startSection('title', 'Court Items'); ?>
<?php $__env->startSection('content'); ?>

    
    <nav aria-label="breadcrumb" class="mb-1">
        <div class="d-md-flex justify-content-between">
            <ol class="breadcrumb border border-warning px-3 py-2 rounded">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('index')); ?>" class="text-warning d-flex align-items-center"><i
                            class="ti ti-home fs-4 mt-1"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('courts.index')); ?>" class="text-warning">Courts</a>
                </li>
                
                <li class="breadcrumb-item">
                    <a href="#" class="text-primary"><?php echo e($court_name); ?></a>
                </li>
            </ol>

            <div>
                <a type="button" class="btn mb-1 waves-effect waves-light btn-light text-dark fs-4 mx-2"
                    data-bs-toggle="modal" data-bs-target="#eventModal" id="modal_button">
                    <i class="ti ti-circle-plus"></i>
                    <span>Add New Item</span>
                </a>
            </div>
        </div>
    </nav>

    <div class="d-md-flex justify-content-end">
        <!-- BEGIN MODAL -->
        <div class="modal fade" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="eventModalLabel">
                            Add Item
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="mx-3">
                        <div class="row">
                            <div class="col">
                                <div class="search-container">
                                    <input type="text" placeholder="Search..." class="form-control" id="search_input">
                                    <div class="search-results"></div>
                                </div>
                            </div>
                        </div>

                        <div class="mt-3 d-none" id="plus_court_items">
                            <div class="row my-2">
                                <div class='col-4 text-primary text-uppercase'>name</div>
                                <div class='col-4 text-primary text-uppercase'>price <i class="ti ti-currency-dollar"></i> </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end my-2">
                            <button type="submit" class="btn btn-success btn-add-event" id="save_item">
                                Save Item
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="my-2">

                        <div class="table-responsive">
                            <table id="court_items_table"
                                class="table border table-striped table-bordered display text-nowrap">
                                <thead>
                                    <!-- start row -->
                                    <tr>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">#id</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">image</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">name</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">price<i class="ti ti-currency-dollar"></i></h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">is active</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0 text-uppercase">action</h6>
                                        </th>
                                    </tr>
                                    <!-- end row -->
                                </thead>
                                <tbody>
                                    <!-- start row -->
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                            </table>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(document).ready(function() {

            $('.dropify').dropify();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var court_id;
            var url = window.location.href;
            var regex = /id=(\d+)/; // Assumes ID is a numeric value
            var match = regex.exec(url);

            if (match != null) {
                court_id = match[1];
                // Output: The ID value from the URL
            } else {
                console.log("ID not found in URL");
            }

            var table = $('#court_items_table').DataTable({
                processing: true,
                serverSide: true,
                scrollY: '100%',
                scrollCollapse: true,
                paging: true,
                responsive: true,
                ajax: "<?php echo e(url('')); ?>" + "/courtitems/id=" + court_id,
                columns: [{
                        data: 'id',
                        id: 'id'
                    },
                    {
                        data: 'image',
                        name: 'image',
                    },
                    {
                        data: 'name',
                        name: 'name',
                    },
                    {
                        data: 'price',
                        name: 'price',
                        className: 'editprice',
                    },
                    {
                        data: 'is_active',
                        name: 'is_active'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false,
                        className: "text-center"
                    }
                ],
                order: [0, 'desc'],
            });

            var selectedItems = [];
            $('.search-container input').on('input', function() {
                console.log(selectedItems);
                var query = $(this).val().trim();
                if (query.length > 0) {
                    $.ajax({
                        url: "<?php echo e(route('courtitems.search')); ?>",
                        data: {
                            court_id: court_id,
                            name: query
                        },
                        type: "POST",
                        success: function(data) {
                            var results = $('.search-results');
                            results.empty();
                            if (data.data.length > 0) {
                                for (var i = 0; i < data.data.length; i++) {
                                    var item = data.data[i];
                                    var li = $('<li style="list-style: none;" class="my-2">');
                                    var text_image = item.img == null ?
                                        'images/courts/no-image.png' : item
                                        .img;
                                    var img = $('<img width="50" height="50">').attr('src',
                                        "<?php echo e(url('')); ?>" + "/" + text_image);
                                    var title = $('<span class="item_name mx-3">').text(item
                                        .name);
                                    // var price = $('<span value="' + item.price + '" >')
                                    var price = $('<span class="mx-3 item_price">').text(item
                                        .price)
                                    var item_id = item.id;

                                    // Use a closure to capture the correct value of item_id
                                    (function(item_id) {
                                        li.on('click', function() {
                                            if (selectedItems.includes(item_id)) {
                                                li.addClass('disabled');
                                                $('#search_input').val('')
                                                results.hide()
                                                return
                                            } else {
                                                $('#search_input').val('')
                                                var title = $(this).find(
                                                        '.item_name')
                                                    .text();
                                                // var price = $(this).find('input')
                                                //     .text();
                                                var price_i = $(this).find(
                                                        '.item_price')
                                                    .text();
                                                $('#plus_court_items').removeClass(
                                                    'd-none')
                                                $('#plus_court_items').append(`
                                    <div class="row mb-2 px-1 item d-flex align-items-center">
                                        <div class="col-4">
                                            ${title}
                                            </div>
                                        <div class="col-4">
                                            <input value="${price_i}" class="price_item form-control" type="number"/>
                                            <input class="id" type="hidden" value="${item_id}"/>
                                        </div>
                                        <div class="col-4">
                                            <i class="ti ti-trash fs-3 text-danger cursor-pointer"></i>
                                        </div>
                                    </div>
                                `)
                                                // Add the item to the selectedItems array and disable the li element
                                                selectedItems.push(item_id);
                                                $(this).addClass('disabled');
                                                results.hide();
                                            }
                                        });
                                    })(item_id);
                                    li.append(img);
                                    li.append(title);
                                    li.append(price);
                                    results.append(li);
                                }
                                results.show();
                            } else {
                                results.hide();
                            }
                        }
                    })
                } else {
                    $('.search-results').hide();
                }
            });

            // Add a click event listener to the trash icon
            $('#plus_court_items').on('click', '.ti-trash', function() {
                // Get the parent element of the trash icon
                var item = $(this).closest('.item');
                // Get the ID of the item from the hidden input field
                var item_id = item.find('.id').val();
                // Remove the item from the selectedItems array
                var index = selectedItems.indexOf(parseInt(item_id));
                if (index > -1) {
                    selectedItems.splice(index, 1);
                    // Remove the item from the DOM
                    item.remove();
                }
            });

            $(document).on('click', '#save_item', function(e) {

                var court_id;
                var url = window.location.href;
                var regex = /id=(\d+)/; // Assumes ID is a numeric value
                var match = regex.exec(url);

                if (match != null) {
                    court_id = match[1];
                    // Output: The ID value from the URL
                } else {
                    console.log("ID not found in URL");
                }

                // create an empty array to hold the items
                var items = [];
                // loop through each div element with the "item" class
                $(".item").each(function() {
                    // get the name and price from the span elements in the div element
                    var id = $(this).find(".id").val();
                    var price = $(this).find(".price_item").val();

                    // create an object with the name and price properties
                    var item = {
                        id: id,
                        price: price
                    };
                    // add the object to the items array
                    items.push(item);
                });
                // send the array of objects to the back end using AJAX
                $.ajax({
                    url: "<?php echo e(route('courtitems.store')); ?>",
                    type: "POST",
                    data: {
                        items: items,
                        court_id: court_id
                    },
                    success: function(response) {
                        if (response.success) {
                            swal({
                                title: 'ITEM(S) ADDED',
                                icon: 'success'
                            }).then(() => {
                                location.reload()
                            })
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                    }
                });
            });

            //when modal close
            $('#eventModal').on('hidden.bs.modal', function() {
                // This code will be executed when the modal is fully hidden
                console.log('The modal is now hidden');
            });

            $('#court_items_table tbody').on('click', '.editprice', function() {

                // Get the td element that was clicked
                var td = $(this);
                // console.log(table.row(this).data());
                var item = table.row(this).data();
                var item_price = item.price;

                // Get the current price
                var priceValue = $(this).text();

                // Create two new input elements with type="time" and set their values to the current check-in
                var priceInput = $('<input type="number">').val(priceValue);

                // Append the input elements to the td element
                td.empty().append(priceInput);

                // Set the focus to the check-in input element
                priceInput.focus();

                // Add a blur event listener to both input elements
                priceInput.blur(function() {

                    // Get the new values of the input elements
                    var new_price = priceInput.val();

                    // Get the attendance ID for the row
                    var item_id = item.id;

                    if (new_price || new_price > 0) {
                        $.ajax({
                            url: "<?php echo e(route('courtitems.update')); ?>",
                            type: 'POST',
                            data: {
                                item_id: item_id,
                                price: new_price,
                            },
                            success: function(response) {
                                if (response.success) {
                                    var price = response.data.price;
                                    // Replace the input elements with new td elements containing the updated values
                                    var newTd = $('<td>').addClass('editprice').text(
                                            price)
                                        .data('price', price)
                                        .data('item-id', response.data.id);
                                    td.replaceWith(newTd);
                                } else {
                                    var newTd = $('<td>').addClass('editprice').text(
                                            item_price)
                                        .data('price', item_price)
                                        .data('item-id', item_id);
                                    td.replaceWith(newTd);
                                }
                            },
                            error: function(xhr, status, error) {
                                console.log(xhr.responseText);
                            }
                        });
                    } else {
                        var newTd = $('<td>').addClass('editprice').text(
                                item_price)
                            .data('price', item_price)
                            .data('item-id', item_id);
                        td.replaceWith(newTd);
                    }
                    // Send an AJAX request to update the check-in and check-out times

                });
            });

            //click outside searchbar
            const myDiv = document.getElementsByClassName("search-results")[0];

            // Add click event listener to the document object
            document.addEventListener("click", function(event) {
                // Check if the clicked element is not the div or any of its child elements
                if (!myDiv.contains(event.target)) {
                    // Hide the div
                    myDiv.style.display = "none";
                    $('#search_input').val('')
                }
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sportciety\web\sportciety_club\resources\views/court_items/index.blade.php ENDPATH**/ ?>