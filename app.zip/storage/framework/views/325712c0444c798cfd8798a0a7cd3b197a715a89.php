<!-- Sidebar Start -->
<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div>
      <div class="brand-logo d-flex align-items-center justify-content-between">
        <a href="index.html" class="text-nowrap logo-img">
          <img src="<?php echo e(asset('images/logos/logo.png')); ?>" class="dark-logo" width="180" alt="" />
          <img src="https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/dist/images/logos/light-logo.svg" class="light-logo"  width="180" alt="" />
        </a>
        <div class="close-btn d-lg-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
          <i class="ti ti-x fs-8"></i>
        </div>
      </div>

      <!-- Sidebar navigation-->
      <nav class="sidebar-nav scroll-sidebar mt-3" data-simplebar>
        <ul id="sidebarnav">

          <li class="sidebar-item" >
            <a class="sidebar-link"
            href="<?php echo e(route('index')); ?>" aria-expanded="false">
              <span>
                <i class="ti ti-gauge"></i>
              </span>
              <span class="hide-menu">Dashboard</span>
            </a>
          </li>

          <li class="sidebar-item" >
            <a class="sidebar-link"
            href="<?php echo e(route('index')); ?>" aria-expanded="false">
              <span>
                <i class="ti ti-calendar-event"></i>
              </span>
              <span class="hide-menu">Schedule</span>
            </a>
          </li>

          <li class="sidebar-item" >
            <a class="sidebar-link"
            href="<?php echo e(route('index')); ?>" aria-expanded="false">
              <span>
                <i class="ti ti-brand-booking"></i>
              </span>
              <span class="hide-menu">Booking</span>
            </a>
          </li>

          

          <li class="sidebar-item">
            <a class="sidebar-link has-arrow " href="#" aria-expanded="false">
              <span class="d-flex">
                <i class="ti ti-soccer-field"></i>
              </span>
              <span class="hide-menu">Courts</span>
            </a>
            <ul aria-expanded="false" class="collapse first-level">
              <li class="sidebar-item">
                <a href="<?php echo e(route('courts.index')); ?>" class="sidebar-link">
                  <div class="round-16 d-flex align-items-center justify-content-center">
                    <i class="ti ti-circle"></i>
                  </div>
                  <span class="hide-menu">Show Courts</span>
                </a>
              </li>
              <li class="sidebar-item">
                <a href="blog-detail.html" class="sidebar-link">
                  <div class="round-16 d-flex align-items-center justify-content-center">
                    <i class="ti ti-circle"></i>
                  </div>
                  <span class="hide-menu">Details</span>
                </a>
              </li>
            </ul>
          </li>

          <li class="sidebar-item" >
            <a class="sidebar-link"
            href="<?php echo e(route('index')); ?>" aria-expanded="false">
              <span>
                <i class="ti ti-user"></i>
              </span>
              <span class="hide-menu">Staff</span>
            </a>
          </li>

          <li class="sidebar-item" >
            <a class="sidebar-link"
            href="<?php echo e(route('index')); ?>" aria-expanded="false">
              <span>
                <i class="ti ti-currency-dollar"></i>
              </span>
              <span class="hide-menu">Accounting</span>
            </a>
          </li>

          <li class="sidebar-item" >
            <a class="sidebar-link"
            href="<?php echo e(route('index')); ?>" aria-expanded="false">
              <span>
                <i class="ti ti-brand-hipchat"></i>
              </span>
              <span class="hide-menu">Chat</span>
            </a>
          </li>

         

        </ul>


        


      </nav>

      


      <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
    </aside>
    <!--  Sidebar End --><?php /**PATH C:\Users\khaled.alhoussein\Desktop\sporciety_new\sportciety_club\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>