<a style="cursor:pointer" href="<?php echo e(route('sales_items.index',['id' => $row->player_id])); ?>">
    <i class="ti ti-eye fs-7"></i>
</a><?php /**PATH /home/sportcietyapp/public_html/platform.sportcietyapp.com/resources/views/sales/actions.blade.php ENDPATH**/ ?>