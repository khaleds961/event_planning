<?php
return [
    'admins_types'  => 2,
    'club_category' => 23,
    'club_items'    => 24,
    'court_items'   => 25,
    'courts'        => 26,
    'sports'        => 27,
    'bookings'      => 28,
    'staff'         => 29,
    'accounting'    => 30,
    'clients'       => 31,
    'dashboard'     => 32,
    'summary'       => 33,
    'schedule'      => 34,
    'sales'         => 35
];